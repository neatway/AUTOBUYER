/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/contentScript.tsx");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function (useSourceMap) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item, useSourceMap);

      if (item[2]) {
        return '@media ' + item[2] + '{' + content + '}';
      } else {
        return content;
      }
    }).join('');
  }; // import a list of modules into the list


  list.i = function (modules, mediaQuery) {
    if (typeof modules === 'string') {
      modules = [[null, modules, '']];
    }

    var alreadyImportedModules = {};

    for (var i = 0; i < this.length; i++) {
      var id = this[i][0];

      if (id != null) {
        alreadyImportedModules[id] = true;
      }
    }

    for (i = 0; i < modules.length; i++) {
      var item = modules[i]; // skip already imported module
      // this implementation is not 100% perfect for weird media query combinations
      // when a module is imported multiple times with different media queries.
      // I hope this will never occur (Hey this way we have smaller bundles)

      if (item[0] == null || !alreadyImportedModules[item[0]]) {
        if (mediaQuery && !item[2]) {
          item[2] = mediaQuery;
        } else if (mediaQuery) {
          item[2] = '(' + item[2] + ') and (' + mediaQuery + ')';
        }

        list.push(item);
      }
    }
  };

  return list;
};

function cssWithMappingToString(item, useSourceMap) {
  var content = item[1] || '';
  var cssMapping = item[3];

  if (!cssMapping) {
    return content;
  }

  if (useSourceMap && typeof btoa === 'function') {
    var sourceMapping = toComment(cssMapping);
    var sourceURLs = cssMapping.sources.map(function (source) {
      return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */';
    });
    return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
  }

  return [content].join('\n');
} // Adapted from convert-source-map (MIT)


function toComment(sourceMap) {
  // eslint-disable-next-line no-undef
  var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
  var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;
  return '/*# ' + data + ' */';
}

/***/ }),

/***/ "./node_modules/css-modules-typescript-loader/index.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/sass-loader/lib/loader.js!./src/contentScript.scss":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-modules-typescript-loader!./node_modules/css-loader/dist/cjs.js??ref--5-2!./node_modules/sass-loader/lib/loader.js!./src/contentScript.scss ***!
  \**********************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js")(false);
// Module
exports.push([module.i, "#_12f_qBdAf_c3g9osSLZec4,\n#_19jaCs7JmPI-XnVJ-LiEkE,\n#_31Fm_EkdWZhyuefUk8Kj4C,\n#_30ALGLrGGF_fZgDj5d6XOi {\n  display: none; }\n", ""]);

// Exports
exports.locals = {
	"audio": "_12f_qBdAf_c3g9osSLZec4",
	"loopDoneSound": "_19jaCs7JmPI-XnVJ-LiEkE",
	"cardSeenSound": "_31Fm_EkdWZhyuefUk8Kj4C",
	"cardPurchasedSound": "_30ALGLrGGF_fZgDj5d6XOi"
};

/***/ }),

/***/ "./node_modules/style-loader/lib/addStyles.js":
/*!****************************************************!*\
  !*** ./node_modules/style-loader/lib/addStyles.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/

var stylesInDom = {};

var	memoize = function (fn) {
	var memo;

	return function () {
		if (typeof memo === "undefined") memo = fn.apply(this, arguments);
		return memo;
	};
};

var isOldIE = memoize(function () {
	// Test for IE <= 9 as proposed by Browserhacks
	// @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
	// Tests for existence of standard globals is to allow style-loader
	// to operate correctly into non-standard environments
	// @see https://github.com/webpack-contrib/style-loader/issues/177
	return window && document && document.all && !window.atob;
});

var getTarget = function (target) {
  return document.querySelector(target);
};

var getElement = (function (fn) {
	var memo = {};

	return function(target) {
                // If passing function in options, then use it for resolve "head" element.
                // Useful for Shadow Root style i.e
                // {
                //   insertInto: function () { return document.querySelector("#foo").shadowRoot }
                // }
                if (typeof target === 'function') {
                        return target();
                }
                if (typeof memo[target] === "undefined") {
			var styleTarget = getTarget.call(this, target);
			// Special case to return head of iframe instead of iframe itself
			if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
				try {
					// This will throw an exception if access to iframe is blocked
					// due to cross-origin restrictions
					styleTarget = styleTarget.contentDocument.head;
				} catch(e) {
					styleTarget = null;
				}
			}
			memo[target] = styleTarget;
		}
		return memo[target]
	};
})();

var singleton = null;
var	singletonCounter = 0;
var	stylesInsertedAtTop = [];

var	fixUrls = __webpack_require__(/*! ./urls */ "./node_modules/style-loader/lib/urls.js");

module.exports = function(list, options) {
	if (typeof DEBUG !== "undefined" && DEBUG) {
		if (typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
	}

	options = options || {};

	options.attrs = typeof options.attrs === "object" ? options.attrs : {};

	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	if (!options.singleton && typeof options.singleton !== "boolean") options.singleton = isOldIE();

	// By default, add <style> tags to the <head> element
        if (!options.insertInto) options.insertInto = "head";

	// By default, add <style> tags to the bottom of the target
	if (!options.insertAt) options.insertAt = "bottom";

	var styles = listToStyles(list, options);

	addStylesToDom(styles, options);

	return function update (newList) {
		var mayRemove = [];

		for (var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];

			domStyle.refs--;
			mayRemove.push(domStyle);
		}

		if(newList) {
			var newStyles = listToStyles(newList, options);
			addStylesToDom(newStyles, options);
		}

		for (var i = 0; i < mayRemove.length; i++) {
			var domStyle = mayRemove[i];

			if(domStyle.refs === 0) {
				for (var j = 0; j < domStyle.parts.length; j++) domStyle.parts[j]();

				delete stylesInDom[domStyle.id];
			}
		}
	};
};

function addStylesToDom (styles, options) {
	for (var i = 0; i < styles.length; i++) {
		var item = styles[i];
		var domStyle = stylesInDom[item.id];

		if(domStyle) {
			domStyle.refs++;

			for(var j = 0; j < domStyle.parts.length; j++) {
				domStyle.parts[j](item.parts[j]);
			}

			for(; j < item.parts.length; j++) {
				domStyle.parts.push(addStyle(item.parts[j], options));
			}
		} else {
			var parts = [];

			for(var j = 0; j < item.parts.length; j++) {
				parts.push(addStyle(item.parts[j], options));
			}

			stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
		}
	}
}

function listToStyles (list, options) {
	var styles = [];
	var newStyles = {};

	for (var i = 0; i < list.length; i++) {
		var item = list[i];
		var id = options.base ? item[0] + options.base : item[0];
		var css = item[1];
		var media = item[2];
		var sourceMap = item[3];
		var part = {css: css, media: media, sourceMap: sourceMap};

		if(!newStyles[id]) styles.push(newStyles[id] = {id: id, parts: [part]});
		else newStyles[id].parts.push(part);
	}

	return styles;
}

function insertStyleElement (options, style) {
	var target = getElement(options.insertInto)

	if (!target) {
		throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");
	}

	var lastStyleElementInsertedAtTop = stylesInsertedAtTop[stylesInsertedAtTop.length - 1];

	if (options.insertAt === "top") {
		if (!lastStyleElementInsertedAtTop) {
			target.insertBefore(style, target.firstChild);
		} else if (lastStyleElementInsertedAtTop.nextSibling) {
			target.insertBefore(style, lastStyleElementInsertedAtTop.nextSibling);
		} else {
			target.appendChild(style);
		}
		stylesInsertedAtTop.push(style);
	} else if (options.insertAt === "bottom") {
		target.appendChild(style);
	} else if (typeof options.insertAt === "object" && options.insertAt.before) {
		var nextSibling = getElement(options.insertInto + " " + options.insertAt.before);
		target.insertBefore(style, nextSibling);
	} else {
		throw new Error("[Style Loader]\n\n Invalid value for parameter 'insertAt' ('options.insertAt') found.\n Must be 'top', 'bottom', or Object.\n (https://github.com/webpack-contrib/style-loader#insertat)\n");
	}
}

function removeStyleElement (style) {
	if (style.parentNode === null) return false;
	style.parentNode.removeChild(style);

	var idx = stylesInsertedAtTop.indexOf(style);
	if(idx >= 0) {
		stylesInsertedAtTop.splice(idx, 1);
	}
}

function createStyleElement (options) {
	var style = document.createElement("style");

	options.attrs.type = "text/css";

	addAttrs(style, options.attrs);
	insertStyleElement(options, style);

	return style;
}

function createLinkElement (options) {
	var link = document.createElement("link");

	options.attrs.type = "text/css";
	options.attrs.rel = "stylesheet";

	addAttrs(link, options.attrs);
	insertStyleElement(options, link);

	return link;
}

function addAttrs (el, attrs) {
	Object.keys(attrs).forEach(function (key) {
		el.setAttribute(key, attrs[key]);
	});
}

function addStyle (obj, options) {
	var style, update, remove, result;

	// If a transform function was defined, run it on the css
	if (options.transform && obj.css) {
	    result = options.transform(obj.css);

	    if (result) {
	    	// If transform returns a value, use that instead of the original css.
	    	// This allows running runtime transformations on the css.
	    	obj.css = result;
	    } else {
	    	// If the transform function returns a falsy value, don't add this css.
	    	// This allows conditional loading of css
	    	return function() {
	    		// noop
	    	};
	    }
	}

	if (options.singleton) {
		var styleIndex = singletonCounter++;

		style = singleton || (singleton = createStyleElement(options));

		update = applyToSingletonTag.bind(null, style, styleIndex, false);
		remove = applyToSingletonTag.bind(null, style, styleIndex, true);

	} else if (
		obj.sourceMap &&
		typeof URL === "function" &&
		typeof URL.createObjectURL === "function" &&
		typeof URL.revokeObjectURL === "function" &&
		typeof Blob === "function" &&
		typeof btoa === "function"
	) {
		style = createLinkElement(options);
		update = updateLink.bind(null, style, options);
		remove = function () {
			removeStyleElement(style);

			if(style.href) URL.revokeObjectURL(style.href);
		};
	} else {
		style = createStyleElement(options);
		update = applyToTag.bind(null, style);
		remove = function () {
			removeStyleElement(style);
		};
	}

	update(obj);

	return function updateStyle (newObj) {
		if (newObj) {
			if (
				newObj.css === obj.css &&
				newObj.media === obj.media &&
				newObj.sourceMap === obj.sourceMap
			) {
				return;
			}

			update(obj = newObj);
		} else {
			remove();
		}
	};
}

var replaceText = (function () {
	var textStore = [];

	return function (index, replacement) {
		textStore[index] = replacement;

		return textStore.filter(Boolean).join('\n');
	};
})();

function applyToSingletonTag (style, index, remove, obj) {
	var css = remove ? "" : obj.css;

	if (style.styleSheet) {
		style.styleSheet.cssText = replaceText(index, css);
	} else {
		var cssNode = document.createTextNode(css);
		var childNodes = style.childNodes;

		if (childNodes[index]) style.removeChild(childNodes[index]);

		if (childNodes.length) {
			style.insertBefore(cssNode, childNodes[index]);
		} else {
			style.appendChild(cssNode);
		}
	}
}

function applyToTag (style, obj) {
	var css = obj.css;
	var media = obj.media;

	if(media) {
		style.setAttribute("media", media)
	}

	if(style.styleSheet) {
		style.styleSheet.cssText = css;
	} else {
		while(style.firstChild) {
			style.removeChild(style.firstChild);
		}

		style.appendChild(document.createTextNode(css));
	}
}

function updateLink (link, options, obj) {
	var css = obj.css;
	var sourceMap = obj.sourceMap;

	/*
		If convertToAbsoluteUrls isn't defined, but sourcemaps are enabled
		and there is no publicPath defined then lets turn convertToAbsoluteUrls
		on by default.  Otherwise default to the convertToAbsoluteUrls option
		directly
	*/
	var autoFixUrls = options.convertToAbsoluteUrls === undefined && sourceMap;

	if (options.convertToAbsoluteUrls || autoFixUrls) {
		css = fixUrls(css);
	}

	if (sourceMap) {
		// http://stackoverflow.com/a/26603875
		css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
	}

	var blob = new Blob([css], { type: "text/css" });

	var oldSrc = link.href;

	link.href = URL.createObjectURL(blob);

	if(oldSrc) URL.revokeObjectURL(oldSrc);
}


/***/ }),

/***/ "./node_modules/style-loader/lib/urls.js":
/*!***********************************************!*\
  !*** ./node_modules/style-loader/lib/urls.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {


/**
 * When source maps are enabled, `style-loader` uses a link element with a data-uri to
 * embed the css on the page. This breaks all relative urls because now they are relative to a
 * bundle instead of the current page.
 *
 * One solution is to only use full urls, but that may be impossible.
 *
 * Instead, this function "fixes" the relative urls to be absolute according to the current page location.
 *
 * A rudimentary test suite is located at `test/fixUrls.js` and can be run via the `npm test` command.
 *
 */

module.exports = function (css) {
  // get current location
  var location = typeof window !== "undefined" && window.location;

  if (!location) {
    throw new Error("fixUrls requires window.location");
  }

	// blank or null?
	if (!css || typeof css !== "string") {
	  return css;
  }

  var baseUrl = location.protocol + "//" + location.host;
  var currentDir = baseUrl + location.pathname.replace(/\/[^\/]*$/, "/");

	// convert each url(...)
	/*
	This regular expression is just a way to recursively match brackets within
	a string.

	 /url\s*\(  = Match on the word "url" with any whitespace after it and then a parens
	   (  = Start a capturing group
	     (?:  = Start a non-capturing group
	         [^)(]  = Match anything that isn't a parentheses
	         |  = OR
	         \(  = Match a start parentheses
	             (?:  = Start another non-capturing groups
	                 [^)(]+  = Match anything that isn't a parentheses
	                 |  = OR
	                 \(  = Match a start parentheses
	                     [^)(]*  = Match anything that isn't a parentheses
	                 \)  = Match a end parentheses
	             )  = End Group
              *\) = Match anything and then a close parens
          )  = Close non-capturing group
          *  = Match anything
       )  = Close capturing group
	 \)  = Match a close parens

	 /gi  = Get all matches, not the first.  Be case insensitive.
	 */
	var fixedCss = css.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi, function(fullMatch, origUrl) {
		// strip quotes (if they exist)
		var unquotedOrigUrl = origUrl
			.trim()
			.replace(/^"(.*)"$/, function(o, $1){ return $1; })
			.replace(/^'(.*)'$/, function(o, $1){ return $1; });

		// already a full url? no change
		if (/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/|\s*$)/i.test(unquotedOrigUrl)) {
		  return fullMatch;
		}

		// convert the url to a full url
		var newUrl;

		if (unquotedOrigUrl.indexOf("//") === 0) {
		  	//TODO: should we add protocol?
			newUrl = unquotedOrigUrl;
		} else if (unquotedOrigUrl.indexOf("/") === 0) {
			// path should be relative to the base url
			newUrl = baseUrl + unquotedOrigUrl; // already starts with '/'
		} else {
			// path should be relative to current directory
			newUrl = currentDir + unquotedOrigUrl.replace(/^\.\//, ""); // Strip leading './'
		}

		// send back the fixed url(...)
		return "url(" + JSON.stringify(newUrl) + ")";
	});

	// send back the fixed css
	return fixedCss;
};


/***/ }),

/***/ "./src/actions/back.ts":
/*!*****************************!*\
  !*** ./src/actions/back.ts ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var getListItems_1 = __importDefault(__webpack_require__(/*! ./helpers/getListItems */ "./src/actions/helpers/getListItems.ts"));
var isUserOnSearchResultsPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchResultsPage */ "./src/actions/helpers/isUserOnSearchResultsPage.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
var isUserOnTransfersPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnTransfersPage */ "./src/actions/helpers/isUserOnTransfersPage.ts"));
var isUserOnTransferTargetsPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnTransferTargetsPage */ "./src/actions/helpers/isUserOnTransferTargetsPage.ts"));
var isUserOnUnassignedPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnUnassignedPage */ "./src/actions/helpers/isUserOnUnassignedPage.ts"));
function goBack() {
    // Prioritizes back button in secondary nav.
    var secondaryHeader = document.getElementsByClassName("navbar-style-secondary")[0];
    if (secondaryHeader && secondaryHeader.getElementsByTagName("button")[0]) {
        clickElement_1.default(secondaryHeader.getElementsByTagName("button")[0]);
        return;
    }
    // Falls back to primary nav back button.
    if (isUserOnSearchTransferMarketPage_1.default() ||
        isUserOnSearchResultsPage_1.default() ||
        isUserOnUnassignedPage_1.default() ||
        isUserOnTransfersPage_1.default() ||
        isUserOnTransferTargetsPage_1.default()) {
        if (isUserOnSearchResultsPage_1.default()) {
            var hasSearchResults = getListItems_1.default().length > 0;
            // If there are no results, we'll go back regardless.
            if (!hasSearchResults) {
                clickElement_1.default(document.getElementsByClassName("ut-navigation-button-control")[0]);
                return;
            }
            // If there are results, check setting and if last search was less than 2.5 seconds ago.
            chrome.storage.sync.get(["lastSearchTime", "disableBack"], function (data) {
                var lastSearchTime = data.lastSearchTime, disableBack = data.disableBack;
                var now = Date.now();
                var timeSinceSearch = now - (lastSearchTime || 0);
                if (timeSinceSearch < 2500 && disableBack) {
                    return;
                }
                else {
                    clickElement_1.default(document.getElementsByClassName("ut-navigation-button-control")[0]);
                }
            });
        }
        else {
            clickElement_1.default(document.getElementsByClassName("ut-navigation-button-control")[0]);
        }
    }
}
exports.default = goBack;


/***/ }),

/***/ "./src/actions/buyNow.ts":
/*!*******************************!*\
  !*** ./src/actions/buyNow.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var confirmConfirmationDialog_1 = __importDefault(__webpack_require__(/*! ./helpers/confirmConfirmationDialog */ "./src/actions/helpers/confirmConfirmationDialog.ts"));
var isUserOnSearchResultsPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchResultsPage */ "./src/actions/helpers/isUserOnSearchResultsPage.ts"));
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
function buyNow() {
    if (isUserOnSearchResultsPage_1.default()) {
        try {
            buyCard();
        }
        catch (error) { }
    }
}
exports.default = buyNow;
function buyCard() {
    clickBuyNowButton();
    var timer = setInterval(function () {
        confirmConfirmationDialog_1.default(function () {
            clearInterval(timer);
        });
    }, 0);
}
function clickBuyNowButton() {
    var button = document.getElementsByClassName("buyButton")[0];
    clickElement_1.default(button);
}


/***/ }),

/***/ "./src/actions/decreaseMaxBinPrice.ts":
/*!********************************************!*\
  !*** ./src/actions/decreaseMaxBinPrice.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
function decreaseMaxBinPrice() {
    if (isUserOnSearchTransferMarketPage_1.default()) {
        var button = document.getElementsByClassName("decrement-value")[3];
        clickElement_1.default(button);
    }
}
exports.default = decreaseMaxBinPrice;


/***/ }),

/***/ "./src/actions/helpers/clickDetailsPanelButton.ts":
/*!********************************************************!*\
  !*** ./src/actions/helpers/clickDetailsPanelButton.ts ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./clickElement */ "./src/actions/helpers/clickElement.ts"));
function clickDetailsPanelButton(buttonLabel) {
    try {
        // Expand "List on Transfer Market" section.
        if (buttonLabel === "List Item") {
            var _buttons = document.getElementsByTagName("button");
            var buttons = Array.from(_buttons);
            for (var _i = 0, buttons_1 = buttons; _i < buttons_1.length; _i++) {
                var button = buttons_1[_i];
                if (button &&
                    button.innerHTML.indexOf("List on Transfer Market") > -1) {
                    clickElement_1.default(button);
                    setTimeout(function () {
                        // Get buttons in the details panel.
                        var detailsPanel = document.getElementsByClassName("DetailPanel")[0];
                        var detailsPanelButtons = detailsPanel.getElementsByTagName("button");
                        var buttonArray = Array.from(detailsPanelButtons);
                        // Find target button by searching by label.
                        var _button = buttonArray.filter(function (__button) {
                            return __button.innerHTML.indexOf(buttonLabel) > -1 &&
                                __button.style.display !== "none";
                        })[0];
                        // Click target button.
                        clickElement_1.default(_button);
                    }, 1000);
                    return;
                }
            }
        }
        // Get buttons in the details panel.
        var detailsPanel = document.getElementsByClassName("DetailPanel")[0];
        var detailsPanelButtons = detailsPanel.getElementsByTagName("button");
        var buttonArray = Array.from(detailsPanelButtons);
        // Find target button by searching by label.
        var _button = buttonArray.filter(function (foo) {
            return foo.innerHTML.indexOf(buttonLabel) > -1 &&
                foo.style.display !== "none";
        })[0];
        // Click target button.
        clickElement_1.default(_button);
    }
    catch (error) {
        throw "Unable to find that button.";
    }
}
exports.default = clickDetailsPanelButton;


/***/ }),

/***/ "./src/actions/helpers/clickElement.ts":
/*!*********************************************!*\
  !*** ./src/actions/helpers/clickElement.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Simulates a click on an element.
 */
function clickElement(element) {
    sendTouchEvent(element, 'touchstart');
    sendTouchEvent(element, 'touchend');
}
exports.default = clickElement;
/**
 * Dispatches a touch event on the element.
 * https://stackoverflow.com/a/42447620
 *
 * @param {HTMLElement} element
 * @param {string} eventType
 */
function sendTouchEvent(element, eventType) {
    /**
     * Touch constructor does take an object in Chrome, but typings aren't updated,
     * so it shows as an error when in reality it's fine.
     */
    // @ts-ignore
    var touch = new Touch({
        // Using a number like TS suggest breaks this... stupid.
        // @ts-ignore
        identifier: Math.random().toString(),
        target: element,
        clientX: Math.random(),
        clientY: Math.random(),
        radiusX: 2.5,
        radiusY: 2.5,
        rotationAngle: 10,
        force: 0.5
    });
    var touchEvent = new TouchEvent(eventType, {
        cancelable: true,
        bubbles: true,
        touches: [touch],
        targetTouches: [touch],
        changedTouches: [touch],
        shiftKey: true
    });
    element.dispatchEvent(touchEvent);
}


/***/ }),

/***/ "./src/actions/helpers/confirmConfirmationDialog.ts":
/*!**********************************************************!*\
  !*** ./src/actions/helpers/confirmConfirmationDialog.ts ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./clickElement */ "./src/actions/helpers/clickElement.ts"));
/**
 * Presses "OK" button in confirmation dialog.
 */
function confirmConfirmationDialog(success) {
    try {
        var okButton = document
            .getElementsByClassName("Dialog")[0]
            .getElementsByTagName("button")[0];
        clickElement_1.default(okButton);
        success && success();
    }
    catch (error) { }
}
exports.default = confirmConfirmationDialog;


/***/ }),

/***/ "./src/actions/helpers/getListItemButtonText.ts":
/*!******************************************************!*\
  !*** ./src/actions/helpers/getListItemButtonText.ts ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function getListItemButtonText() {
    var buttonText = "List for Transfer";
    var language = document.getElementsByTagName("html")[0].lang;
    switch (language) {
        case "fr":
            buttonText = "Placer sur liste des transferts";
            break;
        case "it":
            buttonText = "Metti sul mercato";
            break;
        case "de":
            buttonText = "Anbieten";
            break;
        case "pl":
            buttonText = "Wystaw na licytację";
            break;
        case "nl":
            buttonText = "Op transferlijst plaatsen";
            break;
        case "pt":
            buttonText = "Listar para transferência";
            break;
        case "es":
            buttonText = "Añadir a transferibles";
            break;
        case "ru":
            buttonText = "Выставить на продажу";
            break;
        case "tr":
            buttonText = "Transfer için Listele";
            break;
        case "ko":
            buttonText = "이적 목록에 올리기";
            break;
        case "da":
            buttonText = "Sæt på transferlisten";
            break;
    }
    return buttonText;
}
exports.default = getListItemButtonText;


/***/ }),

/***/ "./src/actions/helpers/getListItems.ts":
/*!*********************************************!*\
  !*** ./src/actions/helpers/getListItems.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var isUserOnSearchResultsPage_1 = __importDefault(__webpack_require__(/*! ./isUserOnSearchResultsPage */ "./src/actions/helpers/isUserOnSearchResultsPage.ts"));
var isUserOnUnassignedPage_1 = __importDefault(__webpack_require__(/*! ./isUserOnUnassignedPage */ "./src/actions/helpers/isUserOnUnassignedPage.ts"));
var isUserOnTransfersPage_1 = __importDefault(__webpack_require__(/*! ./isUserOnTransfersPage */ "./src/actions/helpers/isUserOnTransfersPage.ts"));
function getListItems() {
    var items = [];
    if (isUserOnSearchResultsPage_1.default()) {
        var itemList = document.getElementsByClassName("paginated-item-list")[0];
        items = Array.from(itemList.getElementsByClassName("listFUTItem"));
    }
    else if (isUserOnUnassignedPage_1.default() || isUserOnTransfersPage_1.default()) {
        var itemLists = Array.from(document.getElementsByClassName("itemList"));
        itemLists.forEach(function (itemList) {
            items = items.concat(Array.from(itemList.getElementsByClassName("listFUTItem")));
        }, this);
    }
    else {
        var itemList = document.getElementsByClassName("paginated-item-list")[0];
        items = Array.from(itemList.getElementsByClassName("listFUTItem"));
    }
    return items;
}
exports.default = getListItems;


/***/ }),

/***/ "./src/actions/helpers/isUserOnPage.ts":
/*!*********************************************!*\
  !*** ./src/actions/helpers/isUserOnPage.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Checks if user is on specific page.
 */
function isUserOnPage(pageTitle) {
    var title = document.getElementsByClassName('title')[0];
    return title && title.innerHTML === pageTitle;
}
exports.default = isUserOnPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnSearchResultsPage.ts":
/*!**********************************************************!*\
  !*** ./src/actions/helpers/isUserOnSearchResultsPage.ts ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isUserOnSearchResultsPage() {
    var elements = document.getElementsByClassName("SearchResults");
    return elements.length > 0;
}
exports.default = isUserOnSearchResultsPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts":
/*!*****************************************************************!*\
  !*** ./src/actions/helpers/isUserOnSearchTransferMarketPage.ts ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isUserOnSearchTransferMarketPage() {
    var elements = document.getElementsByClassName("ut-market-search-filters-view");
    var sbcElement = document.getElementsByClassName("sbc");
    return elements.length > 0 && sbcElement.length === 0;
}
exports.default = isUserOnSearchTransferMarketPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnTransferTargetsPage.ts":
/*!************************************************************!*\
  !*** ./src/actions/helpers/isUserOnTransferTargetsPage.ts ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isUserOnTransferTargetsPage() {
    var elements = document.getElementsByClassName("ut-watch-list-view");
    return elements.length > 0;
}
exports.default = isUserOnTransferTargetsPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnTransfersPage.ts":
/*!******************************************************!*\
  !*** ./src/actions/helpers/isUserOnTransfersPage.ts ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function isUserOnTransfersPage() {
    var elements = document.getElementsByClassName("ut-transfer-list-view");
    return elements.length > 0;
}
exports.default = isUserOnTransfersPage;


/***/ }),

/***/ "./src/actions/helpers/isUserOnUnassignedPage.ts":
/*!*******************************************************!*\
  !*** ./src/actions/helpers/isUserOnUnassignedPage.ts ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var isUserOnPage_1 = __importDefault(__webpack_require__(/*! ./isUserOnPage */ "./src/actions/helpers/isUserOnPage.ts"));
function isUserOnUnassignedPage() {
    return (
    // English
    isUserOnPage_1.default("Unassigned") ||
        // French
        isUserOnPage_1.default("NON ATTRIBUÉS") ||
        // Italian
        isUserOnPage_1.default("NON ASSEGNATI") ||
        // German
        isUserOnPage_1.default("NICHT ZUGEWIESEN") ||
        // Polish
        isUserOnPage_1.default("Nieprzypisane") ||
        // Dutch
        isUserOnPage_1.default("NIET TOEGEWEZ.") ||
        // Portuguese
        isUserOnPage_1.default("Não Atribuídos") ||
        // Spanish
        isUserOnPage_1.default("No asignados") ||
        // Russian
        isUserOnPage_1.default("Не назначено") ||
        // Turkish
        isUserOnPage_1.default("Atanmayan") ||
        // Korean
        isUserOnPage_1.default("지정되지 않음"));
}
exports.default = isUserOnUnassignedPage;


/***/ }),

/***/ "./src/actions/increaseMaxBinPrice.ts":
/*!********************************************!*\
  !*** ./src/actions/increaseMaxBinPrice.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
function increaseMaxBinPrice() {
    if (isUserOnSearchTransferMarketPage_1.default()) {
        var button = document.getElementsByClassName("increment-value")[3];
        clickElement_1.default(button);
    }
}
exports.default = increaseMaxBinPrice;


/***/ }),

/***/ "./src/actions/increaseMinBidPrice.ts":
/*!********************************************!*\
  !*** ./src/actions/increaseMinBidPrice.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
function increaseMinBidPrice() {
    var button = document.getElementsByClassName("increment-value")[0];
    clickElement_1.default(button);
}
exports.default = increaseMinBidPrice;


/***/ }),

/***/ "./src/actions/increaseMinBinPrice.ts":
/*!********************************************!*\
  !*** ./src/actions/increaseMinBinPrice.ts ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
function increaseMinBinPrice() {
    if (isUserOnSearchTransferMarketPage_1.default()) {
        var button = document.getElementsByClassName("increment-value")[2];
        clickElement_1.default(button);
    }
}
exports.default = increaseMinBinPrice;


/***/ }),

/***/ "./src/actions/list.ts":
/*!*****************************!*\
  !*** ./src/actions/list.ts ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var getListItemButtonText_1 = __importDefault(__webpack_require__(/*! ./helpers/getListItemButtonText */ "./src/actions/helpers/getListItemButtonText.ts"));
function list(startPrice, buyNowPrice) {
    var quickListPanel = document.getElementsByClassName("DetailPanel")[0];
    var quickListPanelActions = quickListPanel.getElementsByClassName("panelActions")[0];
    var actionRows = quickListPanelActions.getElementsByClassName("panelActionRow");
    if (startPrice) {
        var startPriceRow = actionRows[1];
        var startPriceInput = startPriceRow.getElementsByTagName("input")[0];
        startPriceInput.value = startPrice;
    }
    if (buyNowPrice) {
        var binRow = actionRows[2];
        var binInput = binRow.getElementsByTagName("input")[0];
        binInput.value = buyNowPrice.toString();
    }
    // Get all buttons in "List on Transfer Market" section.
    var _buttons = quickListPanelActions.getElementsByTagName("button");
    var buttons = Array.from(_buttons);
    // Find button with "List Item" as text and tap it.
    var listItemButton;
    var buttonText = getListItemButtonText_1.default();
    for (var _i = 0, buttons_1 = buttons; _i < buttons_1.length; _i++) {
        var button = buttons_1[_i];
        if (button && button.innerHTML === buttonText) {
            listItemButton = button;
        }
    }
    clickElement_1.default(listItemButton);
}
exports.default = list;


/***/ }),

/***/ "./src/actions/search.ts":
/*!*******************************!*\
  !*** ./src/actions/search.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var buyNow_1 = __importDefault(__webpack_require__(/*! ./buyNow */ "./src/actions/buyNow.ts"));
var clickElement_1 = __importDefault(__webpack_require__(/*! ./helpers/clickElement */ "./src/actions/helpers/clickElement.ts"));
var getListItems_1 = __importDefault(__webpack_require__(/*! ./helpers/getListItems */ "./src/actions/helpers/getListItems.ts"));
var isUserOnSearchTransferMarketPage_1 = __importDefault(__webpack_require__(/*! ./helpers/isUserOnSearchTransferMarketPage */ "./src/actions/helpers/isUserOnSearchTransferMarketPage.ts"));
var contentScript_scss_1 = __importDefault(__webpack_require__(/*! ../contentScript.scss */ "./src/contentScript.scss"));
var dangerousInterval = null;
var globalIntervalId = 0;
function search(doHandsfreeBin) {
    if (!isUserOnSearchTransferMarketPage_1.default()) {
        return;
    }
    // Clear interval when new search is happening.
    clearDangerousInterval();
    var searchButton = document.getElementsByClassName("btn-standard call-to-action")[0];
    clickElement_1.default(searchButton);
    var oldSearchCount = window.localStorage.getItem("searchCount");
    var newSearchCount = oldSearchCount ? parseInt(oldSearchCount) + 1 : 1;
    window.localStorage.setItem("searchCount", newSearchCount.toString());
    if (newSearchCount === 1) {
        chrome.storage.sync.get(["discordWebhookCardSeen"], function (data) {
            if (data.discordWebhookCardSeen) {
                // TODO: Add "started" message when we do logging
            }
        });
    }
    // incremement ID to track new interval
    globalIntervalId = globalIntervalId + 1;
    var iterationId = globalIntervalId;
    dangerousInterval = setInterval(function () {
        try {
            var hasSearchResults = getListItems_1.default().length > 0;
            var isNoResultsPage = document.getElementsByClassName("ut-no-results-view").length > 0;
            if (hasSearchResults || isNoResultsPage) {
                try {
                    var items = getListItems_1.default();
                    clickElement_1.default(items[items.length - 1].getElementsByClassName("has-tap-callback")[0]);
                }
                catch (error) { }
                if (doHandsfreeBin) {
                    setTimeout(function () {
                        handsfreeBin();
                    }, 50);
                }
                // Clear interval once search has completed.
                clearDangerousInterval();
            }
        }
        catch (e) { }
    }, 0);
    // clear dangerous timer after a few seconds
    setTimeout(function () {
        clearDangerousInterval(iterationId);
    }, 3500);
}
exports.default = search;
var handsfreeBin = function () {
    try {
        var isBuyButtonPresent = document.getElementsByClassName("buyButton").length > 0;
        if (isBuyButtonPresent) {
            buyNow_1.default();
            // increments seen count
            var oldCount = window.localStorage.getItem("seenCount");
            var newCount = oldCount ? parseInt(oldCount) + 1 : 1;
            window.localStorage.setItem("seenCount", newCount.toString());
            // notes that we just saw a card for "card purchased" count
            window.localStorage.setItem("justSawCard", "true");
            chrome.storage.sync.get(["shouldPlayResultSeenSound", "discordWebhookCardSeen"], function (data) {
                if (data.shouldPlayResultSeenSound) {
                    var cardSeenSound = document.getElementById(contentScript_scss_1.default.cardSeenSound);
                    cardSeenSound.play();
                }
                if (data.discordWebhookCardSeen) {
                    fetch_retry(data.discordWebhookCardSeen, {
                        method: "POST",
                        body: JSON.stringify({
                            content: "A card popped up",
                        }),
                        headers: {
                            "Content-Type": "application/json",
                        },
                    }, 5);
                }
            });
        }
    }
    catch (e) { }
};
/**
 * clear timer if no ID is passed or if ID matches global
 */
var clearDangerousInterval = function (intervalId) {
    if (!intervalId || intervalId === globalIntervalId) {
        clearInterval(dangerousInterval);
    }
};
var fetch_retry = function (url, options, n) {
    return fetch(url, options).catch(function (error) {
        if (n === 1)
            throw error;
        return fetch_retry(url, options, n - 1);
    });
};


/***/ }),

/***/ "./src/actions/sendToTransferList.ts":
/*!*******************************************!*\
  !*** ./src/actions/sendToTransferList.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickDetailsPanelButton_1 = __importDefault(__webpack_require__(/*! ./helpers/clickDetailsPanelButton */ "./src/actions/helpers/clickDetailsPanelButton.ts"));
function sendToTransferList() {
    var buttonText = "Send to Transfer List";
    var language = document.getElementsByTagName("html")[0].lang;
    switch (language) {
        case "fr":
            buttonText = "Env. Liste transf.";
            break;
        case "it":
            buttonText = "Invia a trasferim.";
            break;
        case "de":
            buttonText = "Auf Transferliste";
            break;
        case "pl":
            buttonText = "Wyślij na listę transferową";
            break;
        case "nl":
            buttonText = "Naar transferlijst";
            break;
        case "pt":
            buttonText = "Enviar para Transfer.";
            break;
        case "es":
            buttonText = "Enviar a transferibles";
            break;
        case "ru":
            buttonText = "Отправить в список продаж";
            break;
        case "tr":
            buttonText = "Transfer Listesi’ne Gönder";
            break;
        case "ko":
            buttonText = "이적 목록으로 보내기";
            break;
        case "da":
            buttonText = "Send til transferlisten";
            break;
    }
    try {
        clickDetailsPanelButton_1.default(buttonText);
    }
    catch (error) { }
}
exports.default = sendToTransferList;


/***/ }),

/***/ "./src/actions/storeInClub.ts":
/*!************************************!*\
  !*** ./src/actions/storeInClub.ts ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var clickDetailsPanelButton_1 = __importDefault(__webpack_require__(/*! ./helpers/clickDetailsPanelButton */ "./src/actions/helpers/clickDetailsPanelButton.ts"));
function storeInClub() {
    var buttonText = "Send to My Club";
    var language = document.getElementsByTagName("html")[0].lang;
    switch (language) {
        case "fr":
            buttonText = "Envoyer vers Mon club";
            break;
        case "it":
            buttonText = "Invia a Il mio club";
            break;
        case "de":
            buttonText = "Zu Mein Verein";
            break;
        case "pl":
            buttonText = "Wyślij do klubu";
            break;
        case "nl":
            buttonText = "Naar Mijn club sturen";
            break;
        case "pt":
            buttonText = "Enviar ao Meu clube";
            break;
        case "es":
            buttonText = "Enviar a Mi club";
            break;
        case "ru":
            buttonText = "Отправить в Мой клуб";
            break;
        case "tr":
            buttonText = "Kulübüme Gönder";
            break;
        case "ko":
            buttonText = "내 클럽으로 보내기";
            break;
        case "da":
            buttonText = "Send til Min klub";
            break;
    }
    try {
        clickDetailsPanelButton_1.default(buttonText);
    }
    catch (error) {
        //
    }
}
exports.default = storeInClub;


/***/ }),

/***/ "./src/contentScript.scss":
/*!********************************!*\
  !*** ./src/contentScript.scss ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../node_modules/css-modules-typescript-loader!../node_modules/css-loader/dist/cjs.js??ref--5-2!../node_modules/sass-loader/lib/loader.js!./contentScript.scss */ "./node_modules/css-modules-typescript-loader/index.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/sass-loader/lib/loader.js!./src/contentScript.scss");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./src/contentScript.tsx":
/*!*******************************!*\
  !*** ./src/contentScript.tsx ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var back_1 = __importDefault(__webpack_require__(/*! ./actions/back */ "./src/actions/back.ts"));
var list_1 = __importDefault(__webpack_require__(/*! ./actions/list */ "./src/actions/list.ts"));
var search_1 = __importDefault(__webpack_require__(/*! ./actions/search */ "./src/actions/search.ts"));
var sendToTransferList_1 = __importDefault(__webpack_require__(/*! ./actions/sendToTransferList */ "./src/actions/sendToTransferList.ts"));
var increaseMinBidPrice_1 = __importDefault(__webpack_require__(/*! ./actions/increaseMinBidPrice */ "./src/actions/increaseMinBidPrice.ts"));
var storeInClub_1 = __importDefault(__webpack_require__(/*! ./actions/storeInClub */ "./src/actions/storeInClub.ts"));
var isUserOnSearchResultsPage_1 = __importDefault(__webpack_require__(/*! ./actions/helpers/isUserOnSearchResultsPage */ "./src/actions/helpers/isUserOnSearchResultsPage.ts"));
var increaseMinBinPrice_1 = __importDefault(__webpack_require__(/*! ./actions/increaseMinBinPrice */ "./src/actions/increaseMinBinPrice.ts"));
var increaseMaxBinPrice_1 = __importDefault(__webpack_require__(/*! ./actions/increaseMaxBinPrice */ "./src/actions/increaseMaxBinPrice.ts"));
var decreaseMaxBinPrice_1 = __importDefault(__webpack_require__(/*! ./actions/decreaseMaxBinPrice */ "./src/actions/decreaseMaxBinPrice.ts"));
var contentScript_scss_1 = __importDefault(__webpack_require__(/*! ./contentScript.scss */ "./src/contentScript.scss"));
var onTimer = null;
var offTimer = null;
var isOn = false;
(function () {
    // fifa 22 block (10/1/21)
    var now = Date.now();
    if (now > 1633071600809) {
        alert("Thanks for using FUTgenie in FIFA 21! Please visit the store to purchase a license for FIFA 22. Cheers!");
        return;
    }
    var id = chrome.runtime.id;
    if (id !== "licncdcgncjnmkfcbmdikknkgojihecb") {
        chrome.runtime.sendMessage({
            log: true,
        });
    }
    // message listener to get current coin balance
    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.getCurrentCoinBalance) {
            var coinBalance = document.getElementsByClassName("view-navbar-currency-coins")[0].innerText;
            var normalizedCoinBalance = coinBalance.replace(/[., \u00a0\u202F]*/g, "");
            sendResponse({
                normalizedCoinBalance: normalizedCoinBalance,
            });
        }
    });
    var audio = document.createElement("audio");
    audio.id = contentScript_scss_1.default.audio;
    audio.autoplay = false;
    audio.src = "https://www.soundjay.com/buttons/sounds/button-12.mp3";
    document.documentElement.appendChild(audio);
    var loopDoneSound = document.createElement("audio");
    loopDoneSound.id = contentScript_scss_1.default.loopDoneSound;
    loopDoneSound.autoplay = false;
    loopDoneSound.src = "https://www.soundjay.com/misc/bell-ring-01.mp3";
    document.documentElement.appendChild(loopDoneSound);
    var cardSeenSound = document.createElement("audio");
    cardSeenSound.id = contentScript_scss_1.default.cardSeenSound;
    cardSeenSound.autoplay = false;
    cardSeenSound.src = "https://www.soundjay.com/buttons/sounds/button-09a.mp3";
    document.documentElement.appendChild(cardSeenSound);
    var cardPurchasedSound = document.createElement("audio");
    cardPurchasedSound.id = contentScript_scss_1.default.cardPurchasedSound;
    cardPurchasedSound.autoplay = false;
    cardPurchasedSound.src =
        "https://www.soundjay.com/mechanical/sounds/gun-gunshot-01.mp3";
    document.documentElement.appendChild(cardPurchasedSound);
    // resets badge on refresh (since it's obviously stopped)
    chrome.runtime.sendMessage({ stopAutobuyer: true });
    window.localStorage.setItem("seenCount", "0");
    window.localStorage.setItem("searchCount", "0");
    window.localStorage.setItem("purchasedCount", "0");
    console.log("Setting up event listener...");
    chrome.runtime.onMessage.addListener(function (request) {
        console.log("Listener is ready.");
        if (request.startAutobuyer) {
            window.localStorage.setItem("seenCount", "0");
            window.localStorage.setItem("searchCount", "0");
            window.localStorage.setItem("purchasedCount", "0");
            console.log("Starting autobuyer...");
            var playerNameInput = document
                .getElementsByClassName("ut-player-search-control")[0]
                .getElementsByTagName("input")[0];
            if (playerNameInput && playerNameInput.value === "") {
                var retVal = confirm("Player name input is empty. Are you sure you want to start the autobuyer?");
                if (!retVal) {
                    stopAutobuyer("Autobuyer didn't get started. That was a close one!", true);
                    return;
                }
            }
            var maxBinInput = document.getElementsByClassName("numericInput")[3];
            if (maxBinInput.value === "") {
                var retVal = confirm("The max buy now price is empty. Are you sure you want to start the autobuyer?");
                if (!retVal) {
                    stopAutobuyer("Autobuyer didn't get started. That was a close one!", true);
                    return;
                }
            }
            var resetPoint = request.resetPoint, action = request.action, iterationTime = request.iterationTime, iterationTimeMax = request.iterationTimeMax, listStartPrice = request.listStartPrice, listBinPrice = request.listBinPrice, isTestRun = request.isTestRun, cycles = request.cycles, onInterval = request.onInterval, offInterval = request.offInterval, maxBuyNowPrice = request.maxBuyNowPrice, minimumCoinBalance = request.minimumCoinBalance;
            // Get initial min BIN set by user
            var initialMinBin = document.getElementsByClassName("numericInput")[2].value;
            var initialMinBinNumber = parseInt(initialMinBin.replace(/[., \u00a0\u202F]*/g, "")) || 0;
            // Determine reset price
            var maxPurchasePrice = initialMinBinNumber || resetPoint;
            var resetPrice = getMaxBidPrice(maxPurchasePrice);
            // Get initial max BIN set by user
            var initialMaxBin = document.getElementsByClassName("numericInput")[3].value;
            var initialMaxBinNumber = parseInt(initialMaxBin.replace(/[., \u00a0\u202F]*/g, "")) || 0;
            if (initialMaxBinNumber <= resetPrice) {
                stopAutobuyer('Your "Reset price" must be less than the max BIN price of your sniping filter.', true);
                return;
            }
            createCycle({
                currCycle: 0,
                totalCycles: cycles,
                onInterval: onInterval,
                offInterval: offInterval,
                isTestRun: isTestRun,
                action: action,
                listStartPrice: listStartPrice,
                listBinPrice: listBinPrice,
                iterationTime: iterationTime,
                iterationTimeMax: iterationTimeMax,
                resetPrice: resetPrice,
                userSetMinBin: initialMinBinNumber > 0,
                maxBuyNowPrice: maxBuyNowPrice,
                initialMaxBin: initialMaxBinNumber,
                minimumCoinBalance: minimumCoinBalance,
            });
        }
        else if (request.stopAutobuyerFromPopup) {
            stopAutobuyer("Autobuyer stopped because you stopped it.");
        }
    });
    // Event listener to stop autobuyer on demand
    window.addEventListener("keydown", function (ev) {
        // If user is typing in an input, ignore hotkeys.
        if (document.activeElement.tagName.toLowerCase() === "input") {
            return;
        }
        if (ev.keyCode === 32 && ev.shiftKey) {
            if (isOn || onTimer || offTimer) {
                stopAutobuyer("Autobuyer stopped because you stopped it.");
            }
            else {
                chrome.storage.sync.get([
                    "resetPoint",
                    "duration",
                    "action",
                    "iterationTime",
                    "iterationTimeMax",
                    "listStartPrice",
                    "listBinPrice",
                    "cycles",
                    "onInterval",
                    "offInterval",
                    "maxBuyNowPrice",
                    "minimumCoinBalance",
                ], function (data) {
                    var resetPoint = data.resetPoint, duration = data.duration, action = data.action, iterationTime = data.iterationTime, iterationTimeMax = data.iterationTimeMax, listStartPrice = data.listStartPrice, listBinPrice = data.listBinPrice, cycles = data.cycles, onInterval = data.onInterval, offInterval = data.offInterval, maxBuyNowPrice = data.maxBuyNowPrice, minimumCoinBalance = data.minimumCoinBalance;
                    chrome.runtime.sendMessage({
                        startAutobuyer: true,
                        resetPoint: parseInt(resetPoint),
                        duration: duration,
                        action: action,
                        iterationTime: iterationTime,
                        iterationTimeMax: iterationTimeMax,
                        listStartPrice: listStartPrice,
                        listBinPrice: listBinPrice,
                        isTestRun: false,
                        cycles: parseInt(cycles),
                        onInterval: parseInt(onInterval),
                        offInterval: parseInt(offInterval),
                        maxBuyNowPrice: parseInt(maxBuyNowPrice),
                        minimumCoinBalance: minimumCoinBalance,
                    });
                });
            }
        }
    });
})();
var stopAutobuyer = function (reason, skipCheck) {
    if (skipCheck === void 0) { skipCheck = false; }
    if (isOn || onTimer || offTimer || skipCheck) {
        isOn = false;
        clearTimeout(onTimer);
        onTimer = null;
        clearTimeout(offTimer);
        offTimer = null;
        chrome.runtime.sendMessage({ stopAutobuyer: true });
        var searchCount = window.localStorage.getItem("searchCount");
        var seenCount = window.localStorage.getItem("seenCount");
        var purchasedCount = window.localStorage.getItem("purchasedCount");
        alert(reason + " (" + searchCount + " searches, " + seenCount + " cards seen, " + purchasedCount + " cards bought)");
    }
};
var randomize = function () {
    var min = 0;
    var max = 50;
    return Math.floor(Math.random() * (max - min + 1) + min);
};
var getMaxBidPrice = function (maxPurchasePrice) {
    if (maxPurchasePrice <= 1000) {
        return maxPurchasePrice - 50;
    }
    else if (maxPurchasePrice <= 10000) {
        return maxPurchasePrice - 100;
    }
    else if (maxPurchasePrice <= 100000) {
        return maxPurchasePrice - 500;
    }
    else {
        return maxPurchasePrice - 1000;
    }
};
var createCycle = function (params) {
    var currCycle = params.currCycle, totalCycles = params.totalCycles, onInterval = params.onInterval, offInterval = params.offInterval, isTestRun = params.isTestRun, action = params.action, listStartPrice = params.listStartPrice, listBinPrice = params.listBinPrice, iterationTime = params.iterationTime, iterationTimeMax = params.iterationTimeMax, resetPrice = params.resetPrice, userSetMinBin = params.userSetMinBin, maxBuyNowPrice = params.maxBuyNowPrice, initialMaxBin = params.initialMaxBin, minimumCoinBalance = params.minimumCoinBalance;
    var onIntervalMinutes = onInterval * 60000;
    var offIntervalMinutes = offInterval * 60000;
    isOn = true;
    // set initial coin balance
    var coinBalance = document.getElementsByClassName("view-navbar-currency-coins")[0].innerText;
    var normalizedCoinBalance = coinBalance.replace(/[., \u00a0\u202F]*/g, "");
    window.localStorage.setItem("previousCoinBalance", normalizedCoinBalance);
    moneyFunction(params);
    var randomModifier = randomize();
    // Start a timer that stops "on" loop after specified time
    onTimer = setTimeout(function () {
        isOn = false;
        chrome.storage.sync.get("shouldPlayLoopDoneSound", function (data) {
            if (data.shouldPlayLoopDoneSound) {
                var loopDoneSound = document.getElementById(contentScript_scss_1.default.loopDoneSound);
                loopDoneSound.play();
            }
            if (currCycle === totalCycles - 1) {
                stopAutobuyer("Autobuyer stopped because it completed the number of requested cycles.");
            }
        });
    }, onIntervalMinutes + randomModifier);
    // Start a timer that restarts "on" loop after specificied time
    offTimer = setTimeout(function () {
        if (currCycle < totalCycles - 1) {
            createCycle({
                currCycle: currCycle + 1,
                totalCycles: totalCycles,
                onInterval: onInterval,
                offInterval: offInterval,
                isTestRun: isTestRun,
                action: action,
                listStartPrice: listStartPrice,
                listBinPrice: listBinPrice,
                iterationTime: iterationTime,
                iterationTimeMax: iterationTimeMax,
                resetPrice: resetPrice,
                userSetMinBin: userSetMinBin,
                maxBuyNowPrice: maxBuyNowPrice,
                initialMaxBin: initialMaxBin,
                minimumCoinBalance: minimumCoinBalance,
            });
        }
    }, onIntervalMinutes + randomModifier + offIntervalMinutes);
};
var moneyFunction = function (params) {
    var isTestRun = params.isTestRun, action = params.action, listStartPrice = params.listStartPrice, listBinPrice = params.listBinPrice, iterationTime = params.iterationTime, iterationTimeMax = params.iterationTimeMax, resetPrice = params.resetPrice, userSetMinBin = params.userSetMinBin, maxBuyNowPrice = params.maxBuyNowPrice, initialMaxBin = params.initialMaxBin, minimumCoinBalance = params.minimumCoinBalance;
    var iterationTimeReal = getInterval(iterationTime, iterationTimeMax);
    // check for captcha
    var isAlertPresent = document.getElementsByClassName("ui-dialog-type-alert").length > 0;
    if (isAlertPresent) {
        chrome.storage.sync.get("shouldPlayCaptchaSound", function (data) {
            if (data.shouldPlayCaptchaSound) {
                var audio = document.getElementById(contentScript_scss_1.default.audio);
                audio.play();
            }
            chrome.runtime.sendMessage({
                alert: true,
            });
            stopAutobuyer("Autobuyer stopped because human verification is required by EA.");
        });
        return;
    }
    // check for coin balance
    var coinBalance = document.getElementsByClassName("view-navbar-currency-coins")[0].innerText;
    var normalizedCoinBalance = coinBalance.replace(/[., ]*/g, "");
    // get previous coin balance from storage
    var previousCoinBalance = window.localStorage.getItem("previousCoinBalance");
    if (normalizedCoinBalance < minimumCoinBalance) {
        stopAutobuyer("Autobuyer stopped because your coin balance has fallen beneath the minimum coin balance threshold you set.");
        return;
    }
    else if (previousCoinBalance !== normalizedCoinBalance) {
        var justSawCard = window.localStorage.getItem("justSawCard");
        /**
         * if the card balance is different than before we searched, and we just
         * saw a card, we can reasonably assume a card was purchased
         */
        if (justSawCard === "true") {
            var oldCount = window.localStorage.getItem("purchasedCount");
            var newCount = oldCount ? parseInt(oldCount) + 1 : 1;
            window.localStorage.setItem("purchasedCount", newCount.toString());
            chrome.storage.sync.get(["shouldPlayCardPurchasedSound", "discordWebhookCardPurchased"], function (data) {
                if (data.shouldPlayCardPurchasedSound) {
                    var cardPurchasedSound = document.getElementById(contentScript_scss_1.default.cardPurchasedSound);
                    cardPurchasedSound.play();
                }
                if (data.discordWebhookCardPurchased) {
                    fetch_retry(data.discordWebhookCardPurchased, {
                        method: "POST",
                        body: JSON.stringify({
                            content: "A card was (probably) bought",
                        }),
                        headers: {
                            "Content-Type": "application/json",
                        },
                    }, 5);
                }
            });
        }
    }
    // resets this check before we search again
    window.localStorage.setItem("justSawCard", "false");
    search_1.default(!isTestRun);
    setTimeout(function () {
        setTimeout(function () {
            try {
                if (action === "list") {
                    list_1.default(listStartPrice, listBinPrice);
                }
                else if (action === "transfer") {
                    sendToTransferList_1.default();
                }
                else if (action === "club") {
                    storeInClub_1.default();
                }
                else if (action === "none" || !action) {
                    // do nothing
                }
            }
            catch (e) { }
            setTimeout(function () {
                if (isUserOnSearchResultsPage_1.default()) {
                    back_1.default();
                }
            }, 200);
        }, 300);
        setTimeout(function () {
            if (userSetMinBin) {
                var minBidInput = document.getElementsByClassName("numericInput")[0];
                var currentMinBid = parseInt(minBidInput.value.replace(/[., \u00a0\u202F]*/g, "")) || 0;
                // If current min bid is greater than resetPrice, reset.
                if (currentMinBid >= resetPrice) {
                    minBidInput.value = "";
                    changeMaxBin(initialMaxBin, maxBuyNowPrice);
                }
                increaseMinBidPrice_1.default();
            }
            else {
                var minBinInput = document.getElementsByClassName("numericInput")[2];
                var currentMinBin = parseInt(minBinInput.value.replace(/[., \u00a0\u202F]*/g, "")) || 0;
                // If current min BIN is greater than resetPrice, reset.
                if (currentMinBin >= resetPrice) {
                    minBinInput.value = "";
                    changeMaxBin(initialMaxBin, maxBuyNowPrice);
                }
                increaseMinBinPrice_1.default();
            }
            if (isOn) {
                moneyFunction(params);
            }
        }, 900);
    }, iterationTimeReal);
};
/**
 * Changes "max BIN" price in search filter
 *
 * @param initialMaxBin Max BIN set in the original filter
 * @param maxBuyNowPrice The price set by the user in the pop-up
 */
var changeMaxBin = function (initialMaxBin, maxBuyNowPrice) {
    if (maxBuyNowPrice <= initialMaxBin) {
        return;
    }
    var maxBinInput = document.getElementsByClassName("numericInput")[3];
    var currentMaxBin = parseInt(maxBinInput.value.replace(/[., \u00a0\u202F]*/g, "")) || 0;
    if (currentMaxBin === 0) {
        return;
    }
    if (currentMaxBin >= maxBuyNowPrice) {
        maxBinInput.value = initialMaxBin.toString();
        increaseMaxBinPrice_1.default();
        decreaseMaxBinPrice_1.default();
    }
    else {
        increaseMaxBinPrice_1.default();
    }
};
function getInterval(iterationTime, iterationTimeMax) {
    var min = parseInt(iterationTime);
    var max = parseInt(iterationTimeMax);
    return Math.floor(Math.random() * (max - min + 1) + min);
}
var fetch_retry = function (url, options, n) {
    return fetch(url, options).catch(function (error) {
        if (n === 1)
            throw error;
        return fetch_retry(url, options, n - 1);
    });
};


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvY29udGVudFNjcmlwdC5zY3NzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvbGliL2FkZFN0eWxlcy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2xpYi91cmxzLmpzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2JhY2sudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvYnV5Tm93LnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2RlY3JlYXNlTWF4QmluUHJpY2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9jbGlja0RldGFpbHNQYW5lbEJ1dHRvbi50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYWN0aW9ucy9oZWxwZXJzL2NsaWNrRWxlbWVudC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYWN0aW9ucy9oZWxwZXJzL2NvbmZpcm1Db25maXJtYXRpb25EaWFsb2cudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9nZXRMaXN0SXRlbUJ1dHRvblRleHQudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9nZXRMaXN0SXRlbXMudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblBhZ2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlLnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2hlbHBlcnMvaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblRyYW5zZmVyVGFyZ2V0c1BhZ2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblRyYW5zZmVyc1BhZ2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaGVscGVycy9pc1VzZXJPblVuYXNzaWduZWRQYWdlLnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2luY3JlYXNlTWF4QmluUHJpY2UudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvaW5jcmVhc2VNaW5CaWRQcmljZS50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYWN0aW9ucy9pbmNyZWFzZU1pbkJpblByaWNlLnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL2xpc3QudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2FjdGlvbnMvc2VhcmNoLnRzIiwid2VicGFjazovLy8uL3NyYy9hY3Rpb25zL3NlbmRUb1RyYW5zZmVyTGlzdC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYWN0aW9ucy9zdG9yZUluQ2x1Yi50cyIsIndlYnBhY2s6Ly8vLi9zcmMvY29udGVudFNjcmlwdC5zY3NzPzY1MTUiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnRlbnRTY3JpcHQudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNsRmE7O0FBRWI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCOztBQUVoQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQSx1Q0FBdUMsZ0JBQWdCO0FBQ3ZELE9BQU87QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMLElBQUk7OztBQUdKO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBLG1CQUFtQixpQkFBaUI7QUFDcEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsZUFBZSxvQkFBb0I7QUFDbkMsNEJBQTRCO0FBQzVCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBLENBQUM7OztBQUdEO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxjQUFjO0FBQ25FO0FBQ0EsQzs7Ozs7Ozs7Ozs7QUNwRkEsMkJBQTJCLG1CQUFPLENBQUMscUdBQWdEO0FBQ25GO0FBQ0EsY0FBYyxRQUFTLDhHQUE4RyxrQkFBa0IsRUFBRTs7QUFFeko7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRTs7Ozs7Ozs7Ozs7QUNWQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOENBQThDO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBOztBQUVBLGNBQWMsbUJBQU8sQ0FBQyx1REFBUTs7QUFFOUI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBLGlCQUFpQixtQkFBbUI7QUFDcEM7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsaUJBQWlCLHNCQUFzQjtBQUN2Qzs7QUFFQTtBQUNBLG1CQUFtQiwyQkFBMkI7O0FBRTlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxnQkFBZ0IsbUJBQW1CO0FBQ25DO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSxpQkFBaUIsMkJBQTJCO0FBQzVDO0FBQ0E7O0FBRUEsUUFBUSx1QkFBdUI7QUFDL0I7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQSxpQkFBaUIsdUJBQXVCO0FBQ3hDO0FBQ0E7O0FBRUEsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUEsZ0JBQWdCLGlCQUFpQjtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYzs7QUFFZCxrREFBa0Qsc0JBQXNCO0FBQ3hFO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsdURBQXVEO0FBQ3ZEOztBQUVBLDZCQUE2QixtQkFBbUI7O0FBRWhEOztBQUVBOztBQUVBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN0WEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLFdBQVcsRUFBRTtBQUNyRCx3Q0FBd0MsV0FBVyxFQUFFOztBQUVyRDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLHNDQUFzQztBQUN0QyxHQUFHO0FBQ0g7QUFDQSw4REFBOEQ7QUFDOUQ7O0FBRUE7QUFDQTtBQUNBLEVBQUU7O0FBRUY7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4RkEsaUlBQWtEO0FBQ2xELGlJQUFrRDtBQUNsRCx3S0FBNEU7QUFDNUUsNkxBQTBGO0FBQzFGLDRKQUFvRTtBQUNwRSw4S0FBZ0Y7QUFDaEYsK0pBQXNFO0FBRXRFLFNBQXdCLE1BQU07SUFDMUIsNENBQTRDO0lBQzVDLElBQU0sZUFBZSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDbkQsd0JBQXdCLENBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFTCxJQUFJLGVBQWUsSUFBSSxlQUFlLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDdEUsc0JBQVksQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoRSxPQUFPO0tBQ1Y7SUFFRCx5Q0FBeUM7SUFDekMsSUFDSSwwQ0FBZ0MsRUFBRTtRQUNsQyxtQ0FBeUIsRUFBRTtRQUMzQixnQ0FBc0IsRUFBRTtRQUN4QiwrQkFBcUIsRUFBRTtRQUN2QixxQ0FBMkIsRUFBRSxFQUMvQjtRQUNFLElBQUksbUNBQXlCLEVBQUUsRUFBRTtZQUM3QixJQUFNLGdCQUFnQixHQUFHLHNCQUFZLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBRW5ELHFEQUFxRDtZQUNyRCxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ25CLHNCQUFZLENBQ1IsUUFBUSxDQUFDLHNCQUFzQixDQUMzQiw4QkFBOEIsQ0FDakMsQ0FBQyxDQUFDLENBQUMsQ0FDUCxDQUFDO2dCQUNGLE9BQU87YUFDVjtZQUVELHdGQUF3RjtZQUN4RixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUMsRUFBRSxjQUFJO2dCQUNuRCxrQkFBYyxHQUFrQixJQUFJLGVBQXRCLEVBQUUsV0FBVyxHQUFLLElBQUksWUFBVCxDQUFVO2dCQUU3QyxJQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQ3ZCLElBQU0sZUFBZSxHQUFHLEdBQUcsR0FBRyxDQUFDLGNBQWMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFFcEQsSUFBSSxlQUFlLEdBQUcsSUFBSSxJQUFJLFdBQVcsRUFBRTtvQkFDdkMsT0FBTztpQkFDVjtxQkFBTTtvQkFDSCxzQkFBWSxDQUNSLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDM0IsOEJBQThCLENBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQ1AsQ0FBQztpQkFDTDtZQUNMLENBQUMsQ0FBQyxDQUFDO1NBQ047YUFBTTtZQUNILHNCQUFZLENBQ1IsUUFBUSxDQUFDLHNCQUFzQixDQUMzQiw4QkFBOEIsQ0FDakMsQ0FBQyxDQUFDLENBQUMsQ0FDUCxDQUFDO1NBQ0w7S0FDSjtBQUNMLENBQUM7QUF6REQseUJBeURDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRUQsd0tBQTRFO0FBQzVFLHdLQUE0RTtBQUM1RSxpSUFBa0Q7QUFFbEQsU0FBd0IsTUFBTTtJQUMxQixJQUFJLG1DQUF5QixFQUFFLEVBQUU7UUFDN0IsSUFBSTtZQUNBLE9BQU8sRUFBRSxDQUFDO1NBQ2I7UUFBQyxPQUFPLEtBQUssRUFBRSxHQUFFO0tBQ3JCO0FBQ0wsQ0FBQztBQU5ELHlCQU1DO0FBRUQsU0FBUyxPQUFPO0lBQ1osaUJBQWlCLEVBQUUsQ0FBQztJQUVwQixJQUFNLEtBQUssR0FBRyxXQUFXLENBQUM7UUFDdEIsbUNBQXlCLENBQUM7WUFDdEIsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQztBQUVELFNBQVMsaUJBQWlCO0lBQ3RCLElBQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMvRCxzQkFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3pCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCRCxpSUFBa0Q7QUFDbEQsNkxBQTBGO0FBRTFGLFNBQXdCLG1CQUFtQjtJQUN2QyxJQUFJLDBDQUFnQyxFQUFFLEVBQUU7UUFDcEMsSUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDckUsc0JBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUN4QjtBQUNMLENBQUM7QUFMRCxzQ0FLQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUkQseUhBQTBDO0FBRTFDLFNBQXdCLHVCQUF1QixDQUFDLFdBQW1CO0lBQy9ELElBQUk7UUFDQSw0Q0FBNEM7UUFDNUMsSUFBSSxXQUFXLEtBQUssV0FBVyxFQUFFO1lBQzdCLElBQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN6RCxJQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3JDLEtBQXFCLFVBQU8sRUFBUCxtQkFBTyxFQUFQLHFCQUFPLEVBQVAsSUFBTyxFQUFFO2dCQUF6QixJQUFNLE1BQU07Z0JBQ2IsSUFDSSxNQUFNO29CQUNOLE1BQU0sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQzFEO29CQUNFLHNCQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRXJCLFVBQVUsQ0FBQzt3QkFDUCxvQ0FBb0M7d0JBQ3BDLElBQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDaEQsYUFBYSxDQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNMLElBQU0sbUJBQW1CLEdBQUcsWUFBWSxDQUFDLG9CQUFvQixDQUN6RCxRQUFRLENBQ1gsQ0FBQzt3QkFDRixJQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7d0JBRXBELDRDQUE0Qzt3QkFDNUMsSUFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FDOUIsa0JBQVE7NEJBQ0osZUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dDQUM1QyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sS0FBSyxNQUFNO3dCQURqQyxDQUNpQyxDQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUVMLHVCQUF1Qjt3QkFDdkIsc0JBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDMUIsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUVULE9BQU87aUJBQ1Y7YUFDSjtTQUNKO1FBRUQsb0NBQW9DO1FBQ3BDLElBQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2RSxJQUFNLG1CQUFtQixHQUFHLFlBQVksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN4RSxJQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFFcEQsNENBQTRDO1FBQzVDLElBQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQzlCLGFBQUc7WUFDQyxVQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3ZDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLE1BQU07UUFENUIsQ0FDNEIsQ0FDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVMLHVCQUF1QjtRQUN2QixzQkFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQ3pCO0lBQUMsT0FBTyxLQUFLLEVBQUU7UUFDWixNQUFNLDZCQUE2QixDQUFDO0tBQ3ZDO0FBQ0wsQ0FBQztBQXhERCwwQ0F3REM7Ozs7Ozs7Ozs7Ozs7OztBQzFERDs7R0FFRztBQUNILFNBQXdCLFlBQVksQ0FBQyxPQUFPO0lBQ3hDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDdEMsY0FBYyxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN4QyxDQUFDO0FBSEQsK0JBR0M7QUFFRDs7Ozs7O0dBTUc7QUFDSCxTQUFTLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUztJQUN0Qzs7O09BR0c7SUFDSCxhQUFhO0lBQ2IsSUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLENBQUM7UUFDcEIsd0RBQXdEO1FBQ3hELGFBQWE7UUFDYixVQUFVLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsRUFBRTtRQUNwQyxNQUFNLEVBQUUsT0FBTztRQUNmLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ3RCLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ3RCLE9BQU8sRUFBRSxHQUFHO1FBQ1osT0FBTyxFQUFFLEdBQUc7UUFDWixhQUFhLEVBQUUsRUFBRTtRQUNqQixLQUFLLEVBQUUsR0FBRztLQUNiLENBQUMsQ0FBQztJQUVILElBQU0sVUFBVSxHQUFHLElBQUksVUFBVSxDQUFDLFNBQVMsRUFBRTtRQUN6QyxVQUFVLEVBQUUsSUFBSTtRQUNoQixPQUFPLEVBQUUsSUFBSTtRQUNiLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQztRQUNoQixhQUFhLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFDdEIsY0FBYyxFQUFFLENBQUMsS0FBSyxDQUFDO1FBQ3ZCLFFBQVEsRUFBRSxJQUFJO0tBQ2pCLENBQUMsQ0FBQztJQUVILE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUNELHlIQUEwQztBQUUxQzs7R0FFRztBQUNILFNBQXdCLHlCQUF5QixDQUFDLE9BQW9CO0lBQ2xFLElBQUk7UUFDQSxJQUFNLFFBQVEsR0FBRyxRQUFRO2FBQ3BCLHNCQUFzQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNuQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxzQkFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3ZCLE9BQU8sSUFBSSxPQUFPLEVBQUUsQ0FBQztLQUN4QjtJQUFDLE9BQU8sS0FBSyxFQUFFLEdBQUU7QUFDdEIsQ0FBQztBQVJELDRDQVFDOzs7Ozs7Ozs7Ozs7Ozs7QUNiRCxTQUF3QixxQkFBcUI7SUFDM0MsSUFBSSxVQUFVLEdBQUcsbUJBQW1CLENBQUM7SUFDckMsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUUvRCxRQUFRLFFBQVEsRUFBRTtRQUNoQixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsaUNBQWlDLENBQUM7WUFDL0MsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxtQkFBbUIsQ0FBQztZQUNqQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLFVBQVUsQ0FBQztZQUN4QixNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHFCQUFxQixDQUFDO1lBQ25DLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsMkJBQTJCLENBQUM7WUFDekMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRywyQkFBMkIsQ0FBQztZQUN6QyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHdCQUF3QixDQUFDO1lBQ3RDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsc0JBQXNCLENBQUM7WUFDcEMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyx1QkFBdUIsQ0FBQztZQUNyQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLFlBQVksQ0FBQztZQUMxQixNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHVCQUF1QixDQUFDO1lBQ3JDLE1BQU07S0FDVDtJQUVELE9BQU8sVUFBVSxDQUFDO0FBQ3BCLENBQUM7QUF6Q0Qsd0NBeUNDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6Q0QsZ0tBQW9FO0FBQ3BFLHVKQUE4RDtBQUM5RCxvSkFBNEQ7QUFFNUQsU0FBd0IsWUFBWTtJQUNoQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7SUFFZixJQUFJLG1DQUF5QixFQUFFLEVBQUU7UUFDN0IsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUM1QyxxQkFBcUIsQ0FDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNMLEtBQUssR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO0tBQ3RFO1NBQU0sSUFBSSxnQ0FBc0IsRUFBRSxJQUFJLCtCQUFxQixFQUFFLEVBQUU7UUFDNUQsSUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FDeEIsUUFBUSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsQ0FBQyxDQUM5QyxDQUFDO1FBQ0YsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFTLFFBQVE7WUFDL0IsS0FBSyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQ2hCLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQzdELENBQUM7UUFDTixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDWjtTQUFNO1FBQ0gsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUM1QyxxQkFBcUIsQ0FDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNMLEtBQUssR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO0tBQ3RFO0lBRUQsT0FBTyxLQUFLLENBQUM7QUFDakIsQ0FBQztBQXpCRCwrQkF5QkM7Ozs7Ozs7Ozs7Ozs7OztBQzdCRDs7R0FFRztBQUNILFNBQXdCLFlBQVksQ0FBQyxTQUFpQjtJQUNsRCxJQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDMUQsT0FBTyxLQUFLLElBQUksS0FBSyxDQUFDLFNBQVMsS0FBSyxTQUFTLENBQUM7QUFDbEQsQ0FBQztBQUhELCtCQUdDOzs7Ozs7Ozs7Ozs7Ozs7QUNORCxTQUF3Qix5QkFBeUI7SUFDN0MsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQ2xFLE9BQU8sUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDL0IsQ0FBQztBQUhELDRDQUdDOzs7Ozs7Ozs7Ozs7Ozs7QUNIRCxTQUF3QixnQ0FBZ0M7SUFDcEQsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUM1QywrQkFBK0IsQ0FDbEMsQ0FBQztJQUVGLElBQU0sVUFBVSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUUxRCxPQUFPLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO0FBQzFELENBQUM7QUFSRCxtREFRQzs7Ozs7Ozs7Ozs7Ozs7O0FDUkQsU0FBd0IsMkJBQTJCO0lBQy9DLElBQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ3ZFLE9BQU8sUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDL0IsQ0FBQztBQUhELDhDQUdDOzs7Ozs7Ozs7Ozs7Ozs7QUNIRCxTQUF3QixxQkFBcUI7SUFDekMsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFDMUUsT0FBTyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUMvQixDQUFDO0FBSEQsd0NBR0M7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0hELHlIQUEwQztBQUUxQyxTQUF3QixzQkFBc0I7SUFDMUMsT0FBTztJQUNILFVBQVU7SUFDVixzQkFBWSxDQUFDLFlBQVksQ0FBQztRQUMxQixTQUFTO1FBQ1Qsc0JBQVksQ0FBQyxlQUFlLENBQUM7UUFDN0IsVUFBVTtRQUNWLHNCQUFZLENBQUMsZUFBZSxDQUFDO1FBQzdCLFNBQVM7UUFDVCxzQkFBWSxDQUFDLGtCQUFrQixDQUFDO1FBQ2hDLFNBQVM7UUFDVCxzQkFBWSxDQUFDLGVBQWUsQ0FBQztRQUM3QixRQUFRO1FBQ1Isc0JBQVksQ0FBQyxnQkFBZ0IsQ0FBQztRQUM5QixhQUFhO1FBQ2Isc0JBQVksQ0FBQyxnQkFBZ0IsQ0FBQztRQUM5QixVQUFVO1FBQ1Ysc0JBQVksQ0FBQyxjQUFjLENBQUM7UUFDNUIsVUFBVTtRQUNWLHNCQUFZLENBQUMsY0FBYyxDQUFDO1FBQzVCLFVBQVU7UUFDVixzQkFBWSxDQUFDLFdBQVcsQ0FBQztRQUN6QixTQUFTO1FBQ1Qsc0JBQVksQ0FBQyxTQUFTLENBQUMsQ0FDMUIsQ0FBQztBQUNOLENBQUM7QUF6QkQseUNBeUJDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQkQsaUlBQWtEO0FBQ2xELDZMQUEwRjtBQUUxRixTQUF3QixtQkFBbUI7SUFDdkMsSUFBSSwwQ0FBZ0MsRUFBRSxFQUFFO1FBQ3BDLElBQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JFLHNCQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDeEI7QUFDTCxDQUFDO0FBTEQsc0NBS0M7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1JELGlJQUFrRDtBQUVsRCxTQUF3QixtQkFBbUI7SUFDdkMsSUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDckUsc0JBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QixDQUFDO0FBSEQsc0NBR0M7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0xELGlJQUFrRDtBQUNsRCw2TEFBMEY7QUFFMUYsU0FBd0IsbUJBQW1CO0lBQ3ZDLElBQUksMENBQWdDLEVBQUUsRUFBRTtRQUNwQyxJQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyRSxzQkFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0tBQ3hCO0FBQ0wsQ0FBQztBQUxELHNDQUtDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNSRCxpSUFBa0Q7QUFDbEQsNEpBQW9FO0FBRXBFLFNBQXdCLElBQUksQ0FBQyxVQUFrQixFQUFFLFdBQW1CO0lBQ2hFLElBQU0sY0FBYyxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUV6RSxJQUFNLHFCQUFxQixHQUFHLGNBQWMsQ0FBQyxzQkFBc0IsQ0FDL0QsY0FBYyxDQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRUwsSUFBTSxVQUFVLEdBQUcscUJBQXFCLENBQUMsc0JBQXNCLENBQzNELGdCQUFnQixDQUNuQixDQUFDO0lBRUYsSUFBSSxVQUFVLEVBQUU7UUFDWixJQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDcEMsSUFBTSxlQUFlLEdBQUcsYUFBYSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZFLGVBQWUsQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDO0tBQ3RDO0lBRUQsSUFBSSxXQUFXLEVBQUU7UUFDYixJQUFNLE1BQU0sR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsSUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pELFFBQVEsQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO0tBQzNDO0lBRUQsd0RBQXdEO0lBQ3hELElBQU0sUUFBUSxHQUFHLHFCQUFxQixDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3RFLElBQU0sT0FBTyxHQUFrQixLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBRXBELG1EQUFtRDtJQUNuRCxJQUFJLGNBQWMsQ0FBQztJQUNuQixJQUFNLFVBQVUsR0FBRywrQkFBcUIsRUFBRSxDQUFDO0lBQzNDLEtBQXFCLFVBQU8sRUFBUCxtQkFBTyxFQUFQLHFCQUFPLEVBQVAsSUFBTyxFQUFFO1FBQXpCLElBQU0sTUFBTTtRQUNiLElBQUksTUFBTSxJQUFJLE1BQU0sQ0FBQyxTQUFTLEtBQUssVUFBVSxFQUFFO1lBQzNDLGNBQWMsR0FBRyxNQUFNLENBQUM7U0FDM0I7S0FDSjtJQUVELHNCQUFZLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDakMsQ0FBQztBQXJDRCx1QkFxQ0M7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hDRCwrRkFBOEI7QUFDOUIsaUlBQWtEO0FBQ2xELGlJQUFrRDtBQUNsRCw2TEFBMEY7QUFDMUYseUhBQTJDO0FBRTNDLElBQUksaUJBQWlCLEdBQUcsSUFBSSxDQUFDO0FBQzdCLElBQUksZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO0FBRXpCLFNBQXdCLE1BQU0sQ0FBQyxjQUF1QjtJQUNwRCxJQUFJLENBQUMsMENBQWdDLEVBQUUsRUFBRTtRQUN2QyxPQUFPO0tBQ1I7SUFFRCwrQ0FBK0M7SUFDL0Msc0JBQXNCLEVBQUUsQ0FBQztJQUV6QixJQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQ2xELDZCQUE2QixDQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRUwsc0JBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUUzQixJQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNsRSxJQUFNLGNBQWMsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN6RSxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsY0FBYyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7SUFFdEUsSUFBSSxjQUFjLEtBQUssQ0FBQyxFQUFFO1FBQ3hCLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLEVBQUUsVUFBQyxJQUFJO1lBQ3ZELElBQUksSUFBSSxDQUFDLHNCQUFzQixFQUFFO2dCQUMvQixpREFBaUQ7YUFDbEQ7UUFDSCxDQUFDLENBQUMsQ0FBQztLQUNKO0lBRUQsdUNBQXVDO0lBQ3ZDLGdCQUFnQixHQUFHLGdCQUFnQixHQUFHLENBQUMsQ0FBQztJQUN4QyxJQUFNLFdBQVcsR0FBRyxnQkFBZ0IsQ0FBQztJQUVyQyxpQkFBaUIsR0FBRyxXQUFXLENBQUM7UUFDOUIsSUFBSTtZQUNGLElBQU0sZ0JBQWdCLEdBQUcsc0JBQVksRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFDbkQsSUFBTSxlQUFlLEdBQ25CLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFFbkUsSUFBSSxnQkFBZ0IsSUFBSSxlQUFlLEVBQUU7Z0JBQ3ZDLElBQUk7b0JBQ0YsSUFBTSxLQUFLLEdBQUcsc0JBQVksRUFBRSxDQUFDO29CQUM3QixzQkFBWSxDQUNWLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUM1QyxrQkFBa0IsQ0FDbkIsQ0FBQyxDQUFDLENBQUMsQ0FDTCxDQUFDO2lCQUNIO2dCQUFDLE9BQU8sS0FBSyxFQUFFLEdBQUU7Z0JBRWxCLElBQUksY0FBYyxFQUFFO29CQUNsQixVQUFVLENBQUM7d0JBQ1QsWUFBWSxFQUFFLENBQUM7b0JBQ2pCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDUjtnQkFFRCw0Q0FBNEM7Z0JBQzVDLHNCQUFzQixFQUFFLENBQUM7YUFDMUI7U0FDRjtRQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUU7SUFDaEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRU4sNENBQTRDO0lBQzVDLFVBQVUsQ0FBQztRQUNULHNCQUFzQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3RDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUNYLENBQUM7QUE5REQseUJBOERDO0FBRUQsSUFBTSxZQUFZLEdBQUc7SUFDbkIsSUFBSTtRQUNGLElBQU0sa0JBQWtCLEdBQ3RCLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBRTFELElBQUksa0JBQWtCLEVBQUU7WUFDdEIsZ0JBQU0sRUFBRSxDQUFDO1lBRVQsd0JBQXdCO1lBQ3hCLElBQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzFELElBQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZELE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztZQUU5RCwyREFBMkQ7WUFDM0QsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRW5ELE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDckIsQ0FBQywyQkFBMkIsRUFBRSx3QkFBd0IsQ0FBQyxFQUN2RCxVQUFDLElBQUk7Z0JBQ0gsSUFBSSxJQUFJLENBQUMseUJBQXlCLEVBQUU7b0JBQ2xDLElBQU0sYUFBYSxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQzNDLDRCQUFNLENBQUMsYUFBYSxDQUNELENBQUM7b0JBQ3RCLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztpQkFDdEI7Z0JBRUQsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7b0JBQy9CLFdBQVcsQ0FDVCxJQUFJLENBQUMsc0JBQXNCLEVBQzNCO3dCQUNFLE1BQU0sRUFBRSxNQUFNO3dCQUNkLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUNuQixPQUFPLEVBQUUsa0JBQWtCO3lCQUM1QixDQUFDO3dCQUNGLE9BQU8sRUFBRTs0QkFDUCxjQUFjLEVBQUUsa0JBQWtCO3lCQUNuQztxQkFDRixFQUNELENBQUMsQ0FDRixDQUFDO2lCQUNIO1lBQ0gsQ0FBQyxDQUNGLENBQUM7U0FDSDtLQUNGO0lBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRTtBQUNoQixDQUFDLENBQUM7QUFFRjs7R0FFRztBQUNILElBQU0sc0JBQXNCLEdBQUcsVUFBQyxVQUFtQjtJQUNqRCxJQUFJLENBQUMsVUFBVSxJQUFJLFVBQVUsS0FBSyxnQkFBZ0IsRUFBRTtRQUNsRCxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQztLQUNsQztBQUNILENBQUMsQ0FBQztBQUVGLElBQU0sV0FBVyxHQUFHLFVBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxDQUFDO0lBQ2xDLFlBQUssQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsS0FBSztRQUN2QyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQUUsTUFBTSxLQUFLLENBQUM7UUFDekIsT0FBTyxXQUFXLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDMUMsQ0FBQyxDQUFDO0FBSEYsQ0FHRSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNySUwsa0tBQXdFO0FBRXhFLFNBQXdCLGtCQUFrQjtJQUN4QyxJQUFJLFVBQVUsR0FBRyx1QkFBdUIsQ0FBQztJQUN6QyxJQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBRS9ELFFBQVEsUUFBUSxFQUFFO1FBQ2hCLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxvQkFBb0IsQ0FBQztZQUNsQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLG9CQUFvQixDQUFDO1lBQ2xDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsbUJBQW1CLENBQUM7WUFDakMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyw2QkFBNkIsQ0FBQztZQUMzQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLG9CQUFvQixDQUFDO1lBQ2xDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsdUJBQXVCLENBQUM7WUFDckMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyx3QkFBd0IsQ0FBQztZQUN0QyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLDJCQUEyQixDQUFDO1lBQ3pDLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsNEJBQTRCLENBQUM7WUFDMUMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxhQUFhLENBQUM7WUFDM0IsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyx5QkFBeUIsQ0FBQztZQUN2QyxNQUFNO0tBQ1Q7SUFFRCxJQUFJO1FBQ0YsaUNBQXVCLENBQUMsVUFBVSxDQUFDLENBQUM7S0FDckM7SUFBQyxPQUFPLEtBQUssRUFBRSxHQUFFO0FBQ3BCLENBQUM7QUEzQ0QscUNBMkNDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3Q0Qsa0tBQXdFO0FBRXhFLFNBQXdCLFdBQVc7SUFDakMsSUFBSSxVQUFVLEdBQUcsaUJBQWlCLENBQUM7SUFDbkMsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUUvRCxRQUFRLFFBQVEsRUFBRTtRQUNoQixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsdUJBQXVCLENBQUM7WUFDckMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxxQkFBcUIsQ0FBQztZQUNuQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLGdCQUFnQixDQUFDO1lBQzlCLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsaUJBQWlCLENBQUM7WUFDL0IsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyx1QkFBdUIsQ0FBQztZQUNyQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLHFCQUFxQixDQUFDO1lBQ25DLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsa0JBQWtCLENBQUM7WUFDaEMsTUFBTTtRQUNSLEtBQUssSUFBSTtZQUNQLFVBQVUsR0FBRyxzQkFBc0IsQ0FBQztZQUNwQyxNQUFNO1FBQ1IsS0FBSyxJQUFJO1lBQ1AsVUFBVSxHQUFHLGlCQUFpQixDQUFDO1lBQy9CLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsWUFBWSxDQUFDO1lBQzFCLE1BQU07UUFDUixLQUFLLElBQUk7WUFDUCxVQUFVLEdBQUcsbUJBQW1CLENBQUM7WUFDakMsTUFBTTtLQUNUO0lBRUQsSUFBSTtRQUNGLGlDQUF1QixDQUFDLFVBQVUsQ0FBQyxDQUFDO0tBQ3JDO0lBQUMsT0FBTyxLQUFLLEVBQUU7UUFDZCxFQUFFO0tBQ0g7QUFDSCxDQUFDO0FBN0NELDhCQTZDQzs7Ozs7Ozs7Ozs7OztBQzlDRCxjQUFjLG1CQUFPLENBQUMsc1VBQTBLOztBQUVoTSw0Q0FBNEMsUUFBUzs7QUFFckQ7QUFDQTs7OztBQUlBLGVBQWU7O0FBRWY7QUFDQTs7QUFFQSxhQUFhLG1CQUFPLENBQUMsbUdBQWdEOztBQUVyRTs7QUFFQSxHQUFHLEtBQVUsRUFBRSxFOzs7Ozs7Ozs7Ozs7Ozs7OztBQ25CZixpR0FBb0M7QUFDcEMsaUdBQWtDO0FBQ2xDLHVHQUFzQztBQUN0QywySUFBOEQ7QUFDOUQsOElBQWdFO0FBQ2hFLHNIQUFnRDtBQUNoRCxnTEFBb0Y7QUFDcEYsOElBQWdFO0FBQ2hFLDhJQUFnRTtBQUNoRSw4SUFBZ0U7QUFDaEUsd0hBQTBDO0FBRTFDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQztBQUNuQixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7QUFDcEIsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDO0FBRWpCLENBQUM7SUFDQywwQkFBMEI7SUFDMUIsSUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ3ZCLElBQUksR0FBRyxHQUFHLGFBQWEsRUFBRTtRQUN2QixLQUFLLENBQ0gsK0dBQStHLENBQ2hILENBQUM7UUFDRixPQUFPO0tBQ1I7SUFFRCxJQUFNLEVBQUUsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztJQUM3QixJQUFJLEVBQUUsS0FBSyxrQ0FBa0MsRUFBRTtRQUM3QyxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztZQUN6QixHQUFHLEVBQUUsSUFBSTtTQUNWLENBQUMsQ0FBQztLQUNKO0lBRUQsK0NBQStDO0lBQy9DLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsWUFBWTtRQUNqRSxJQUFJLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRTtZQUNqQyxJQUFNLFdBQVcsR0FBSSxRQUFRLENBQUMsc0JBQXNCLENBQ2xELDRCQUE0QixDQUM3QixDQUFDLENBQUMsQ0FBaUIsQ0FBQyxTQUFTLENBQUM7WUFDL0IsSUFBTSxxQkFBcUIsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUMvQyxxQkFBcUIsRUFDckIsRUFBRSxDQUNILENBQUM7WUFFRixZQUFZLENBQUM7Z0JBQ1gscUJBQXFCLEVBQUUscUJBQXFCO2FBQzdDLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSCxJQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzlDLEtBQUssQ0FBQyxFQUFFLEdBQUcsNEJBQU0sQ0FBQyxLQUFLLENBQUM7SUFDeEIsS0FBSyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDdkIsS0FBSyxDQUFDLEdBQUcsR0FBRyx1REFBdUQsQ0FBQztJQUNwRSxRQUFRLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUU1QyxJQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3RELGFBQWEsQ0FBQyxFQUFFLEdBQUcsNEJBQU0sQ0FBQyxhQUFhLENBQUM7SUFDeEMsYUFBYSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDL0IsYUFBYSxDQUFDLEdBQUcsR0FBRyxnREFBZ0QsQ0FBQztJQUNyRSxRQUFRLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUVwRCxJQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3RELGFBQWEsQ0FBQyxFQUFFLEdBQUcsNEJBQU0sQ0FBQyxhQUFhLENBQUM7SUFDeEMsYUFBYSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDL0IsYUFBYSxDQUFDLEdBQUcsR0FBRyx3REFBd0QsQ0FBQztJQUM3RSxRQUFRLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUVwRCxJQUFNLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDM0Qsa0JBQWtCLENBQUMsRUFBRSxHQUFHLDRCQUFNLENBQUMsa0JBQWtCLENBQUM7SUFDbEQsa0JBQWtCLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUNwQyxrQkFBa0IsQ0FBQyxHQUFHO1FBQ3BCLCtEQUErRCxDQUFDO0lBQ2xFLFFBQVEsQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFFekQseURBQXlEO0lBQ3pELE1BQU0sQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7SUFDcEQsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQzlDLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNoRCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUVuRCxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFFNUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLFVBQUMsT0FBTztRQUMzQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFFbEMsSUFBSSxPQUFPLENBQUMsY0FBYyxFQUFFO1lBQzFCLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUM5QyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDaEQsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFFbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBRXJDLElBQU0sZUFBZSxHQUFHLFFBQVE7aUJBQzdCLHNCQUFzQixDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNyRCxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNwQyxJQUFJLGVBQWUsSUFBSSxlQUFlLENBQUMsS0FBSyxLQUFLLEVBQUUsRUFBRTtnQkFDbkQsSUFBTSxNQUFNLEdBQUcsT0FBTyxDQUNwQiwyRUFBMkUsQ0FDNUUsQ0FBQztnQkFFRixJQUFJLENBQUMsTUFBTSxFQUFFO29CQUNYLGFBQWEsQ0FDWCxxREFBcUQsRUFDckQsSUFBSSxDQUNMLENBQUM7b0JBQ0YsT0FBTztpQkFDUjthQUNGO1lBRUQsSUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZFLElBQUssV0FBZ0MsQ0FBQyxLQUFLLEtBQUssRUFBRSxFQUFFO2dCQUNsRCxJQUFNLE1BQU0sR0FBRyxPQUFPLENBQ3BCLCtFQUErRSxDQUNoRixDQUFDO2dCQUVGLElBQUksQ0FBQyxNQUFNLEVBQUU7b0JBQ1gsYUFBYSxDQUNYLHFEQUFxRCxFQUNyRCxJQUFJLENBQ0wsQ0FBQztvQkFDRixPQUFPO2lCQUNSO2FBQ0Y7WUFHQyxjQUFVLEdBWVIsT0FBTyxXQVpDLEVBQ1YsTUFBTSxHQVdKLE9BQU8sT0FYSCxFQUNOLGFBQWEsR0FVWCxPQUFPLGNBVkksRUFDYixnQkFBZ0IsR0FTZCxPQUFPLGlCQVRPLEVBQ2hCLGNBQWMsR0FRWixPQUFPLGVBUkssRUFDZCxZQUFZLEdBT1YsT0FBTyxhQVBHLEVBQ1osU0FBUyxHQU1QLE9BQU8sVUFOQSxFQUNULE1BQU0sR0FLSixPQUFPLE9BTEgsRUFDTixVQUFVLEdBSVIsT0FBTyxXQUpDLEVBQ1YsV0FBVyxHQUdULE9BQU8sWUFIRSxFQUNYLGNBQWMsR0FFWixPQUFPLGVBRkssRUFDZCxrQkFBa0IsR0FDaEIsT0FBTyxtQkFEUyxDQUNSO1lBRVosa0NBQWtDO1lBQ2xDLElBQU0sYUFBYSxHQUFJLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDcEQsY0FBYyxDQUNmLENBQUMsQ0FBQyxDQUFzQixDQUFDLEtBQUssQ0FBQztZQUNoQyxJQUFNLG1CQUFtQixHQUN2QixRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUVsRSx3QkFBd0I7WUFDeEIsSUFBTSxnQkFBZ0IsR0FBRyxtQkFBbUIsSUFBSSxVQUFVLENBQUM7WUFDM0QsSUFBTSxVQUFVLEdBQUcsY0FBYyxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFFcEQsa0NBQWtDO1lBQ2xDLElBQU0sYUFBYSxHQUFJLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDcEQsY0FBYyxDQUNmLENBQUMsQ0FBQyxDQUFzQixDQUFDLEtBQUssQ0FBQztZQUNoQyxJQUFNLG1CQUFtQixHQUN2QixRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUVsRSxJQUFJLG1CQUFtQixJQUFJLFVBQVUsRUFBRTtnQkFDckMsYUFBYSxDQUNYLGdGQUFnRixFQUNoRixJQUFJLENBQ0wsQ0FBQztnQkFDRixPQUFPO2FBQ1I7WUFFRCxXQUFXLENBQUM7Z0JBQ1YsU0FBUyxFQUFFLENBQUM7Z0JBQ1osV0FBVyxFQUFFLE1BQU07Z0JBQ25CLFVBQVU7Z0JBQ1YsV0FBVztnQkFDWCxTQUFTO2dCQUNULE1BQU07Z0JBQ04sY0FBYztnQkFDZCxZQUFZO2dCQUNaLGFBQWE7Z0JBQ2IsZ0JBQWdCO2dCQUNoQixVQUFVO2dCQUNWLGFBQWEsRUFBRSxtQkFBbUIsR0FBRyxDQUFDO2dCQUN0QyxjQUFjO2dCQUNkLGFBQWEsRUFBRSxtQkFBbUI7Z0JBQ2xDLGtCQUFrQixFQUFFLGtCQUFrQjthQUN2QyxDQUFDLENBQUM7U0FDSjthQUFNLElBQUksT0FBTyxDQUFDLHNCQUFzQixFQUFFO1lBQ3pDLGFBQWEsQ0FBQywyQ0FBMkMsQ0FBQyxDQUFDO1NBQzVEO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSCw2Q0FBNkM7SUFDN0MsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxVQUFDLEVBQUU7UUFDcEMsaURBQWlEO1FBQ2pELElBQUksUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLEtBQUssT0FBTyxFQUFFO1lBQzVELE9BQU87U0FDUjtRQUVELElBQUksRUFBRSxDQUFDLE9BQU8sS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtZQUNwQyxJQUFJLElBQUksSUFBSSxPQUFPLElBQUksUUFBUSxFQUFFO2dCQUMvQixhQUFhLENBQUMsMkNBQTJDLENBQUMsQ0FBQzthQUM1RDtpQkFBTTtnQkFDTCxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ3JCO29CQUNFLFlBQVk7b0JBQ1osVUFBVTtvQkFDVixRQUFRO29CQUNSLGVBQWU7b0JBQ2Ysa0JBQWtCO29CQUNsQixnQkFBZ0I7b0JBQ2hCLGNBQWM7b0JBQ2QsUUFBUTtvQkFDUixZQUFZO29CQUNaLGFBQWE7b0JBQ2IsZ0JBQWdCO29CQUNoQixvQkFBb0I7aUJBQ3JCLEVBQ0QsVUFBQyxJQUFJO29CQUVELGNBQVUsR0FZUixJQUFJLFdBWkksRUFDVixRQUFRLEdBV04sSUFBSSxTQVhFLEVBQ1IsTUFBTSxHQVVKLElBQUksT0FWQSxFQUNOLGFBQWEsR0FTWCxJQUFJLGNBVE8sRUFDYixnQkFBZ0IsR0FRZCxJQUFJLGlCQVJVLEVBQ2hCLGNBQWMsR0FPWixJQUFJLGVBUFEsRUFDZCxZQUFZLEdBTVYsSUFBSSxhQU5NLEVBQ1osTUFBTSxHQUtKLElBQUksT0FMQSxFQUNOLFVBQVUsR0FJUixJQUFJLFdBSkksRUFDVixXQUFXLEdBR1QsSUFBSSxZQUhLLEVBQ1gsY0FBYyxHQUVaLElBQUksZUFGUSxFQUNkLGtCQUFrQixHQUNoQixJQUFJLG1CQURZLENBQ1g7b0JBRVQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7d0JBQ3pCLGNBQWMsRUFBRSxJQUFJO3dCQUNwQixVQUFVLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQzt3QkFDaEMsUUFBUSxFQUFFLFFBQVE7d0JBQ2xCLE1BQU0sRUFBRSxNQUFNO3dCQUNkLGFBQWEsRUFBRSxhQUFhO3dCQUM1QixnQkFBZ0IsRUFBRSxnQkFBZ0I7d0JBQ2xDLGNBQWMsRUFBRSxjQUFjO3dCQUM5QixZQUFZLEVBQUUsWUFBWTt3QkFDMUIsU0FBUyxFQUFFLEtBQUs7d0JBQ2hCLE1BQU0sRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDO3dCQUN4QixVQUFVLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQzt3QkFDaEMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxXQUFXLENBQUM7d0JBQ2xDLGNBQWMsRUFBRSxRQUFRLENBQUMsY0FBYyxDQUFDO3dCQUN4QyxrQkFBa0IsRUFBRSxrQkFBa0I7cUJBQ3ZDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQ0YsQ0FBQzthQUNIO1NBQ0Y7SUFDSCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFFTCxJQUFNLGFBQWEsR0FBRyxVQUFDLE1BQWMsRUFBRSxTQUEwQjtJQUExQiw2Q0FBMEI7SUFDL0QsSUFBSSxJQUFJLElBQUksT0FBTyxJQUFJLFFBQVEsSUFBSSxTQUFTLEVBQUU7UUFDNUMsSUFBSSxHQUFHLEtBQUssQ0FBQztRQUViLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0QixPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRWYsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3ZCLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFFaEIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUVwRCxJQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUMvRCxJQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMzRCxJQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXJFLEtBQUssQ0FDQSxNQUFNLFVBQUssV0FBVyxtQkFBYyxTQUFTLHFCQUFnQixjQUFjLG1CQUFnQixDQUMvRixDQUFDO0tBQ0g7QUFDSCxDQUFDLENBQUM7QUFFRixJQUFNLFNBQVMsR0FBRztJQUNoQixJQUFNLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDZCxJQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7SUFFZixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztBQUMzRCxDQUFDLENBQUM7QUFFRixJQUFNLGNBQWMsR0FBRyxVQUFDLGdCQUF3QjtJQUM5QyxJQUFJLGdCQUFnQixJQUFJLElBQUksRUFBRTtRQUM1QixPQUFPLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztLQUM5QjtTQUFNLElBQUksZ0JBQWdCLElBQUksS0FBSyxFQUFFO1FBQ3BDLE9BQU8sZ0JBQWdCLEdBQUcsR0FBRyxDQUFDO0tBQy9CO1NBQU0sSUFBSSxnQkFBZ0IsSUFBSSxNQUFNLEVBQUU7UUFDckMsT0FBTyxnQkFBZ0IsR0FBRyxHQUFHLENBQUM7S0FDL0I7U0FBTTtRQUNMLE9BQU8sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO0tBQ2hDO0FBQ0gsQ0FBQyxDQUFDO0FBRUYsSUFBTSxXQUFXLEdBQUcsVUFBQyxNQWdCcEI7SUFFRyxhQUFTLEdBZVAsTUFBTSxVQWZDLEVBQ1QsV0FBVyxHQWNULE1BQU0sWUFkRyxFQUNYLFVBQVUsR0FhUixNQUFNLFdBYkUsRUFDVixXQUFXLEdBWVQsTUFBTSxZQVpHLEVBQ1gsU0FBUyxHQVdQLE1BQU0sVUFYQyxFQUNULE1BQU0sR0FVSixNQUFNLE9BVkYsRUFDTixjQUFjLEdBU1osTUFBTSxlQVRNLEVBQ2QsWUFBWSxHQVFWLE1BQU0sYUFSSSxFQUNaLGFBQWEsR0FPWCxNQUFNLGNBUEssRUFDYixnQkFBZ0IsR0FNZCxNQUFNLGlCQU5RLEVBQ2hCLFVBQVUsR0FLUixNQUFNLFdBTEUsRUFDVixhQUFhLEdBSVgsTUFBTSxjQUpLLEVBQ2IsY0FBYyxHQUdaLE1BQU0sZUFITSxFQUNkLGFBQWEsR0FFWCxNQUFNLGNBRkssRUFDYixrQkFBa0IsR0FDaEIsTUFBTSxtQkFEVSxDQUNUO0lBRVgsSUFBTSxpQkFBaUIsR0FBRyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQzdDLElBQU0sa0JBQWtCLEdBQUcsV0FBVyxHQUFHLEtBQUssQ0FBQztJQUUvQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0lBRVosMkJBQTJCO0lBQzNCLElBQU0sV0FBVyxHQUFJLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDbEQsNEJBQTRCLENBQzdCLENBQUMsQ0FBQyxDQUFpQixDQUFDLFNBQVMsQ0FBQztJQUMvQixJQUFNLHFCQUFxQixHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDN0UsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUscUJBQXFCLENBQUMsQ0FBQztJQUUxRSxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFdEIsSUFBTSxjQUFjLEdBQUcsU0FBUyxFQUFFLENBQUM7SUFFbkMsMERBQTBEO0lBQzFELE9BQU8sR0FBRyxVQUFVLENBQUM7UUFDbkIsSUFBSSxHQUFHLEtBQUssQ0FBQztRQUViLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsRUFBRSxVQUFDLElBQUk7WUFDdEQsSUFBSSxJQUFJLENBQUMsdUJBQXVCLEVBQUU7Z0JBQ2hDLElBQU0sYUFBYSxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQzNDLDRCQUFNLENBQUMsYUFBYSxDQUNELENBQUM7Z0JBQ3RCLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUN0QjtZQUVELElBQUksU0FBUyxLQUFLLFdBQVcsR0FBRyxDQUFDLEVBQUU7Z0JBQ2pDLGFBQWEsQ0FDWCx3RUFBd0UsQ0FDekUsQ0FBQzthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLEVBQUUsaUJBQWlCLEdBQUcsY0FBYyxDQUFDLENBQUM7SUFFdkMsK0RBQStEO0lBQy9ELFFBQVEsR0FBRyxVQUFVLENBQUM7UUFDcEIsSUFBSSxTQUFTLEdBQUcsV0FBVyxHQUFHLENBQUMsRUFBRTtZQUMvQixXQUFXLENBQUM7Z0JBQ1YsU0FBUyxFQUFFLFNBQVMsR0FBRyxDQUFDO2dCQUN4QixXQUFXO2dCQUNYLFVBQVU7Z0JBQ1YsV0FBVztnQkFDWCxTQUFTO2dCQUNULE1BQU07Z0JBQ04sY0FBYztnQkFDZCxZQUFZO2dCQUNaLGFBQWE7Z0JBQ2IsZ0JBQWdCO2dCQUNoQixVQUFVO2dCQUNWLGFBQWE7Z0JBQ2IsY0FBYztnQkFDZCxhQUFhO2dCQUNiLGtCQUFrQjthQUNuQixDQUFDLENBQUM7U0FDSjtJQUNILENBQUMsRUFBRSxpQkFBaUIsR0FBRyxjQUFjLEdBQUcsa0JBQWtCLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUM7QUFFRixJQUFNLGFBQWEsR0FBRyxVQUFDLE1BWXRCO0lBRUcsYUFBUyxHQVdQLE1BQU0sVUFYQyxFQUNULE1BQU0sR0FVSixNQUFNLE9BVkYsRUFDTixjQUFjLEdBU1osTUFBTSxlQVRNLEVBQ2QsWUFBWSxHQVFWLE1BQU0sYUFSSSxFQUNaLGFBQWEsR0FPWCxNQUFNLGNBUEssRUFDYixnQkFBZ0IsR0FNZCxNQUFNLGlCQU5RLEVBQ2hCLFVBQVUsR0FLUixNQUFNLFdBTEUsRUFDVixhQUFhLEdBSVgsTUFBTSxjQUpLLEVBQ2IsY0FBYyxHQUdaLE1BQU0sZUFITSxFQUNkLGFBQWEsR0FFWCxNQUFNLGNBRkssRUFDYixrQkFBa0IsR0FDaEIsTUFBTSxtQkFEVSxDQUNUO0lBRVgsSUFBTSxpQkFBaUIsR0FBRyxXQUFXLENBQUMsYUFBYSxFQUFFLGdCQUFnQixDQUFDLENBQUM7SUFFdkUsb0JBQW9CO0lBQ3BCLElBQU0sY0FBYyxHQUNsQixRQUFRLENBQUMsc0JBQXNCLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ3JFLElBQUksY0FBYyxFQUFFO1FBQ2xCLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxVQUFDLElBQUk7WUFDckQsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7Z0JBQy9CLElBQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsNEJBQU0sQ0FBQyxLQUFLLENBQXFCLENBQUM7Z0JBQ3hFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNkO1lBRUQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7Z0JBQ3pCLEtBQUssRUFBRSxJQUFJO2FBQ1osQ0FBQyxDQUFDO1lBRUgsYUFBYSxDQUNYLGlFQUFpRSxDQUNsRSxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPO0tBQ1I7SUFFRCx5QkFBeUI7SUFDekIsSUFBTSxXQUFXLEdBQUksUUFBUSxDQUFDLHNCQUFzQixDQUNsRCw0QkFBNEIsQ0FDN0IsQ0FBQyxDQUFDLENBQWlCLENBQUMsU0FBUyxDQUFDO0lBQy9CLElBQU0scUJBQXFCLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFFakUseUNBQXlDO0lBQ3pDLElBQU0sbUJBQW1CLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQ3JELHFCQUFxQixDQUN0QixDQUFDO0lBRUYsSUFBSSxxQkFBcUIsR0FBRyxrQkFBa0IsRUFBRTtRQUM5QyxhQUFhLENBQ1gsNEdBQTRHLENBQzdHLENBQUM7UUFFRixPQUFPO0tBQ1I7U0FBTSxJQUFJLG1CQUFtQixLQUFLLHFCQUFxQixFQUFFO1FBQ3hELElBQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRS9EOzs7V0FHRztRQUNILElBQUksV0FBVyxLQUFLLE1BQU0sRUFBRTtZQUMxQixJQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQy9ELElBQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZELE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1lBRW5FLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDckIsQ0FBQyw4QkFBOEIsRUFBRSw2QkFBNkIsQ0FBQyxFQUMvRCxVQUFDLElBQUk7Z0JBQ0gsSUFBSSxJQUFJLENBQUMsNEJBQTRCLEVBQUU7b0JBQ3JDLElBQU0sa0JBQWtCLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FDaEQsNEJBQU0sQ0FBQyxrQkFBa0IsQ0FDTixDQUFDO29CQUN0QixrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQztpQkFDM0I7Z0JBRUQsSUFBSSxJQUFJLENBQUMsMkJBQTJCLEVBQUU7b0JBQ3BDLFdBQVcsQ0FDVCxJQUFJLENBQUMsMkJBQTJCLEVBQ2hDO3dCQUNFLE1BQU0sRUFBRSxNQUFNO3dCQUNkLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUNuQixPQUFPLEVBQUUsOEJBQThCO3lCQUN4QyxDQUFDO3dCQUNGLE9BQU8sRUFBRTs0QkFDUCxjQUFjLEVBQUUsa0JBQWtCO3lCQUNuQztxQkFDRixFQUNELENBQUMsQ0FDRixDQUFDO2lCQUNIO1lBQ0gsQ0FBQyxDQUNGLENBQUM7U0FDSDtLQUNGO0lBRUQsMkNBQTJDO0lBQzNDLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUVwRCxnQkFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7SUFFbkIsVUFBVSxDQUFDO1FBQ1QsVUFBVSxDQUFDO1lBQ1QsSUFBSTtnQkFDRixJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7b0JBQ3JCLGNBQUksQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDLENBQUM7aUJBQ3BDO3FCQUFNLElBQUksTUFBTSxLQUFLLFVBQVUsRUFBRTtvQkFDaEMsNEJBQWtCLEVBQUUsQ0FBQztpQkFDdEI7cUJBQU0sSUFBSSxNQUFNLEtBQUssTUFBTSxFQUFFO29CQUM1QixxQkFBVyxFQUFFLENBQUM7aUJBQ2Y7cUJBQU0sSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFO29CQUN2QyxhQUFhO2lCQUNkO2FBQ0Y7WUFBQyxPQUFPLENBQUMsRUFBRSxHQUFFO1lBRWQsVUFBVSxDQUFDO2dCQUNULElBQUksbUNBQXlCLEVBQUUsRUFBRTtvQkFDL0IsY0FBTSxFQUFFLENBQUM7aUJBQ1Y7WUFDSCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDVixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFUixVQUFVLENBQUM7WUFDVCxJQUFJLGFBQWEsRUFBRTtnQkFDakIsSUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUNqRCxjQUFjLENBQ2YsQ0FBQyxDQUFDLENBQXFCLENBQUM7Z0JBQ3pCLElBQU0sYUFBYSxHQUNqQixRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRXRFLHdEQUF3RDtnQkFDeEQsSUFBSSxhQUFhLElBQUksVUFBVSxFQUFFO29CQUMvQixXQUFXLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDdkIsWUFBWSxDQUFDLGFBQWEsRUFBRSxjQUFjLENBQUMsQ0FBQztpQkFDN0M7Z0JBRUQsNkJBQW1CLEVBQUUsQ0FBQzthQUN2QjtpQkFBTTtnQkFDTCxJQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQ2pELGNBQWMsQ0FDZixDQUFDLENBQUMsQ0FBcUIsQ0FBQztnQkFDekIsSUFBTSxhQUFhLEdBQ2pCLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFdEUsd0RBQXdEO2dCQUN4RCxJQUFJLGFBQWEsSUFBSSxVQUFVLEVBQUU7b0JBQy9CLFdBQVcsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUN2QixZQUFZLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQyxDQUFDO2lCQUM3QztnQkFFRCw2QkFBbUIsRUFBRSxDQUFDO2FBQ3ZCO1lBRUQsSUFBSSxJQUFJLEVBQUU7Z0JBQ1IsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3ZCO1FBQ0gsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsQ0FBQyxFQUFFLGlCQUFpQixDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDO0FBRUY7Ozs7O0dBS0c7QUFDSCxJQUFNLFlBQVksR0FBRyxVQUFDLGFBQXFCLEVBQUUsY0FBc0I7SUFDakUsSUFBSSxjQUFjLElBQUksYUFBYSxFQUFFO1FBQ25DLE9BQU87S0FDUjtJQUVELElBQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FDakQsY0FBYyxDQUNmLENBQUMsQ0FBQyxDQUFxQixDQUFDO0lBQ3pCLElBQU0sYUFBYSxHQUNqQixRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7SUFFdEUsSUFBSSxhQUFhLEtBQUssQ0FBQyxFQUFFO1FBQ3ZCLE9BQU87S0FDUjtJQUVELElBQUksYUFBYSxJQUFJLGNBQWMsRUFBRTtRQUNuQyxXQUFXLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUM3Qyw2QkFBbUIsRUFBRSxDQUFDO1FBQ3RCLDZCQUFtQixFQUFFLENBQUM7S0FDdkI7U0FBTTtRQUNMLDZCQUFtQixFQUFFLENBQUM7S0FDdkI7QUFDSCxDQUFDLENBQUM7QUFFRixTQUFTLFdBQVcsQ0FBQyxhQUFxQixFQUFFLGdCQUF3QjtJQUNsRSxJQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDcEMsSUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFFdkMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7QUFDM0QsQ0FBQztBQUVELElBQU0sV0FBVyxHQUFHLFVBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxDQUFDO0lBQ2xDLFlBQUssQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsS0FBSztRQUN2QyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQUUsTUFBTSxLQUFLLENBQUM7UUFDekIsT0FBTyxXQUFXLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDMUMsQ0FBQyxDQUFDO0FBSEYsQ0FHRSxDQUFDIiwiZmlsZSI6ImNvbnRlbnRTY3JpcHQuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3NyYy9jb250ZW50U2NyaXB0LnRzeFwiKTtcbiIsIlwidXNlIHN0cmljdFwiO1xuXG4vKlxuICBNSVQgTGljZW5zZSBodHRwOi8vd3d3Lm9wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL21pdC1saWNlbnNlLnBocFxuICBBdXRob3IgVG9iaWFzIEtvcHBlcnMgQHNva3JhXG4qL1xuLy8gY3NzIGJhc2UgY29kZSwgaW5qZWN0ZWQgYnkgdGhlIGNzcy1sb2FkZXJcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKHVzZVNvdXJjZU1hcCkge1xuICB2YXIgbGlzdCA9IFtdOyAvLyByZXR1cm4gdGhlIGxpc3Qgb2YgbW9kdWxlcyBhcyBjc3Mgc3RyaW5nXG5cbiAgbGlzdC50b1N0cmluZyA9IGZ1bmN0aW9uIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiB0aGlzLm1hcChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgdmFyIGNvbnRlbnQgPSBjc3NXaXRoTWFwcGluZ1RvU3RyaW5nKGl0ZW0sIHVzZVNvdXJjZU1hcCk7XG5cbiAgICAgIGlmIChpdGVtWzJdKSB7XG4gICAgICAgIHJldHVybiAnQG1lZGlhICcgKyBpdGVtWzJdICsgJ3snICsgY29udGVudCArICd9JztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBjb250ZW50O1xuICAgICAgfVxuICAgIH0pLmpvaW4oJycpO1xuICB9OyAvLyBpbXBvcnQgYSBsaXN0IG9mIG1vZHVsZXMgaW50byB0aGUgbGlzdFxuXG5cbiAgbGlzdC5pID0gZnVuY3Rpb24gKG1vZHVsZXMsIG1lZGlhUXVlcnkpIHtcbiAgICBpZiAodHlwZW9mIG1vZHVsZXMgPT09ICdzdHJpbmcnKSB7XG4gICAgICBtb2R1bGVzID0gW1tudWxsLCBtb2R1bGVzLCAnJ11dO1xuICAgIH1cblxuICAgIHZhciBhbHJlYWR5SW1wb3J0ZWRNb2R1bGVzID0ge307XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHZhciBpZCA9IHRoaXNbaV1bMF07XG5cbiAgICAgIGlmIChpZCAhPSBudWxsKSB7XG4gICAgICAgIGFscmVhZHlJbXBvcnRlZE1vZHVsZXNbaWRdID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBmb3IgKGkgPSAwOyBpIDwgbW9kdWxlcy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIGl0ZW0gPSBtb2R1bGVzW2ldOyAvLyBza2lwIGFscmVhZHkgaW1wb3J0ZWQgbW9kdWxlXG4gICAgICAvLyB0aGlzIGltcGxlbWVudGF0aW9uIGlzIG5vdCAxMDAlIHBlcmZlY3QgZm9yIHdlaXJkIG1lZGlhIHF1ZXJ5IGNvbWJpbmF0aW9uc1xuICAgICAgLy8gd2hlbiBhIG1vZHVsZSBpcyBpbXBvcnRlZCBtdWx0aXBsZSB0aW1lcyB3aXRoIGRpZmZlcmVudCBtZWRpYSBxdWVyaWVzLlxuICAgICAgLy8gSSBob3BlIHRoaXMgd2lsbCBuZXZlciBvY2N1ciAoSGV5IHRoaXMgd2F5IHdlIGhhdmUgc21hbGxlciBidW5kbGVzKVxuXG4gICAgICBpZiAoaXRlbVswXSA9PSBudWxsIHx8ICFhbHJlYWR5SW1wb3J0ZWRNb2R1bGVzW2l0ZW1bMF1dKSB7XG4gICAgICAgIGlmIChtZWRpYVF1ZXJ5ICYmICFpdGVtWzJdKSB7XG4gICAgICAgICAgaXRlbVsyXSA9IG1lZGlhUXVlcnk7XG4gICAgICAgIH0gZWxzZSBpZiAobWVkaWFRdWVyeSkge1xuICAgICAgICAgIGl0ZW1bMl0gPSAnKCcgKyBpdGVtWzJdICsgJykgYW5kICgnICsgbWVkaWFRdWVyeSArICcpJztcbiAgICAgICAgfVxuXG4gICAgICAgIGxpc3QucHVzaChpdGVtKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIGxpc3Q7XG59O1xuXG5mdW5jdGlvbiBjc3NXaXRoTWFwcGluZ1RvU3RyaW5nKGl0ZW0sIHVzZVNvdXJjZU1hcCkge1xuICB2YXIgY29udGVudCA9IGl0ZW1bMV0gfHwgJyc7XG4gIHZhciBjc3NNYXBwaW5nID0gaXRlbVszXTtcblxuICBpZiAoIWNzc01hcHBpbmcpIHtcbiAgICByZXR1cm4gY29udGVudDtcbiAgfVxuXG4gIGlmICh1c2VTb3VyY2VNYXAgJiYgdHlwZW9mIGJ0b2EgPT09ICdmdW5jdGlvbicpIHtcbiAgICB2YXIgc291cmNlTWFwcGluZyA9IHRvQ29tbWVudChjc3NNYXBwaW5nKTtcbiAgICB2YXIgc291cmNlVVJMcyA9IGNzc01hcHBpbmcuc291cmNlcy5tYXAoZnVuY3Rpb24gKHNvdXJjZSkge1xuICAgICAgcmV0dXJuICcvKiMgc291cmNlVVJMPScgKyBjc3NNYXBwaW5nLnNvdXJjZVJvb3QgKyBzb3VyY2UgKyAnICovJztcbiAgICB9KTtcbiAgICByZXR1cm4gW2NvbnRlbnRdLmNvbmNhdChzb3VyY2VVUkxzKS5jb25jYXQoW3NvdXJjZU1hcHBpbmddKS5qb2luKCdcXG4nKTtcbiAgfVxuXG4gIHJldHVybiBbY29udGVudF0uam9pbignXFxuJyk7XG59IC8vIEFkYXB0ZWQgZnJvbSBjb252ZXJ0LXNvdXJjZS1tYXAgKE1JVClcblxuXG5mdW5jdGlvbiB0b0NvbW1lbnQoc291cmNlTWFwKSB7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bmRlZlxuICB2YXIgYmFzZTY0ID0gYnRvYSh1bmVzY2FwZShlbmNvZGVVUklDb21wb25lbnQoSlNPTi5zdHJpbmdpZnkoc291cmNlTWFwKSkpKTtcbiAgdmFyIGRhdGEgPSAnc291cmNlTWFwcGluZ1VSTD1kYXRhOmFwcGxpY2F0aW9uL2pzb247Y2hhcnNldD11dGYtODtiYXNlNjQsJyArIGJhc2U2NDtcbiAgcmV0dXJuICcvKiMgJyArIGRhdGEgKyAnICovJztcbn0iLCJleHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiKShmYWxzZSk7XG4vLyBNb2R1bGVcbmV4cG9ydHMucHVzaChbbW9kdWxlLmlkLCBcIiNfMTJmX3FCZEFmX2MzZzlvc1NMWmVjNCxcXG4jXzE5amFDczdKbVBJLVhuVkotTGlFa0UsXFxuI18zMUZtX0VrZFdaaHl1ZWZVazhLajRDLFxcbiNfMzBBTEdMckdHRl9mWmdEajVkNlhPaSB7XFxuICBkaXNwbGF5OiBub25lOyB9XFxuXCIsIFwiXCJdKTtcblxuLy8gRXhwb3J0c1xuZXhwb3J0cy5sb2NhbHMgPSB7XG5cdFwiYXVkaW9cIjogXCJfMTJmX3FCZEFmX2MzZzlvc1NMWmVjNFwiLFxuXHRcImxvb3BEb25lU291bmRcIjogXCJfMTlqYUNzN0ptUEktWG5WSi1MaUVrRVwiLFxuXHRcImNhcmRTZWVuU291bmRcIjogXCJfMzFGbV9Fa2RXWmh5dWVmVWs4S2o0Q1wiLFxuXHRcImNhcmRQdXJjaGFzZWRTb3VuZFwiOiBcIl8zMEFMR0xyR0dGX2ZaZ0RqNWQ2WE9pXCJcbn07IiwiLypcblx0TUlUIExpY2Vuc2UgaHR0cDovL3d3dy5vcGVuc291cmNlLm9yZy9saWNlbnNlcy9taXQtbGljZW5zZS5waHBcblx0QXV0aG9yIFRvYmlhcyBLb3BwZXJzIEBzb2tyYVxuKi9cblxudmFyIHN0eWxlc0luRG9tID0ge307XG5cbnZhclx0bWVtb2l6ZSA9IGZ1bmN0aW9uIChmbikge1xuXHR2YXIgbWVtbztcblxuXHRyZXR1cm4gZnVuY3Rpb24gKCkge1xuXHRcdGlmICh0eXBlb2YgbWVtbyA9PT0gXCJ1bmRlZmluZWRcIikgbWVtbyA9IGZuLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG5cdFx0cmV0dXJuIG1lbW87XG5cdH07XG59O1xuXG52YXIgaXNPbGRJRSA9IG1lbW9pemUoZnVuY3Rpb24gKCkge1xuXHQvLyBUZXN0IGZvciBJRSA8PSA5IGFzIHByb3Bvc2VkIGJ5IEJyb3dzZXJoYWNrc1xuXHQvLyBAc2VlIGh0dHA6Ly9icm93c2VyaGFja3MuY29tLyNoYWNrLWU3MWQ4NjkyZjY1MzM0MTczZmVlNzE1YzIyMmNiODA1XG5cdC8vIFRlc3RzIGZvciBleGlzdGVuY2Ugb2Ygc3RhbmRhcmQgZ2xvYmFscyBpcyB0byBhbGxvdyBzdHlsZS1sb2FkZXJcblx0Ly8gdG8gb3BlcmF0ZSBjb3JyZWN0bHkgaW50byBub24tc3RhbmRhcmQgZW52aXJvbm1lbnRzXG5cdC8vIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL3dlYnBhY2stY29udHJpYi9zdHlsZS1sb2FkZXIvaXNzdWVzLzE3N1xuXHRyZXR1cm4gd2luZG93ICYmIGRvY3VtZW50ICYmIGRvY3VtZW50LmFsbCAmJiAhd2luZG93LmF0b2I7XG59KTtcblxudmFyIGdldFRhcmdldCA9IGZ1bmN0aW9uICh0YXJnZXQpIHtcbiAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IodGFyZ2V0KTtcbn07XG5cbnZhciBnZXRFbGVtZW50ID0gKGZ1bmN0aW9uIChmbikge1xuXHR2YXIgbWVtbyA9IHt9O1xuXG5cdHJldHVybiBmdW5jdGlvbih0YXJnZXQpIHtcbiAgICAgICAgICAgICAgICAvLyBJZiBwYXNzaW5nIGZ1bmN0aW9uIGluIG9wdGlvbnMsIHRoZW4gdXNlIGl0IGZvciByZXNvbHZlIFwiaGVhZFwiIGVsZW1lbnQuXG4gICAgICAgICAgICAgICAgLy8gVXNlZnVsIGZvciBTaGFkb3cgUm9vdCBzdHlsZSBpLmVcbiAgICAgICAgICAgICAgICAvLyB7XG4gICAgICAgICAgICAgICAgLy8gICBpbnNlcnRJbnRvOiBmdW5jdGlvbiAoKSB7IHJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2Zvb1wiKS5zaGFkb3dSb290IH1cbiAgICAgICAgICAgICAgICAvLyB9XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0YXJnZXQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0YXJnZXQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBtZW1vW3RhcmdldF0gPT09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdHZhciBzdHlsZVRhcmdldCA9IGdldFRhcmdldC5jYWxsKHRoaXMsIHRhcmdldCk7XG5cdFx0XHQvLyBTcGVjaWFsIGNhc2UgdG8gcmV0dXJuIGhlYWQgb2YgaWZyYW1lIGluc3RlYWQgb2YgaWZyYW1lIGl0c2VsZlxuXHRcdFx0aWYgKHdpbmRvdy5IVE1MSUZyYW1lRWxlbWVudCAmJiBzdHlsZVRhcmdldCBpbnN0YW5jZW9mIHdpbmRvdy5IVE1MSUZyYW1lRWxlbWVudCkge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdC8vIFRoaXMgd2lsbCB0aHJvdyBhbiBleGNlcHRpb24gaWYgYWNjZXNzIHRvIGlmcmFtZSBpcyBibG9ja2VkXG5cdFx0XHRcdFx0Ly8gZHVlIHRvIGNyb3NzLW9yaWdpbiByZXN0cmljdGlvbnNcblx0XHRcdFx0XHRzdHlsZVRhcmdldCA9IHN0eWxlVGFyZ2V0LmNvbnRlbnREb2N1bWVudC5oZWFkO1xuXHRcdFx0XHR9IGNhdGNoKGUpIHtcblx0XHRcdFx0XHRzdHlsZVRhcmdldCA9IG51bGw7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdG1lbW9bdGFyZ2V0XSA9IHN0eWxlVGFyZ2V0O1xuXHRcdH1cblx0XHRyZXR1cm4gbWVtb1t0YXJnZXRdXG5cdH07XG59KSgpO1xuXG52YXIgc2luZ2xldG9uID0gbnVsbDtcbnZhclx0c2luZ2xldG9uQ291bnRlciA9IDA7XG52YXJcdHN0eWxlc0luc2VydGVkQXRUb3AgPSBbXTtcblxudmFyXHRmaXhVcmxzID0gcmVxdWlyZShcIi4vdXJsc1wiKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbihsaXN0LCBvcHRpb25zKSB7XG5cdGlmICh0eXBlb2YgREVCVUcgIT09IFwidW5kZWZpbmVkXCIgJiYgREVCVUcpIHtcblx0XHRpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcIm9iamVjdFwiKSB0aHJvdyBuZXcgRXJyb3IoXCJUaGUgc3R5bGUtbG9hZGVyIGNhbm5vdCBiZSB1c2VkIGluIGEgbm9uLWJyb3dzZXIgZW52aXJvbm1lbnRcIik7XG5cdH1cblxuXHRvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcblxuXHRvcHRpb25zLmF0dHJzID0gdHlwZW9mIG9wdGlvbnMuYXR0cnMgPT09IFwib2JqZWN0XCIgPyBvcHRpb25zLmF0dHJzIDoge307XG5cblx0Ly8gRm9yY2Ugc2luZ2xlLXRhZyBzb2x1dGlvbiBvbiBJRTYtOSwgd2hpY2ggaGFzIGEgaGFyZCBsaW1pdCBvbiB0aGUgIyBvZiA8c3R5bGU+XG5cdC8vIHRhZ3MgaXQgd2lsbCBhbGxvdyBvbiBhIHBhZ2Vcblx0aWYgKCFvcHRpb25zLnNpbmdsZXRvbiAmJiB0eXBlb2Ygb3B0aW9ucy5zaW5nbGV0b24gIT09IFwiYm9vbGVhblwiKSBvcHRpb25zLnNpbmdsZXRvbiA9IGlzT2xkSUUoKTtcblxuXHQvLyBCeSBkZWZhdWx0LCBhZGQgPHN0eWxlPiB0YWdzIHRvIHRoZSA8aGVhZD4gZWxlbWVudFxuICAgICAgICBpZiAoIW9wdGlvbnMuaW5zZXJ0SW50bykgb3B0aW9ucy5pbnNlcnRJbnRvID0gXCJoZWFkXCI7XG5cblx0Ly8gQnkgZGVmYXVsdCwgYWRkIDxzdHlsZT4gdGFncyB0byB0aGUgYm90dG9tIG9mIHRoZSB0YXJnZXRcblx0aWYgKCFvcHRpb25zLmluc2VydEF0KSBvcHRpb25zLmluc2VydEF0ID0gXCJib3R0b21cIjtcblxuXHR2YXIgc3R5bGVzID0gbGlzdFRvU3R5bGVzKGxpc3QsIG9wdGlvbnMpO1xuXG5cdGFkZFN0eWxlc1RvRG9tKHN0eWxlcywgb3B0aW9ucyk7XG5cblx0cmV0dXJuIGZ1bmN0aW9uIHVwZGF0ZSAobmV3TGlzdCkge1xuXHRcdHZhciBtYXlSZW1vdmUgPSBbXTtcblxuXHRcdGZvciAodmFyIGkgPSAwOyBpIDwgc3R5bGVzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHR2YXIgaXRlbSA9IHN0eWxlc1tpXTtcblx0XHRcdHZhciBkb21TdHlsZSA9IHN0eWxlc0luRG9tW2l0ZW0uaWRdO1xuXG5cdFx0XHRkb21TdHlsZS5yZWZzLS07XG5cdFx0XHRtYXlSZW1vdmUucHVzaChkb21TdHlsZSk7XG5cdFx0fVxuXG5cdFx0aWYobmV3TGlzdCkge1xuXHRcdFx0dmFyIG5ld1N0eWxlcyA9IGxpc3RUb1N0eWxlcyhuZXdMaXN0LCBvcHRpb25zKTtcblx0XHRcdGFkZFN0eWxlc1RvRG9tKG5ld1N0eWxlcywgb3B0aW9ucyk7XG5cdFx0fVxuXG5cdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBtYXlSZW1vdmUubGVuZ3RoOyBpKyspIHtcblx0XHRcdHZhciBkb21TdHlsZSA9IG1heVJlbW92ZVtpXTtcblxuXHRcdFx0aWYoZG9tU3R5bGUucmVmcyA9PT0gMCkge1xuXHRcdFx0XHRmb3IgKHZhciBqID0gMDsgaiA8IGRvbVN0eWxlLnBhcnRzLmxlbmd0aDsgaisrKSBkb21TdHlsZS5wYXJ0c1tqXSgpO1xuXG5cdFx0XHRcdGRlbGV0ZSBzdHlsZXNJbkRvbVtkb21TdHlsZS5pZF07XG5cdFx0XHR9XG5cdFx0fVxuXHR9O1xufTtcblxuZnVuY3Rpb24gYWRkU3R5bGVzVG9Eb20gKHN0eWxlcywgb3B0aW9ucykge1xuXHRmb3IgKHZhciBpID0gMDsgaSA8IHN0eWxlcy5sZW5ndGg7IGkrKykge1xuXHRcdHZhciBpdGVtID0gc3R5bGVzW2ldO1xuXHRcdHZhciBkb21TdHlsZSA9IHN0eWxlc0luRG9tW2l0ZW0uaWRdO1xuXG5cdFx0aWYoZG9tU3R5bGUpIHtcblx0XHRcdGRvbVN0eWxlLnJlZnMrKztcblxuXHRcdFx0Zm9yKHZhciBqID0gMDsgaiA8IGRvbVN0eWxlLnBhcnRzLmxlbmd0aDsgaisrKSB7XG5cdFx0XHRcdGRvbVN0eWxlLnBhcnRzW2pdKGl0ZW0ucGFydHNbal0pO1xuXHRcdFx0fVxuXG5cdFx0XHRmb3IoOyBqIDwgaXRlbS5wYXJ0cy5sZW5ndGg7IGorKykge1xuXHRcdFx0XHRkb21TdHlsZS5wYXJ0cy5wdXNoKGFkZFN0eWxlKGl0ZW0ucGFydHNbal0sIG9wdGlvbnMpKTtcblx0XHRcdH1cblx0XHR9IGVsc2Uge1xuXHRcdFx0dmFyIHBhcnRzID0gW107XG5cblx0XHRcdGZvcih2YXIgaiA9IDA7IGogPCBpdGVtLnBhcnRzLmxlbmd0aDsgaisrKSB7XG5cdFx0XHRcdHBhcnRzLnB1c2goYWRkU3R5bGUoaXRlbS5wYXJ0c1tqXSwgb3B0aW9ucykpO1xuXHRcdFx0fVxuXG5cdFx0XHRzdHlsZXNJbkRvbVtpdGVtLmlkXSA9IHtpZDogaXRlbS5pZCwgcmVmczogMSwgcGFydHM6IHBhcnRzfTtcblx0XHR9XG5cdH1cbn1cblxuZnVuY3Rpb24gbGlzdFRvU3R5bGVzIChsaXN0LCBvcHRpb25zKSB7XG5cdHZhciBzdHlsZXMgPSBbXTtcblx0dmFyIG5ld1N0eWxlcyA9IHt9O1xuXG5cdGZvciAodmFyIGkgPSAwOyBpIDwgbGlzdC5sZW5ndGg7IGkrKykge1xuXHRcdHZhciBpdGVtID0gbGlzdFtpXTtcblx0XHR2YXIgaWQgPSBvcHRpb25zLmJhc2UgPyBpdGVtWzBdICsgb3B0aW9ucy5iYXNlIDogaXRlbVswXTtcblx0XHR2YXIgY3NzID0gaXRlbVsxXTtcblx0XHR2YXIgbWVkaWEgPSBpdGVtWzJdO1xuXHRcdHZhciBzb3VyY2VNYXAgPSBpdGVtWzNdO1xuXHRcdHZhciBwYXJ0ID0ge2NzczogY3NzLCBtZWRpYTogbWVkaWEsIHNvdXJjZU1hcDogc291cmNlTWFwfTtcblxuXHRcdGlmKCFuZXdTdHlsZXNbaWRdKSBzdHlsZXMucHVzaChuZXdTdHlsZXNbaWRdID0ge2lkOiBpZCwgcGFydHM6IFtwYXJ0XX0pO1xuXHRcdGVsc2UgbmV3U3R5bGVzW2lkXS5wYXJ0cy5wdXNoKHBhcnQpO1xuXHR9XG5cblx0cmV0dXJuIHN0eWxlcztcbn1cblxuZnVuY3Rpb24gaW5zZXJ0U3R5bGVFbGVtZW50IChvcHRpb25zLCBzdHlsZSkge1xuXHR2YXIgdGFyZ2V0ID0gZ2V0RWxlbWVudChvcHRpb25zLmluc2VydEludG8pXG5cblx0aWYgKCF0YXJnZXQpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoXCJDb3VsZG4ndCBmaW5kIGEgc3R5bGUgdGFyZ2V0LiBUaGlzIHByb2JhYmx5IG1lYW5zIHRoYXQgdGhlIHZhbHVlIGZvciB0aGUgJ2luc2VydEludG8nIHBhcmFtZXRlciBpcyBpbnZhbGlkLlwiKTtcblx0fVxuXG5cdHZhciBsYXN0U3R5bGVFbGVtZW50SW5zZXJ0ZWRBdFRvcCA9IHN0eWxlc0luc2VydGVkQXRUb3Bbc3R5bGVzSW5zZXJ0ZWRBdFRvcC5sZW5ndGggLSAxXTtcblxuXHRpZiAob3B0aW9ucy5pbnNlcnRBdCA9PT0gXCJ0b3BcIikge1xuXHRcdGlmICghbGFzdFN0eWxlRWxlbWVudEluc2VydGVkQXRUb3ApIHtcblx0XHRcdHRhcmdldC5pbnNlcnRCZWZvcmUoc3R5bGUsIHRhcmdldC5maXJzdENoaWxkKTtcblx0XHR9IGVsc2UgaWYgKGxhc3RTdHlsZUVsZW1lbnRJbnNlcnRlZEF0VG9wLm5leHRTaWJsaW5nKSB7XG5cdFx0XHR0YXJnZXQuaW5zZXJ0QmVmb3JlKHN0eWxlLCBsYXN0U3R5bGVFbGVtZW50SW5zZXJ0ZWRBdFRvcC5uZXh0U2libGluZyk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHRhcmdldC5hcHBlbmRDaGlsZChzdHlsZSk7XG5cdFx0fVxuXHRcdHN0eWxlc0luc2VydGVkQXRUb3AucHVzaChzdHlsZSk7XG5cdH0gZWxzZSBpZiAob3B0aW9ucy5pbnNlcnRBdCA9PT0gXCJib3R0b21cIikge1xuXHRcdHRhcmdldC5hcHBlbmRDaGlsZChzdHlsZSk7XG5cdH0gZWxzZSBpZiAodHlwZW9mIG9wdGlvbnMuaW5zZXJ0QXQgPT09IFwib2JqZWN0XCIgJiYgb3B0aW9ucy5pbnNlcnRBdC5iZWZvcmUpIHtcblx0XHR2YXIgbmV4dFNpYmxpbmcgPSBnZXRFbGVtZW50KG9wdGlvbnMuaW5zZXJ0SW50byArIFwiIFwiICsgb3B0aW9ucy5pbnNlcnRBdC5iZWZvcmUpO1xuXHRcdHRhcmdldC5pbnNlcnRCZWZvcmUoc3R5bGUsIG5leHRTaWJsaW5nKTtcblx0fSBlbHNlIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoXCJbU3R5bGUgTG9hZGVyXVxcblxcbiBJbnZhbGlkIHZhbHVlIGZvciBwYXJhbWV0ZXIgJ2luc2VydEF0JyAoJ29wdGlvbnMuaW5zZXJ0QXQnKSBmb3VuZC5cXG4gTXVzdCBiZSAndG9wJywgJ2JvdHRvbScsIG9yIE9iamVjdC5cXG4gKGh0dHBzOi8vZ2l0aHViLmNvbS93ZWJwYWNrLWNvbnRyaWIvc3R5bGUtbG9hZGVyI2luc2VydGF0KVxcblwiKTtcblx0fVxufVxuXG5mdW5jdGlvbiByZW1vdmVTdHlsZUVsZW1lbnQgKHN0eWxlKSB7XG5cdGlmIChzdHlsZS5wYXJlbnROb2RlID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdHN0eWxlLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc3R5bGUpO1xuXG5cdHZhciBpZHggPSBzdHlsZXNJbnNlcnRlZEF0VG9wLmluZGV4T2Yoc3R5bGUpO1xuXHRpZihpZHggPj0gMCkge1xuXHRcdHN0eWxlc0luc2VydGVkQXRUb3Auc3BsaWNlKGlkeCwgMSk7XG5cdH1cbn1cblxuZnVuY3Rpb24gY3JlYXRlU3R5bGVFbGVtZW50IChvcHRpb25zKSB7XG5cdHZhciBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzdHlsZVwiKTtcblxuXHRvcHRpb25zLmF0dHJzLnR5cGUgPSBcInRleHQvY3NzXCI7XG5cblx0YWRkQXR0cnMoc3R5bGUsIG9wdGlvbnMuYXR0cnMpO1xuXHRpbnNlcnRTdHlsZUVsZW1lbnQob3B0aW9ucywgc3R5bGUpO1xuXG5cdHJldHVybiBzdHlsZTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlTGlua0VsZW1lbnQgKG9wdGlvbnMpIHtcblx0dmFyIGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlua1wiKTtcblxuXHRvcHRpb25zLmF0dHJzLnR5cGUgPSBcInRleHQvY3NzXCI7XG5cdG9wdGlvbnMuYXR0cnMucmVsID0gXCJzdHlsZXNoZWV0XCI7XG5cblx0YWRkQXR0cnMobGluaywgb3B0aW9ucy5hdHRycyk7XG5cdGluc2VydFN0eWxlRWxlbWVudChvcHRpb25zLCBsaW5rKTtcblxuXHRyZXR1cm4gbGluaztcbn1cblxuZnVuY3Rpb24gYWRkQXR0cnMgKGVsLCBhdHRycykge1xuXHRPYmplY3Qua2V5cyhhdHRycykuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7XG5cdFx0ZWwuc2V0QXR0cmlidXRlKGtleSwgYXR0cnNba2V5XSk7XG5cdH0pO1xufVxuXG5mdW5jdGlvbiBhZGRTdHlsZSAob2JqLCBvcHRpb25zKSB7XG5cdHZhciBzdHlsZSwgdXBkYXRlLCByZW1vdmUsIHJlc3VsdDtcblxuXHQvLyBJZiBhIHRyYW5zZm9ybSBmdW5jdGlvbiB3YXMgZGVmaW5lZCwgcnVuIGl0IG9uIHRoZSBjc3Ncblx0aWYgKG9wdGlvbnMudHJhbnNmb3JtICYmIG9iai5jc3MpIHtcblx0ICAgIHJlc3VsdCA9IG9wdGlvbnMudHJhbnNmb3JtKG9iai5jc3MpO1xuXG5cdCAgICBpZiAocmVzdWx0KSB7XG5cdCAgICBcdC8vIElmIHRyYW5zZm9ybSByZXR1cm5zIGEgdmFsdWUsIHVzZSB0aGF0IGluc3RlYWQgb2YgdGhlIG9yaWdpbmFsIGNzcy5cblx0ICAgIFx0Ly8gVGhpcyBhbGxvd3MgcnVubmluZyBydW50aW1lIHRyYW5zZm9ybWF0aW9ucyBvbiB0aGUgY3NzLlxuXHQgICAgXHRvYmouY3NzID0gcmVzdWx0O1xuXHQgICAgfSBlbHNlIHtcblx0ICAgIFx0Ly8gSWYgdGhlIHRyYW5zZm9ybSBmdW5jdGlvbiByZXR1cm5zIGEgZmFsc3kgdmFsdWUsIGRvbid0IGFkZCB0aGlzIGNzcy5cblx0ICAgIFx0Ly8gVGhpcyBhbGxvd3MgY29uZGl0aW9uYWwgbG9hZGluZyBvZiBjc3Ncblx0ICAgIFx0cmV0dXJuIGZ1bmN0aW9uKCkge1xuXHQgICAgXHRcdC8vIG5vb3Bcblx0ICAgIFx0fTtcblx0ICAgIH1cblx0fVxuXG5cdGlmIChvcHRpb25zLnNpbmdsZXRvbikge1xuXHRcdHZhciBzdHlsZUluZGV4ID0gc2luZ2xldG9uQ291bnRlcisrO1xuXG5cdFx0c3R5bGUgPSBzaW5nbGV0b24gfHwgKHNpbmdsZXRvbiA9IGNyZWF0ZVN0eWxlRWxlbWVudChvcHRpb25zKSk7XG5cblx0XHR1cGRhdGUgPSBhcHBseVRvU2luZ2xldG9uVGFnLmJpbmQobnVsbCwgc3R5bGUsIHN0eWxlSW5kZXgsIGZhbHNlKTtcblx0XHRyZW1vdmUgPSBhcHBseVRvU2luZ2xldG9uVGFnLmJpbmQobnVsbCwgc3R5bGUsIHN0eWxlSW5kZXgsIHRydWUpO1xuXG5cdH0gZWxzZSBpZiAoXG5cdFx0b2JqLnNvdXJjZU1hcCAmJlxuXHRcdHR5cGVvZiBVUkwgPT09IFwiZnVuY3Rpb25cIiAmJlxuXHRcdHR5cGVvZiBVUkwuY3JlYXRlT2JqZWN0VVJMID09PSBcImZ1bmN0aW9uXCIgJiZcblx0XHR0eXBlb2YgVVJMLnJldm9rZU9iamVjdFVSTCA9PT0gXCJmdW5jdGlvblwiICYmXG5cdFx0dHlwZW9mIEJsb2IgPT09IFwiZnVuY3Rpb25cIiAmJlxuXHRcdHR5cGVvZiBidG9hID09PSBcImZ1bmN0aW9uXCJcblx0KSB7XG5cdFx0c3R5bGUgPSBjcmVhdGVMaW5rRWxlbWVudChvcHRpb25zKTtcblx0XHR1cGRhdGUgPSB1cGRhdGVMaW5rLmJpbmQobnVsbCwgc3R5bGUsIG9wdGlvbnMpO1xuXHRcdHJlbW92ZSA9IGZ1bmN0aW9uICgpIHtcblx0XHRcdHJlbW92ZVN0eWxlRWxlbWVudChzdHlsZSk7XG5cblx0XHRcdGlmKHN0eWxlLmhyZWYpIFVSTC5yZXZva2VPYmplY3RVUkwoc3R5bGUuaHJlZik7XG5cdFx0fTtcblx0fSBlbHNlIHtcblx0XHRzdHlsZSA9IGNyZWF0ZVN0eWxlRWxlbWVudChvcHRpb25zKTtcblx0XHR1cGRhdGUgPSBhcHBseVRvVGFnLmJpbmQobnVsbCwgc3R5bGUpO1xuXHRcdHJlbW92ZSA9IGZ1bmN0aW9uICgpIHtcblx0XHRcdHJlbW92ZVN0eWxlRWxlbWVudChzdHlsZSk7XG5cdFx0fTtcblx0fVxuXG5cdHVwZGF0ZShvYmopO1xuXG5cdHJldHVybiBmdW5jdGlvbiB1cGRhdGVTdHlsZSAobmV3T2JqKSB7XG5cdFx0aWYgKG5ld09iaikge1xuXHRcdFx0aWYgKFxuXHRcdFx0XHRuZXdPYmouY3NzID09PSBvYmouY3NzICYmXG5cdFx0XHRcdG5ld09iai5tZWRpYSA9PT0gb2JqLm1lZGlhICYmXG5cdFx0XHRcdG5ld09iai5zb3VyY2VNYXAgPT09IG9iai5zb3VyY2VNYXBcblx0XHRcdCkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdHVwZGF0ZShvYmogPSBuZXdPYmopO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRyZW1vdmUoKTtcblx0XHR9XG5cdH07XG59XG5cbnZhciByZXBsYWNlVGV4dCA9IChmdW5jdGlvbiAoKSB7XG5cdHZhciB0ZXh0U3RvcmUgPSBbXTtcblxuXHRyZXR1cm4gZnVuY3Rpb24gKGluZGV4LCByZXBsYWNlbWVudCkge1xuXHRcdHRleHRTdG9yZVtpbmRleF0gPSByZXBsYWNlbWVudDtcblxuXHRcdHJldHVybiB0ZXh0U3RvcmUuZmlsdGVyKEJvb2xlYW4pLmpvaW4oJ1xcbicpO1xuXHR9O1xufSkoKTtcblxuZnVuY3Rpb24gYXBwbHlUb1NpbmdsZXRvblRhZyAoc3R5bGUsIGluZGV4LCByZW1vdmUsIG9iaikge1xuXHR2YXIgY3NzID0gcmVtb3ZlID8gXCJcIiA6IG9iai5jc3M7XG5cblx0aWYgKHN0eWxlLnN0eWxlU2hlZXQpIHtcblx0XHRzdHlsZS5zdHlsZVNoZWV0LmNzc1RleHQgPSByZXBsYWNlVGV4dChpbmRleCwgY3NzKTtcblx0fSBlbHNlIHtcblx0XHR2YXIgY3NzTm9kZSA9IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNzcyk7XG5cdFx0dmFyIGNoaWxkTm9kZXMgPSBzdHlsZS5jaGlsZE5vZGVzO1xuXG5cdFx0aWYgKGNoaWxkTm9kZXNbaW5kZXhdKSBzdHlsZS5yZW1vdmVDaGlsZChjaGlsZE5vZGVzW2luZGV4XSk7XG5cblx0XHRpZiAoY2hpbGROb2Rlcy5sZW5ndGgpIHtcblx0XHRcdHN0eWxlLmluc2VydEJlZm9yZShjc3NOb2RlLCBjaGlsZE5vZGVzW2luZGV4XSk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHN0eWxlLmFwcGVuZENoaWxkKGNzc05vZGUpO1xuXHRcdH1cblx0fVxufVxuXG5mdW5jdGlvbiBhcHBseVRvVGFnIChzdHlsZSwgb2JqKSB7XG5cdHZhciBjc3MgPSBvYmouY3NzO1xuXHR2YXIgbWVkaWEgPSBvYmoubWVkaWE7XG5cblx0aWYobWVkaWEpIHtcblx0XHRzdHlsZS5zZXRBdHRyaWJ1dGUoXCJtZWRpYVwiLCBtZWRpYSlcblx0fVxuXG5cdGlmKHN0eWxlLnN0eWxlU2hlZXQpIHtcblx0XHRzdHlsZS5zdHlsZVNoZWV0LmNzc1RleHQgPSBjc3M7XG5cdH0gZWxzZSB7XG5cdFx0d2hpbGUoc3R5bGUuZmlyc3RDaGlsZCkge1xuXHRcdFx0c3R5bGUucmVtb3ZlQ2hpbGQoc3R5bGUuZmlyc3RDaGlsZCk7XG5cdFx0fVxuXG5cdFx0c3R5bGUuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY3NzKSk7XG5cdH1cbn1cblxuZnVuY3Rpb24gdXBkYXRlTGluayAobGluaywgb3B0aW9ucywgb2JqKSB7XG5cdHZhciBjc3MgPSBvYmouY3NzO1xuXHR2YXIgc291cmNlTWFwID0gb2JqLnNvdXJjZU1hcDtcblxuXHQvKlxuXHRcdElmIGNvbnZlcnRUb0Fic29sdXRlVXJscyBpc24ndCBkZWZpbmVkLCBidXQgc291cmNlbWFwcyBhcmUgZW5hYmxlZFxuXHRcdGFuZCB0aGVyZSBpcyBubyBwdWJsaWNQYXRoIGRlZmluZWQgdGhlbiBsZXRzIHR1cm4gY29udmVydFRvQWJzb2x1dGVVcmxzXG5cdFx0b24gYnkgZGVmYXVsdC4gIE90aGVyd2lzZSBkZWZhdWx0IHRvIHRoZSBjb252ZXJ0VG9BYnNvbHV0ZVVybHMgb3B0aW9uXG5cdFx0ZGlyZWN0bHlcblx0Ki9cblx0dmFyIGF1dG9GaXhVcmxzID0gb3B0aW9ucy5jb252ZXJ0VG9BYnNvbHV0ZVVybHMgPT09IHVuZGVmaW5lZCAmJiBzb3VyY2VNYXA7XG5cblx0aWYgKG9wdGlvbnMuY29udmVydFRvQWJzb2x1dGVVcmxzIHx8IGF1dG9GaXhVcmxzKSB7XG5cdFx0Y3NzID0gZml4VXJscyhjc3MpO1xuXHR9XG5cblx0aWYgKHNvdXJjZU1hcCkge1xuXHRcdC8vIGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9hLzI2NjAzODc1XG5cdFx0Y3NzICs9IFwiXFxuLyojIHNvdXJjZU1hcHBpbmdVUkw9ZGF0YTphcHBsaWNhdGlvbi9qc29uO2Jhc2U2NCxcIiArIGJ0b2EodW5lc2NhcGUoZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KHNvdXJjZU1hcCkpKSkgKyBcIiAqL1wiO1xuXHR9XG5cblx0dmFyIGJsb2IgPSBuZXcgQmxvYihbY3NzXSwgeyB0eXBlOiBcInRleHQvY3NzXCIgfSk7XG5cblx0dmFyIG9sZFNyYyA9IGxpbmsuaHJlZjtcblxuXHRsaW5rLmhyZWYgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuXG5cdGlmKG9sZFNyYykgVVJMLnJldm9rZU9iamVjdFVSTChvbGRTcmMpO1xufVxuIiwiXG4vKipcbiAqIFdoZW4gc291cmNlIG1hcHMgYXJlIGVuYWJsZWQsIGBzdHlsZS1sb2FkZXJgIHVzZXMgYSBsaW5rIGVsZW1lbnQgd2l0aCBhIGRhdGEtdXJpIHRvXG4gKiBlbWJlZCB0aGUgY3NzIG9uIHRoZSBwYWdlLiBUaGlzIGJyZWFrcyBhbGwgcmVsYXRpdmUgdXJscyBiZWNhdXNlIG5vdyB0aGV5IGFyZSByZWxhdGl2ZSB0byBhXG4gKiBidW5kbGUgaW5zdGVhZCBvZiB0aGUgY3VycmVudCBwYWdlLlxuICpcbiAqIE9uZSBzb2x1dGlvbiBpcyB0byBvbmx5IHVzZSBmdWxsIHVybHMsIGJ1dCB0aGF0IG1heSBiZSBpbXBvc3NpYmxlLlxuICpcbiAqIEluc3RlYWQsIHRoaXMgZnVuY3Rpb24gXCJmaXhlc1wiIHRoZSByZWxhdGl2ZSB1cmxzIHRvIGJlIGFic29sdXRlIGFjY29yZGluZyB0byB0aGUgY3VycmVudCBwYWdlIGxvY2F0aW9uLlxuICpcbiAqIEEgcnVkaW1lbnRhcnkgdGVzdCBzdWl0ZSBpcyBsb2NhdGVkIGF0IGB0ZXN0L2ZpeFVybHMuanNgIGFuZCBjYW4gYmUgcnVuIHZpYSB0aGUgYG5wbSB0ZXN0YCBjb21tYW5kLlxuICpcbiAqL1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChjc3MpIHtcbiAgLy8gZ2V0IGN1cnJlbnQgbG9jYXRpb25cbiAgdmFyIGxvY2F0aW9uID0gdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB3aW5kb3cubG9jYXRpb247XG5cbiAgaWYgKCFsb2NhdGlvbikge1xuICAgIHRocm93IG5ldyBFcnJvcihcImZpeFVybHMgcmVxdWlyZXMgd2luZG93LmxvY2F0aW9uXCIpO1xuICB9XG5cblx0Ly8gYmxhbmsgb3IgbnVsbD9cblx0aWYgKCFjc3MgfHwgdHlwZW9mIGNzcyAhPT0gXCJzdHJpbmdcIikge1xuXHQgIHJldHVybiBjc3M7XG4gIH1cblxuICB2YXIgYmFzZVVybCA9IGxvY2F0aW9uLnByb3RvY29sICsgXCIvL1wiICsgbG9jYXRpb24uaG9zdDtcbiAgdmFyIGN1cnJlbnREaXIgPSBiYXNlVXJsICsgbG9jYXRpb24ucGF0aG5hbWUucmVwbGFjZSgvXFwvW15cXC9dKiQvLCBcIi9cIik7XG5cblx0Ly8gY29udmVydCBlYWNoIHVybCguLi4pXG5cdC8qXG5cdFRoaXMgcmVndWxhciBleHByZXNzaW9uIGlzIGp1c3QgYSB3YXkgdG8gcmVjdXJzaXZlbHkgbWF0Y2ggYnJhY2tldHMgd2l0aGluXG5cdGEgc3RyaW5nLlxuXG5cdCAvdXJsXFxzKlxcKCAgPSBNYXRjaCBvbiB0aGUgd29yZCBcInVybFwiIHdpdGggYW55IHdoaXRlc3BhY2UgYWZ0ZXIgaXQgYW5kIHRoZW4gYSBwYXJlbnNcblx0ICAgKCAgPSBTdGFydCBhIGNhcHR1cmluZyBncm91cFxuXHQgICAgICg/OiAgPSBTdGFydCBhIG5vbi1jYXB0dXJpbmcgZ3JvdXBcblx0ICAgICAgICAgW14pKF0gID0gTWF0Y2ggYW55dGhpbmcgdGhhdCBpc24ndCBhIHBhcmVudGhlc2VzXG5cdCAgICAgICAgIHwgID0gT1Jcblx0ICAgICAgICAgXFwoICA9IE1hdGNoIGEgc3RhcnQgcGFyZW50aGVzZXNcblx0ICAgICAgICAgICAgICg/OiAgPSBTdGFydCBhbm90aGVyIG5vbi1jYXB0dXJpbmcgZ3JvdXBzXG5cdCAgICAgICAgICAgICAgICAgW14pKF0rICA9IE1hdGNoIGFueXRoaW5nIHRoYXQgaXNuJ3QgYSBwYXJlbnRoZXNlc1xuXHQgICAgICAgICAgICAgICAgIHwgID0gT1Jcblx0ICAgICAgICAgICAgICAgICBcXCggID0gTWF0Y2ggYSBzdGFydCBwYXJlbnRoZXNlc1xuXHQgICAgICAgICAgICAgICAgICAgICBbXikoXSogID0gTWF0Y2ggYW55dGhpbmcgdGhhdCBpc24ndCBhIHBhcmVudGhlc2VzXG5cdCAgICAgICAgICAgICAgICAgXFwpICA9IE1hdGNoIGEgZW5kIHBhcmVudGhlc2VzXG5cdCAgICAgICAgICAgICApICA9IEVuZCBHcm91cFxuICAgICAgICAgICAgICAqXFwpID0gTWF0Y2ggYW55dGhpbmcgYW5kIHRoZW4gYSBjbG9zZSBwYXJlbnNcbiAgICAgICAgICApICA9IENsb3NlIG5vbi1jYXB0dXJpbmcgZ3JvdXBcbiAgICAgICAgICAqICA9IE1hdGNoIGFueXRoaW5nXG4gICAgICAgKSAgPSBDbG9zZSBjYXB0dXJpbmcgZ3JvdXBcblx0IFxcKSAgPSBNYXRjaCBhIGNsb3NlIHBhcmVuc1xuXG5cdCAvZ2kgID0gR2V0IGFsbCBtYXRjaGVzLCBub3QgdGhlIGZpcnN0LiAgQmUgY2FzZSBpbnNlbnNpdGl2ZS5cblx0ICovXG5cdHZhciBmaXhlZENzcyA9IGNzcy5yZXBsYWNlKC91cmxcXHMqXFwoKCg/OlteKShdfFxcKCg/OlteKShdK3xcXChbXikoXSpcXCkpKlxcKSkqKVxcKS9naSwgZnVuY3Rpb24oZnVsbE1hdGNoLCBvcmlnVXJsKSB7XG5cdFx0Ly8gc3RyaXAgcXVvdGVzIChpZiB0aGV5IGV4aXN0KVxuXHRcdHZhciB1bnF1b3RlZE9yaWdVcmwgPSBvcmlnVXJsXG5cdFx0XHQudHJpbSgpXG5cdFx0XHQucmVwbGFjZSgvXlwiKC4qKVwiJC8sIGZ1bmN0aW9uKG8sICQxKXsgcmV0dXJuICQxOyB9KVxuXHRcdFx0LnJlcGxhY2UoL14nKC4qKSckLywgZnVuY3Rpb24obywgJDEpeyByZXR1cm4gJDE7IH0pO1xuXG5cdFx0Ly8gYWxyZWFkeSBhIGZ1bGwgdXJsPyBubyBjaGFuZ2Vcblx0XHRpZiAoL14oI3xkYXRhOnxodHRwOlxcL1xcL3xodHRwczpcXC9cXC98ZmlsZTpcXC9cXC9cXC98XFxzKiQpL2kudGVzdCh1bnF1b3RlZE9yaWdVcmwpKSB7XG5cdFx0ICByZXR1cm4gZnVsbE1hdGNoO1xuXHRcdH1cblxuXHRcdC8vIGNvbnZlcnQgdGhlIHVybCB0byBhIGZ1bGwgdXJsXG5cdFx0dmFyIG5ld1VybDtcblxuXHRcdGlmICh1bnF1b3RlZE9yaWdVcmwuaW5kZXhPZihcIi8vXCIpID09PSAwKSB7XG5cdFx0ICBcdC8vVE9ETzogc2hvdWxkIHdlIGFkZCBwcm90b2NvbD9cblx0XHRcdG5ld1VybCA9IHVucXVvdGVkT3JpZ1VybDtcblx0XHR9IGVsc2UgaWYgKHVucXVvdGVkT3JpZ1VybC5pbmRleE9mKFwiL1wiKSA9PT0gMCkge1xuXHRcdFx0Ly8gcGF0aCBzaG91bGQgYmUgcmVsYXRpdmUgdG8gdGhlIGJhc2UgdXJsXG5cdFx0XHRuZXdVcmwgPSBiYXNlVXJsICsgdW5xdW90ZWRPcmlnVXJsOyAvLyBhbHJlYWR5IHN0YXJ0cyB3aXRoICcvJ1xuXHRcdH0gZWxzZSB7XG5cdFx0XHQvLyBwYXRoIHNob3VsZCBiZSByZWxhdGl2ZSB0byBjdXJyZW50IGRpcmVjdG9yeVxuXHRcdFx0bmV3VXJsID0gY3VycmVudERpciArIHVucXVvdGVkT3JpZ1VybC5yZXBsYWNlKC9eXFwuXFwvLywgXCJcIik7IC8vIFN0cmlwIGxlYWRpbmcgJy4vJ1xuXHRcdH1cblxuXHRcdC8vIHNlbmQgYmFjayB0aGUgZml4ZWQgdXJsKC4uLilcblx0XHRyZXR1cm4gXCJ1cmwoXCIgKyBKU09OLnN0cmluZ2lmeShuZXdVcmwpICsgXCIpXCI7XG5cdH0pO1xuXG5cdC8vIHNlbmQgYmFjayB0aGUgZml4ZWQgY3NzXG5cdHJldHVybiBmaXhlZENzcztcbn07XG4iLCJpbXBvcnQgY2xpY2tFbGVtZW50IGZyb20gXCIuL2hlbHBlcnMvY2xpY2tFbGVtZW50XCI7XHJcbmltcG9ydCBnZXRMaXN0SXRlbXMgZnJvbSBcIi4vaGVscGVycy9nZXRMaXN0SXRlbXNcIjtcclxuaW1wb3J0IGlzVXNlck9uU2VhcmNoUmVzdWx0c1BhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlXCI7XHJcbmltcG9ydCBpc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZSBmcm9tIFwiLi9oZWxwZXJzL2lzVXNlck9uU2VhcmNoVHJhbnNmZXJNYXJrZXRQYWdlXCI7XHJcbmltcG9ydCBpc1VzZXJPblRyYW5zZmVyc1BhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblRyYW5zZmVyc1BhZ2VcIjtcclxuaW1wb3J0IGlzVXNlck9uVHJhbnNmZXJUYXJnZXRzUGFnZSBmcm9tIFwiLi9oZWxwZXJzL2lzVXNlck9uVHJhbnNmZXJUYXJnZXRzUGFnZVwiO1xyXG5pbXBvcnQgaXNVc2VyT25VbmFzc2lnbmVkUGFnZSBmcm9tIFwiLi9oZWxwZXJzL2lzVXNlck9uVW5hc3NpZ25lZFBhZ2VcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGdvQmFjaygpIHtcclxuICAgIC8vIFByaW9yaXRpemVzIGJhY2sgYnV0dG9uIGluIHNlY29uZGFyeSBuYXYuXHJcbiAgICBjb25zdCBzZWNvbmRhcnlIZWFkZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxyXG4gICAgICAgIFwibmF2YmFyLXN0eWxlLXNlY29uZGFyeVwiXHJcbiAgICApWzBdO1xyXG5cclxuICAgIGlmIChzZWNvbmRhcnlIZWFkZXIgJiYgc2Vjb25kYXJ5SGVhZGVyLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYnV0dG9uXCIpWzBdKSB7XHJcbiAgICAgICAgY2xpY2tFbGVtZW50KHNlY29uZGFyeUhlYWRlci5nZXRFbGVtZW50c0J5VGFnTmFtZShcImJ1dHRvblwiKVswXSk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEZhbGxzIGJhY2sgdG8gcHJpbWFyeSBuYXYgYmFjayBidXR0b24uXHJcbiAgICBpZiAoXHJcbiAgICAgICAgaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UoKSB8fFxyXG4gICAgICAgIGlzVXNlck9uU2VhcmNoUmVzdWx0c1BhZ2UoKSB8fFxyXG4gICAgICAgIGlzVXNlck9uVW5hc3NpZ25lZFBhZ2UoKSB8fFxyXG4gICAgICAgIGlzVXNlck9uVHJhbnNmZXJzUGFnZSgpIHx8XHJcbiAgICAgICAgaXNVc2VyT25UcmFuc2ZlclRhcmdldHNQYWdlKClcclxuICAgICkge1xyXG4gICAgICAgIGlmIChpc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlKCkpIHtcclxuICAgICAgICAgICAgY29uc3QgaGFzU2VhcmNoUmVzdWx0cyA9IGdldExpc3RJdGVtcygpLmxlbmd0aCA+IDA7XHJcblxyXG4gICAgICAgICAgICAvLyBJZiB0aGVyZSBhcmUgbm8gcmVzdWx0cywgd2UnbGwgZ28gYmFjayByZWdhcmRsZXNzLlxyXG4gICAgICAgICAgICBpZiAoIWhhc1NlYXJjaFJlc3VsdHMpIHtcclxuICAgICAgICAgICAgICAgIGNsaWNrRWxlbWVudChcclxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcInV0LW5hdmlnYXRpb24tYnV0dG9uLWNvbnRyb2xcIlxyXG4gICAgICAgICAgICAgICAgICAgIClbMF1cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIElmIHRoZXJlIGFyZSByZXN1bHRzLCBjaGVjayBzZXR0aW5nIGFuZCBpZiBsYXN0IHNlYXJjaCB3YXMgbGVzcyB0aGFuIDIuNSBzZWNvbmRzIGFnby5cclxuICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoW1wibGFzdFNlYXJjaFRpbWVcIiwgXCJkaXNhYmxlQmFja1wiXSwgZGF0YSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB7IGxhc3RTZWFyY2hUaW1lLCBkaXNhYmxlQmFjayB9ID0gZGF0YTtcclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdGltZVNpbmNlU2VhcmNoID0gbm93IC0gKGxhc3RTZWFyY2hUaW1lIHx8IDApO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0aW1lU2luY2VTZWFyY2ggPCAyNTAwICYmIGRpc2FibGVCYWNrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjbGlja0VsZW1lbnQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInV0LW5hdmlnYXRpb24tYnV0dG9uLWNvbnRyb2xcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY2xpY2tFbGVtZW50KFxyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgICAgICAgICAgICAgICAgICBcInV0LW5hdmlnYXRpb24tYnV0dG9uLWNvbnRyb2xcIlxyXG4gICAgICAgICAgICAgICAgKVswXVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgY29uZmlybUNvbmZpcm1hdGlvbkRpYWxvZyBmcm9tIFwiLi9oZWxwZXJzL2NvbmZpcm1Db25maXJtYXRpb25EaWFsb2dcIjtcclxuaW1wb3J0IGlzVXNlck9uU2VhcmNoUmVzdWx0c1BhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlXCI7XHJcbmltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vaGVscGVycy9jbGlja0VsZW1lbnRcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGJ1eU5vdygpIHtcclxuICAgIGlmIChpc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlKCkpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBidXlDYXJkKCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHt9XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGJ1eUNhcmQoKSB7XHJcbiAgICBjbGlja0J1eU5vd0J1dHRvbigpO1xyXG5cclxuICAgIGNvbnN0IHRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgICAgIGNvbmZpcm1Db25maXJtYXRpb25EaWFsb2coKCkgPT4ge1xyXG4gICAgICAgICAgICBjbGVhckludGVydmFsKHRpbWVyKTtcclxuICAgICAgICB9KTtcclxuICAgIH0sIDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBjbGlja0J1eU5vd0J1dHRvbigpIHtcclxuICAgIGNvbnN0IGJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJidXlCdXR0b25cIilbMF07XHJcbiAgICBjbGlja0VsZW1lbnQoYnV0dG9uKTtcclxufVxyXG4iLCJpbXBvcnQgY2xpY2tFbGVtZW50IGZyb20gXCIuL2hlbHBlcnMvY2xpY2tFbGVtZW50XCI7XG5pbXBvcnQgaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZVwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBkZWNyZWFzZU1heEJpblByaWNlKCkge1xuICAgIGlmIChpc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZSgpKSB7XG4gICAgICAgIGNvbnN0IGJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJkZWNyZW1lbnQtdmFsdWVcIilbM107XG4gICAgICAgIGNsaWNrRWxlbWVudChidXR0b24pO1xuICAgIH1cbn1cbiIsImltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vY2xpY2tFbGVtZW50XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNsaWNrRGV0YWlsc1BhbmVsQnV0dG9uKGJ1dHRvbkxhYmVsOiBzdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgICAvLyBFeHBhbmQgXCJMaXN0IG9uIFRyYW5zZmVyIE1hcmtldFwiIHNlY3Rpb24uXG4gICAgICAgIGlmIChidXR0b25MYWJlbCA9PT0gXCJMaXN0IEl0ZW1cIikge1xuICAgICAgICAgICAgY29uc3QgX2J1dHRvbnMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImJ1dHRvblwiKTtcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvbnMgPSBBcnJheS5mcm9tKF9idXR0b25zKTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgYnV0dG9uIG9mIGJ1dHRvbnMpIHtcbiAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbiAmJlxuICAgICAgICAgICAgICAgICAgICBidXR0b24uaW5uZXJIVE1MLmluZGV4T2YoXCJMaXN0IG9uIFRyYW5zZmVyIE1hcmtldFwiKSA+IC0xXG4gICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgIGNsaWNrRWxlbWVudChidXR0b24pO1xuXG4gICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gR2V0IGJ1dHRvbnMgaW4gdGhlIGRldGFpbHMgcGFuZWwuXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkZXRhaWxzUGFuZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiRGV0YWlsUGFuZWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgKVswXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRldGFpbHNQYW5lbEJ1dHRvbnMgPSBkZXRhaWxzUGFuZWwuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1dHRvbkFycmF5ID0gQXJyYXkuZnJvbShkZXRhaWxzUGFuZWxCdXR0b25zKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gRmluZCB0YXJnZXQgYnV0dG9uIGJ5IHNlYXJjaGluZyBieSBsYWJlbC5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IF9idXR0b24gPSBidXR0b25BcnJheS5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX19idXR0b24gPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX19idXR0b24uaW5uZXJIVE1MLmluZGV4T2YoYnV0dG9uTGFiZWwpID4gLTEgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX19idXR0b24uc3R5bGUuZGlzcGxheSAhPT0gXCJub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIClbMF07XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIENsaWNrIHRhcmdldCBidXR0b24uXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGlja0VsZW1lbnQoX2J1dHRvbik7XG4gICAgICAgICAgICAgICAgICAgIH0sIDEwMDApO1xuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBHZXQgYnV0dG9ucyBpbiB0aGUgZGV0YWlscyBwYW5lbC5cbiAgICAgICAgY29uc3QgZGV0YWlsc1BhbmVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcIkRldGFpbFBhbmVsXCIpWzBdO1xuICAgICAgICBjb25zdCBkZXRhaWxzUGFuZWxCdXR0b25zID0gZGV0YWlsc1BhbmVsLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYnV0dG9uXCIpO1xuICAgICAgICBjb25zdCBidXR0b25BcnJheSA9IEFycmF5LmZyb20oZGV0YWlsc1BhbmVsQnV0dG9ucyk7XG5cbiAgICAgICAgLy8gRmluZCB0YXJnZXQgYnV0dG9uIGJ5IHNlYXJjaGluZyBieSBsYWJlbC5cbiAgICAgICAgY29uc3QgX2J1dHRvbiA9IGJ1dHRvbkFycmF5LmZpbHRlcihcbiAgICAgICAgICAgIGZvbyA9PlxuICAgICAgICAgICAgICAgIGZvby5pbm5lckhUTUwuaW5kZXhPZihidXR0b25MYWJlbCkgPiAtMSAmJlxuICAgICAgICAgICAgICAgIGZvby5zdHlsZS5kaXNwbGF5ICE9PSBcIm5vbmVcIlxuICAgICAgICApWzBdO1xuXG4gICAgICAgIC8vIENsaWNrIHRhcmdldCBidXR0b24uXG4gICAgICAgIGNsaWNrRWxlbWVudChfYnV0dG9uKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyBcIlVuYWJsZSB0byBmaW5kIHRoYXQgYnV0dG9uLlwiO1xuICAgIH1cbn1cbiIsIi8qKlxuICogU2ltdWxhdGVzIGEgY2xpY2sgb24gYW4gZWxlbWVudC5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gY2xpY2tFbGVtZW50KGVsZW1lbnQpIHtcbiAgICBzZW5kVG91Y2hFdmVudChlbGVtZW50LCAndG91Y2hzdGFydCcpO1xuICAgIHNlbmRUb3VjaEV2ZW50KGVsZW1lbnQsICd0b3VjaGVuZCcpO1xufVxuXG4vKipcbiAqIERpc3BhdGNoZXMgYSB0b3VjaCBldmVudCBvbiB0aGUgZWxlbWVudC5cbiAqIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vYS80MjQ0NzYyMFxuICpcbiAqIEBwYXJhbSB7SFRNTEVsZW1lbnR9IGVsZW1lbnRcbiAqIEBwYXJhbSB7c3RyaW5nfSBldmVudFR5cGVcbiAqL1xuZnVuY3Rpb24gc2VuZFRvdWNoRXZlbnQoZWxlbWVudCwgZXZlbnRUeXBlKSB7XG4gICAgLyoqXG4gICAgICogVG91Y2ggY29uc3RydWN0b3IgZG9lcyB0YWtlIGFuIG9iamVjdCBpbiBDaHJvbWUsIGJ1dCB0eXBpbmdzIGFyZW4ndCB1cGRhdGVkLFxuICAgICAqIHNvIGl0IHNob3dzIGFzIGFuIGVycm9yIHdoZW4gaW4gcmVhbGl0eSBpdCdzIGZpbmUuXG4gICAgICovXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIGNvbnN0IHRvdWNoID0gbmV3IFRvdWNoKHtcbiAgICAgICAgLy8gVXNpbmcgYSBudW1iZXIgbGlrZSBUUyBzdWdnZXN0IGJyZWFrcyB0aGlzLi4uIHN0dXBpZC5cbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICBpZGVudGlmaWVyOiBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKCksXG4gICAgICAgIHRhcmdldDogZWxlbWVudCxcbiAgICAgICAgY2xpZW50WDogTWF0aC5yYW5kb20oKSxcbiAgICAgICAgY2xpZW50WTogTWF0aC5yYW5kb20oKSxcbiAgICAgICAgcmFkaXVzWDogMi41LFxuICAgICAgICByYWRpdXNZOiAyLjUsXG4gICAgICAgIHJvdGF0aW9uQW5nbGU6IDEwLFxuICAgICAgICBmb3JjZTogMC41XG4gICAgfSk7XG5cbiAgICBjb25zdCB0b3VjaEV2ZW50ID0gbmV3IFRvdWNoRXZlbnQoZXZlbnRUeXBlLCB7XG4gICAgICAgIGNhbmNlbGFibGU6IHRydWUsXG4gICAgICAgIGJ1YmJsZXM6IHRydWUsXG4gICAgICAgIHRvdWNoZXM6IFt0b3VjaF0sXG4gICAgICAgIHRhcmdldFRvdWNoZXM6IFt0b3VjaF0sXG4gICAgICAgIGNoYW5nZWRUb3VjaGVzOiBbdG91Y2hdLFxuICAgICAgICBzaGlmdEtleTogdHJ1ZVxuICAgIH0pO1xuXG4gICAgZWxlbWVudC5kaXNwYXRjaEV2ZW50KHRvdWNoRXZlbnQpO1xufVxuIiwiaW1wb3J0IGNsaWNrRWxlbWVudCBmcm9tIFwiLi9jbGlja0VsZW1lbnRcIjtcclxuXHJcbi8qKlxyXG4gKiBQcmVzc2VzIFwiT0tcIiBidXR0b24gaW4gY29uZmlybWF0aW9uIGRpYWxvZy5cclxuICovXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNvbmZpcm1Db25maXJtYXRpb25EaWFsb2coc3VjY2Vzcz86ICgpID0+IHZvaWQpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3Qgb2tCdXR0b24gPSBkb2N1bWVudFxyXG4gICAgICAgICAgICAuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcIkRpYWxvZ1wiKVswXVxyXG4gICAgICAgICAgICAuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJidXR0b25cIilbMF07XHJcbiAgICAgICAgY2xpY2tFbGVtZW50KG9rQnV0dG9uKTtcclxuICAgICAgICBzdWNjZXNzICYmIHN1Y2Nlc3MoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7fVxyXG59XHJcbiIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGdldExpc3RJdGVtQnV0dG9uVGV4dCgpOiBzdHJpbmcge1xuICBsZXQgYnV0dG9uVGV4dCA9IFwiTGlzdCBmb3IgVHJhbnNmZXJcIjtcbiAgY29uc3QgbGFuZ3VhZ2UgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImh0bWxcIilbMF0ubGFuZztcblxuICBzd2l0Y2ggKGxhbmd1YWdlKSB7XG4gICAgY2FzZSBcImZyXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJQbGFjZXIgc3VyIGxpc3RlIGRlcyB0cmFuc2ZlcnRzXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiaXRcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIk1ldHRpIHN1bCBtZXJjYXRvXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZGVcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIkFuYmlldGVuXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwicGxcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIld5c3RhdyBuYSBsaWN5dGFjasSZXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwibmxcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIk9wIHRyYW5zZmVybGlqc3QgcGxhYXRzZW5cIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJwdFwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiTGlzdGFyIHBhcmEgdHJhbnNmZXLDqm5jaWFcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJlc1wiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiQcOxYWRpciBhIHRyYW5zZmVyaWJsZXNcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJydVwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwi0JLRi9GB0YLQsNCy0LjRgtGMINC90LAg0L/RgNC+0LTQsNC20YNcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJ0clwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiVHJhbnNmZXIgacOnaW4gTGlzdGVsZVwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImtvXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCLsnbTsoIEg66qp66Gd7JeQIOyYrOumrOq4sFwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImRhXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJTw6Z0IHDDpSB0cmFuc2Zlcmxpc3RlblwiO1xuICAgICAgYnJlYWs7XG4gIH1cblxuICByZXR1cm4gYnV0dG9uVGV4dDtcbn1cbiIsImltcG9ydCBpc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlIGZyb20gXCIuL2lzVXNlck9uU2VhcmNoUmVzdWx0c1BhZ2VcIjtcbmltcG9ydCBpc1VzZXJPblVuYXNzaWduZWRQYWdlIGZyb20gXCIuL2lzVXNlck9uVW5hc3NpZ25lZFBhZ2VcIjtcbmltcG9ydCBpc1VzZXJPblRyYW5zZmVyc1BhZ2UgZnJvbSBcIi4vaXNVc2VyT25UcmFuc2ZlcnNQYWdlXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGdldExpc3RJdGVtcygpIHtcbiAgICBsZXQgaXRlbXMgPSBbXTtcblxuICAgIGlmIChpc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlKCkpIHtcbiAgICAgICAgY29uc3QgaXRlbUxpc3QgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgICAgICAgICAgXCJwYWdpbmF0ZWQtaXRlbS1saXN0XCJcbiAgICAgICAgKVswXTtcbiAgICAgICAgaXRlbXMgPSBBcnJheS5mcm9tKGl0ZW1MaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJsaXN0RlVUSXRlbVwiKSk7XG4gICAgfSBlbHNlIGlmIChpc1VzZXJPblVuYXNzaWduZWRQYWdlKCkgfHwgaXNVc2VyT25UcmFuc2ZlcnNQYWdlKCkpIHtcbiAgICAgICAgY29uc3QgaXRlbUxpc3RzID0gQXJyYXkuZnJvbShcbiAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJpdGVtTGlzdFwiKVxuICAgICAgICApO1xuICAgICAgICBpdGVtTGlzdHMuZm9yRWFjaChmdW5jdGlvbihpdGVtTGlzdCkge1xuICAgICAgICAgICAgaXRlbXMgPSBpdGVtcy5jb25jYXQoXG4gICAgICAgICAgICAgICAgQXJyYXkuZnJvbShpdGVtTGlzdC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwibGlzdEZVVEl0ZW1cIikpXG4gICAgICAgICAgICApO1xuICAgICAgICB9LCB0aGlzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBpdGVtTGlzdCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICAgICAgICBcInBhZ2luYXRlZC1pdGVtLWxpc3RcIlxuICAgICAgICApWzBdO1xuICAgICAgICBpdGVtcyA9IEFycmF5LmZyb20oaXRlbUxpc3QuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImxpc3RGVVRJdGVtXCIpKTtcbiAgICB9XG5cbiAgICByZXR1cm4gaXRlbXM7XG59XG4iLCIvKipcbiAqIENoZWNrcyBpZiB1c2VyIGlzIG9uIHNwZWNpZmljIHBhZ2UuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzVXNlck9uUGFnZShwYWdlVGl0bGU6IHN0cmluZykge1xuICAgIGNvbnN0IHRpdGxlID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgndGl0bGUnKVswXTtcbiAgICByZXR1cm4gdGl0bGUgJiYgdGl0bGUuaW5uZXJIVE1MID09PSBwYWdlVGl0bGU7XG59XG4iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlKCk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IGVsZW1lbnRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcIlNlYXJjaFJlc3VsdHNcIik7XG4gICAgcmV0dXJuIGVsZW1lbnRzLmxlbmd0aCA+IDA7XG59XG4iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZSgpOiBib29sZWFuIHtcbiAgICBjb25zdCBlbGVtZW50cyA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICAgIFwidXQtbWFya2V0LXNlYXJjaC1maWx0ZXJzLXZpZXdcIlxuICAgICk7XG5cbiAgICBjb25zdCBzYmNFbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInNiY1wiKTtcblxuICAgIHJldHVybiBlbGVtZW50cy5sZW5ndGggPiAwICYmIHNiY0VsZW1lbnQubGVuZ3RoID09PSAwO1xufVxuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaXNVc2VyT25UcmFuc2ZlclRhcmdldHNQYWdlKCk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IGVsZW1lbnRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInV0LXdhdGNoLWxpc3Qtdmlld1wiKTtcbiAgICByZXR1cm4gZWxlbWVudHMubGVuZ3RoID4gMDtcbn1cbiIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzVXNlck9uVHJhbnNmZXJzUGFnZSgpOiBib29sZWFuIHtcbiAgICBjb25zdCBlbGVtZW50cyA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ1dC10cmFuc2Zlci1saXN0LXZpZXdcIik7XG4gICAgcmV0dXJuIGVsZW1lbnRzLmxlbmd0aCA+IDA7XG59XG4iLCJpbXBvcnQgaXNVc2VyT25QYWdlIGZyb20gXCIuL2lzVXNlck9uUGFnZVwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc1VzZXJPblVuYXNzaWduZWRQYWdlKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiAoXG4gICAgICAgIC8vIEVuZ2xpc2hcbiAgICAgICAgaXNVc2VyT25QYWdlKFwiVW5hc3NpZ25lZFwiKSB8fFxuICAgICAgICAvLyBGcmVuY2hcbiAgICAgICAgaXNVc2VyT25QYWdlKFwiTk9OIEFUVFJJQlXDiVNcIikgfHxcbiAgICAgICAgLy8gSXRhbGlhblxuICAgICAgICBpc1VzZXJPblBhZ2UoXCJOT04gQVNTRUdOQVRJXCIpIHx8XG4gICAgICAgIC8vIEdlcm1hblxuICAgICAgICBpc1VzZXJPblBhZ2UoXCJOSUNIVCBaVUdFV0lFU0VOXCIpIHx8XG4gICAgICAgIC8vIFBvbGlzaFxuICAgICAgICBpc1VzZXJPblBhZ2UoXCJOaWVwcnp5cGlzYW5lXCIpIHx8XG4gICAgICAgIC8vIER1dGNoXG4gICAgICAgIGlzVXNlck9uUGFnZShcIk5JRVQgVE9FR0VXRVouXCIpIHx8XG4gICAgICAgIC8vIFBvcnR1Z3Vlc2VcbiAgICAgICAgaXNVc2VyT25QYWdlKFwiTsOjbyBBdHJpYnXDrWRvc1wiKSB8fFxuICAgICAgICAvLyBTcGFuaXNoXG4gICAgICAgIGlzVXNlck9uUGFnZShcIk5vIGFzaWduYWRvc1wiKSB8fFxuICAgICAgICAvLyBSdXNzaWFuXG4gICAgICAgIGlzVXNlck9uUGFnZShcItCd0LUg0L3QsNC30L3QsNGH0LXQvdC+XCIpIHx8XG4gICAgICAgIC8vIFR1cmtpc2hcbiAgICAgICAgaXNVc2VyT25QYWdlKFwiQXRhbm1heWFuXCIpIHx8XG4gICAgICAgIC8vIEtvcmVhblxuICAgICAgICBpc1VzZXJPblBhZ2UoXCLsp4DsoJXrkJjsp4Ag7JWK7J2MXCIpXG4gICAgKTtcbn1cbiIsImltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vaGVscGVycy9jbGlja0VsZW1lbnRcIjtcbmltcG9ydCBpc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZSBmcm9tIFwiLi9oZWxwZXJzL2lzVXNlck9uU2VhcmNoVHJhbnNmZXJNYXJrZXRQYWdlXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGluY3JlYXNlTWF4QmluUHJpY2UoKSB7XG4gICAgaWYgKGlzVXNlck9uU2VhcmNoVHJhbnNmZXJNYXJrZXRQYWdlKCkpIHtcbiAgICAgICAgY29uc3QgYnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImluY3JlbWVudC12YWx1ZVwiKVszXTtcbiAgICAgICAgY2xpY2tFbGVtZW50KGJ1dHRvbik7XG4gICAgfVxufVxuIiwiaW1wb3J0IGNsaWNrRWxlbWVudCBmcm9tIFwiLi9oZWxwZXJzL2NsaWNrRWxlbWVudFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpbmNyZWFzZU1pbkJpZFByaWNlKCkge1xuICAgIGNvbnN0IGJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJpbmNyZW1lbnQtdmFsdWVcIilbMF07XG4gICAgY2xpY2tFbGVtZW50KGJ1dHRvbik7XG59XG4iLCJpbXBvcnQgY2xpY2tFbGVtZW50IGZyb20gXCIuL2hlbHBlcnMvY2xpY2tFbGVtZW50XCI7XG5pbXBvcnQgaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZVwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpbmNyZWFzZU1pbkJpblByaWNlKCkge1xuICAgIGlmIChpc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZSgpKSB7XG4gICAgICAgIGNvbnN0IGJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJpbmNyZW1lbnQtdmFsdWVcIilbMl07XG4gICAgICAgIGNsaWNrRWxlbWVudChidXR0b24pO1xuICAgIH1cbn1cbiIsImltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vaGVscGVycy9jbGlja0VsZW1lbnRcIjtcbmltcG9ydCBnZXRMaXN0SXRlbUJ1dHRvblRleHQgZnJvbSBcIi4vaGVscGVycy9nZXRMaXN0SXRlbUJ1dHRvblRleHRcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbGlzdChzdGFydFByaWNlOiBzdHJpbmcsIGJ1eU5vd1ByaWNlOiBzdHJpbmcpIHtcbiAgICBjb25zdCBxdWlja0xpc3RQYW5lbCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJEZXRhaWxQYW5lbFwiKVswXTtcblxuICAgIGNvbnN0IHF1aWNrTGlzdFBhbmVsQWN0aW9ucyA9IHF1aWNrTGlzdFBhbmVsLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXG4gICAgICAgIFwicGFuZWxBY3Rpb25zXCJcbiAgICApWzBdO1xuXG4gICAgY29uc3QgYWN0aW9uUm93cyA9IHF1aWNrTGlzdFBhbmVsQWN0aW9ucy5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxuICAgICAgICBcInBhbmVsQWN0aW9uUm93XCJcbiAgICApO1xuXG4gICAgaWYgKHN0YXJ0UHJpY2UpIHtcbiAgICAgICAgY29uc3Qgc3RhcnRQcmljZVJvdyA9IGFjdGlvblJvd3NbMV07XG4gICAgICAgIGNvbnN0IHN0YXJ0UHJpY2VJbnB1dCA9IHN0YXJ0UHJpY2VSb3cuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJpbnB1dFwiKVswXTtcbiAgICAgICAgc3RhcnRQcmljZUlucHV0LnZhbHVlID0gc3RhcnRQcmljZTtcbiAgICB9XG5cbiAgICBpZiAoYnV5Tm93UHJpY2UpIHtcbiAgICAgICAgY29uc3QgYmluUm93ID0gYWN0aW9uUm93c1syXTtcbiAgICAgICAgY29uc3QgYmluSW5wdXQgPSBiaW5Sb3cuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJpbnB1dFwiKVswXTtcbiAgICAgICAgYmluSW5wdXQudmFsdWUgPSBidXlOb3dQcmljZS50b1N0cmluZygpO1xuICAgIH1cblxuICAgIC8vIEdldCBhbGwgYnV0dG9ucyBpbiBcIkxpc3Qgb24gVHJhbnNmZXIgTWFya2V0XCIgc2VjdGlvbi5cbiAgICBjb25zdCBfYnV0dG9ucyA9IHF1aWNrTGlzdFBhbmVsQWN0aW9ucy5nZXRFbGVtZW50c0J5VGFnTmFtZShcImJ1dHRvblwiKTtcbiAgICBjb25zdCBidXR0b25zOiBIVE1MRWxlbWVudFtdID0gQXJyYXkuZnJvbShfYnV0dG9ucyk7XG5cbiAgICAvLyBGaW5kIGJ1dHRvbiB3aXRoIFwiTGlzdCBJdGVtXCIgYXMgdGV4dCBhbmQgdGFwIGl0LlxuICAgIGxldCBsaXN0SXRlbUJ1dHRvbjtcbiAgICBjb25zdCBidXR0b25UZXh0ID0gZ2V0TGlzdEl0ZW1CdXR0b25UZXh0KCk7XG4gICAgZm9yIChjb25zdCBidXR0b24gb2YgYnV0dG9ucykge1xuICAgICAgICBpZiAoYnV0dG9uICYmIGJ1dHRvbi5pbm5lckhUTUwgPT09IGJ1dHRvblRleHQpIHtcbiAgICAgICAgICAgIGxpc3RJdGVtQnV0dG9uID0gYnV0dG9uO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgY2xpY2tFbGVtZW50KGxpc3RJdGVtQnV0dG9uKTtcbn1cbiIsImltcG9ydCBidXlOb3cgZnJvbSBcIi4vYnV5Tm93XCI7XHJcbmltcG9ydCBjbGlja0VsZW1lbnQgZnJvbSBcIi4vaGVscGVycy9jbGlja0VsZW1lbnRcIjtcclxuaW1wb3J0IGdldExpc3RJdGVtcyBmcm9tIFwiLi9oZWxwZXJzL2dldExpc3RJdGVtc1wiO1xyXG5pbXBvcnQgaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UgZnJvbSBcIi4vaGVscGVycy9pc1VzZXJPblNlYXJjaFRyYW5zZmVyTWFya2V0UGFnZVwiO1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuLi9jb250ZW50U2NyaXB0LnNjc3NcIjtcclxuXHJcbmxldCBkYW5nZXJvdXNJbnRlcnZhbCA9IG51bGw7XHJcbmxldCBnbG9iYWxJbnRlcnZhbElkID0gMDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHNlYXJjaChkb0hhbmRzZnJlZUJpbjogYm9vbGVhbikge1xyXG4gIGlmICghaXNVc2VyT25TZWFyY2hUcmFuc2Zlck1hcmtldFBhZ2UoKSkge1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgLy8gQ2xlYXIgaW50ZXJ2YWwgd2hlbiBuZXcgc2VhcmNoIGlzIGhhcHBlbmluZy5cclxuICBjbGVhckRhbmdlcm91c0ludGVydmFsKCk7XHJcblxyXG4gIGNvbnN0IHNlYXJjaEJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXHJcbiAgICBcImJ0bi1zdGFuZGFyZCBjYWxsLXRvLWFjdGlvblwiXHJcbiAgKVswXTtcclxuXHJcbiAgY2xpY2tFbGVtZW50KHNlYXJjaEJ1dHRvbik7XHJcblxyXG4gIGNvbnN0IG9sZFNlYXJjaENvdW50ID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwic2VhcmNoQ291bnRcIik7XHJcbiAgY29uc3QgbmV3U2VhcmNoQ291bnQgPSBvbGRTZWFyY2hDb3VudCA/IHBhcnNlSW50KG9sZFNlYXJjaENvdW50KSArIDEgOiAxO1xyXG4gIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInNlYXJjaENvdW50XCIsIG5ld1NlYXJjaENvdW50LnRvU3RyaW5nKCkpO1xyXG5cclxuICBpZiAobmV3U2VhcmNoQ291bnQgPT09IDEpIHtcclxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFtcImRpc2NvcmRXZWJob29rQ2FyZFNlZW5cIl0sIChkYXRhKSA9PiB7XHJcbiAgICAgIGlmIChkYXRhLmRpc2NvcmRXZWJob29rQ2FyZFNlZW4pIHtcclxuICAgICAgICAvLyBUT0RPOiBBZGQgXCJzdGFydGVkXCIgbWVzc2FnZSB3aGVuIHdlIGRvIGxvZ2dpbmdcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvLyBpbmNyZW1lbWVudCBJRCB0byB0cmFjayBuZXcgaW50ZXJ2YWxcclxuICBnbG9iYWxJbnRlcnZhbElkID0gZ2xvYmFsSW50ZXJ2YWxJZCArIDE7XHJcbiAgY29uc3QgaXRlcmF0aW9uSWQgPSBnbG9iYWxJbnRlcnZhbElkO1xyXG5cclxuICBkYW5nZXJvdXNJbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGhhc1NlYXJjaFJlc3VsdHMgPSBnZXRMaXN0SXRlbXMoKS5sZW5ndGggPiAwO1xyXG4gICAgICBjb25zdCBpc05vUmVzdWx0c1BhZ2UgPVxyXG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ1dC1uby1yZXN1bHRzLXZpZXdcIikubGVuZ3RoID4gMDtcclxuXHJcbiAgICAgIGlmIChoYXNTZWFyY2hSZXN1bHRzIHx8IGlzTm9SZXN1bHRzUGFnZSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBpdGVtcyA9IGdldExpc3RJdGVtcygpO1xyXG4gICAgICAgICAgY2xpY2tFbGVtZW50KFxyXG4gICAgICAgICAgICBpdGVtc1tpdGVtcy5sZW5ndGggLSAxXS5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxyXG4gICAgICAgICAgICAgIFwiaGFzLXRhcC1jYWxsYmFja1wiXHJcbiAgICAgICAgICAgIClbMF1cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHt9XHJcblxyXG4gICAgICAgIGlmIChkb0hhbmRzZnJlZUJpbikge1xyXG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGhhbmRzZnJlZUJpbigpO1xyXG4gICAgICAgICAgfSwgNTApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gQ2xlYXIgaW50ZXJ2YWwgb25jZSBzZWFyY2ggaGFzIGNvbXBsZXRlZC5cclxuICAgICAgICBjbGVhckRhbmdlcm91c0ludGVydmFsKCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgfSwgMCk7XHJcblxyXG4gIC8vIGNsZWFyIGRhbmdlcm91cyB0aW1lciBhZnRlciBhIGZldyBzZWNvbmRzXHJcbiAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICBjbGVhckRhbmdlcm91c0ludGVydmFsKGl0ZXJhdGlvbklkKTtcclxuICB9LCAzNTAwKTtcclxufVxyXG5cclxuY29uc3QgaGFuZHNmcmVlQmluID0gKCkgPT4ge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBpc0J1eUJ1dHRvblByZXNlbnQgPVxyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiYnV5QnV0dG9uXCIpLmxlbmd0aCA+IDA7XHJcblxyXG4gICAgaWYgKGlzQnV5QnV0dG9uUHJlc2VudCkge1xyXG4gICAgICBidXlOb3coKTtcclxuXHJcbiAgICAgIC8vIGluY3JlbWVudHMgc2VlbiBjb3VudFxyXG4gICAgICBjb25zdCBvbGRDb3VudCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInNlZW5Db3VudFwiKTtcclxuICAgICAgY29uc3QgbmV3Q291bnQgPSBvbGRDb3VudCA/IHBhcnNlSW50KG9sZENvdW50KSArIDEgOiAxO1xyXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJzZWVuQ291bnRcIiwgbmV3Q291bnQudG9TdHJpbmcoKSk7XHJcblxyXG4gICAgICAvLyBub3RlcyB0aGF0IHdlIGp1c3Qgc2F3IGEgY2FyZCBmb3IgXCJjYXJkIHB1cmNoYXNlZFwiIGNvdW50XHJcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImp1c3RTYXdDYXJkXCIsIFwidHJ1ZVwiKTtcclxuXHJcbiAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFxyXG4gICAgICAgIFtcInNob3VsZFBsYXlSZXN1bHRTZWVuU291bmRcIiwgXCJkaXNjb3JkV2ViaG9va0NhcmRTZWVuXCJdLFxyXG4gICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZGF0YS5zaG91bGRQbGF5UmVzdWx0U2VlblNvdW5kKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGNhcmRTZWVuU291bmQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcclxuICAgICAgICAgICAgICBzdHlsZXMuY2FyZFNlZW5Tb3VuZFxyXG4gICAgICAgICAgICApIGFzIEhUTUxBdWRpb0VsZW1lbnQ7XHJcbiAgICAgICAgICAgIGNhcmRTZWVuU291bmQucGxheSgpO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGlmIChkYXRhLmRpc2NvcmRXZWJob29rQ2FyZFNlZW4pIHtcclxuICAgICAgICAgICAgZmV0Y2hfcmV0cnkoXHJcbiAgICAgICAgICAgICAgZGF0YS5kaXNjb3JkV2ViaG9va0NhcmRTZWVuLFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXHJcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGBBIGNhcmQgcG9wcGVkIHVwYCxcclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICA1XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGUpIHt9XHJcbn07XHJcblxyXG4vKipcclxuICogY2xlYXIgdGltZXIgaWYgbm8gSUQgaXMgcGFzc2VkIG9yIGlmIElEIG1hdGNoZXMgZ2xvYmFsXHJcbiAqL1xyXG5jb25zdCBjbGVhckRhbmdlcm91c0ludGVydmFsID0gKGludGVydmFsSWQ/OiBudW1iZXIpID0+IHtcclxuICBpZiAoIWludGVydmFsSWQgfHwgaW50ZXJ2YWxJZCA9PT0gZ2xvYmFsSW50ZXJ2YWxJZCkge1xyXG4gICAgY2xlYXJJbnRlcnZhbChkYW5nZXJvdXNJbnRlcnZhbCk7XHJcbiAgfVxyXG59O1xyXG5cclxuY29uc3QgZmV0Y2hfcmV0cnkgPSAodXJsLCBvcHRpb25zLCBuKSA9PlxyXG4gIGZldGNoKHVybCwgb3B0aW9ucykuY2F0Y2goZnVuY3Rpb24gKGVycm9yKSB7XHJcbiAgICBpZiAobiA9PT0gMSkgdGhyb3cgZXJyb3I7XHJcbiAgICByZXR1cm4gZmV0Y2hfcmV0cnkodXJsLCBvcHRpb25zLCBuIC0gMSk7XHJcbiAgfSk7XHJcbiIsImltcG9ydCBjbGlja0RldGFpbHNQYW5lbEJ1dHRvbiBmcm9tIFwiLi9oZWxwZXJzL2NsaWNrRGV0YWlsc1BhbmVsQnV0dG9uXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzZW5kVG9UcmFuc2Zlckxpc3QoKSB7XHJcbiAgbGV0IGJ1dHRvblRleHQgPSBcIlNlbmQgdG8gVHJhbnNmZXIgTGlzdFwiO1xyXG4gIGNvbnN0IGxhbmd1YWdlID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJodG1sXCIpWzBdLmxhbmc7XHJcblxyXG4gIHN3aXRjaCAobGFuZ3VhZ2UpIHtcclxuICAgIGNhc2UgXCJmclwiOlxyXG4gICAgICBidXR0b25UZXh0ID0gXCJFbnYuIExpc3RlIHRyYW5zZi5cIjtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwiaXRcIjpcclxuICAgICAgYnV0dG9uVGV4dCA9IFwiSW52aWEgYSB0cmFzZmVyaW0uXCI7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBcImRlXCI6XHJcbiAgICAgIGJ1dHRvblRleHQgPSBcIkF1ZiBUcmFuc2Zlcmxpc3RlXCI7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBcInBsXCI6XHJcbiAgICAgIGJ1dHRvblRleHQgPSBcIld5xZtsaWogbmEgbGlzdMSZIHRyYW5zZmVyb3fEhVwiO1xyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgXCJubFwiOlxyXG4gICAgICBidXR0b25UZXh0ID0gXCJOYWFyIHRyYW5zZmVybGlqc3RcIjtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwicHRcIjpcclxuICAgICAgYnV0dG9uVGV4dCA9IFwiRW52aWFyIHBhcmEgVHJhbnNmZXIuXCI7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBcImVzXCI6XHJcbiAgICAgIGJ1dHRvblRleHQgPSBcIkVudmlhciBhIHRyYW5zZmVyaWJsZXNcIjtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwicnVcIjpcclxuICAgICAgYnV0dG9uVGV4dCA9IFwi0J7RgtC/0YDQsNCy0LjRgtGMINCyINGB0L/QuNGB0L7QuiDQv9GA0L7QtNCw0LZcIjtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwidHJcIjpcclxuICAgICAgYnV0dG9uVGV4dCA9IFwiVHJhbnNmZXIgTGlzdGVzaeKAmW5lIEfDtm5kZXJcIjtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwia29cIjpcclxuICAgICAgYnV0dG9uVGV4dCA9IFwi7J207KCBIOuqqeuhneycvOuhnCDrs7TrgrTquLBcIjtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwiZGFcIjpcclxuICAgICAgYnV0dG9uVGV4dCA9IFwiU2VuZCB0aWwgdHJhbnNmZXJsaXN0ZW5cIjtcclxuICAgICAgYnJlYWs7XHJcbiAgfVxyXG5cclxuICB0cnkge1xyXG4gICAgY2xpY2tEZXRhaWxzUGFuZWxCdXR0b24oYnV0dG9uVGV4dCk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHt9XHJcbn1cclxuIiwiaW1wb3J0IGNsaWNrRGV0YWlsc1BhbmVsQnV0dG9uIGZyb20gXCIuL2hlbHBlcnMvY2xpY2tEZXRhaWxzUGFuZWxCdXR0b25cIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gc3RvcmVJbkNsdWIoKSB7XG4gIGxldCBidXR0b25UZXh0ID0gXCJTZW5kIHRvIE15IENsdWJcIjtcbiAgY29uc3QgbGFuZ3VhZ2UgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImh0bWxcIilbMF0ubGFuZztcblxuICBzd2l0Y2ggKGxhbmd1YWdlKSB7XG4gICAgY2FzZSBcImZyXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJFbnZveWVyIHZlcnMgTW9uIGNsdWJcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJpdFwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiSW52aWEgYSBJbCBtaW8gY2x1YlwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImRlXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJadSBNZWluIFZlcmVpblwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInBsXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJXecWbbGlqIGRvIGtsdWJ1XCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwibmxcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIk5hYXIgTWlqbiBjbHViIHN0dXJlblwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInB0XCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJFbnZpYXIgYW8gTWV1IGNsdWJlXCI7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZXNcIjpcbiAgICAgIGJ1dHRvblRleHQgPSBcIkVudmlhciBhIE1pIGNsdWJcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJydVwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwi0J7RgtC/0YDQsNCy0LjRgtGMINCyINCc0L7QuSDQutC70YPQsVwiO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInRyXCI6XG4gICAgICBidXR0b25UZXh0ID0gXCJLdWzDvGLDvG1lIEfDtm5kZXJcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJrb1wiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwi64K0IO2BtOufveycvOuhnCDrs7TrgrTquLBcIjtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJkYVwiOlxuICAgICAgYnV0dG9uVGV4dCA9IFwiU2VuZCB0aWwgTWluIGtsdWJcIjtcbiAgICAgIGJyZWFrO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjbGlja0RldGFpbHNQYW5lbEJ1dHRvbihidXR0b25UZXh0KTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAvL1xuICB9XG59XG4iLCJcbnZhciBjb250ZW50ID0gcmVxdWlyZShcIiEhLi4vbm9kZV9tb2R1bGVzL2Nzcy1tb2R1bGVzLXR5cGVzY3JpcHQtbG9hZGVyL2luZGV4LmpzIS4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9yZWYtLTUtMiEuLi9ub2RlX21vZHVsZXMvc2Fzcy1sb2FkZXIvbGliL2xvYWRlci5qcyEuL2NvbnRlbnRTY3JpcHQuc2Nzc1wiKTtcblxuaWYodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSBjb250ZW50ID0gW1ttb2R1bGUuaWQsIGNvbnRlbnQsICcnXV07XG5cbnZhciB0cmFuc2Zvcm07XG52YXIgaW5zZXJ0SW50bztcblxuXG5cbnZhciBvcHRpb25zID0ge1wiaG1yXCI6dHJ1ZX1cblxub3B0aW9ucy50cmFuc2Zvcm0gPSB0cmFuc2Zvcm1cbm9wdGlvbnMuaW5zZXJ0SW50byA9IHVuZGVmaW5lZDtcblxudmFyIHVwZGF0ZSA9IHJlcXVpcmUoXCIhLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9saWIvYWRkU3R5bGVzLmpzXCIpKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5pZihjb250ZW50LmxvY2FscykgbW9kdWxlLmV4cG9ydHMgPSBjb250ZW50LmxvY2FscztcblxuaWYobW9kdWxlLmhvdCkge1xuXHRtb2R1bGUuaG90LmFjY2VwdChcIiEhLi4vbm9kZV9tb2R1bGVzL2Nzcy1tb2R1bGVzLXR5cGVzY3JpcHQtbG9hZGVyL2luZGV4LmpzIS4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzPz9yZWYtLTUtMiEuLi9ub2RlX21vZHVsZXMvc2Fzcy1sb2FkZXIvbGliL2xvYWRlci5qcyEuL2NvbnRlbnRTY3JpcHQuc2Nzc1wiLCBmdW5jdGlvbigpIHtcblx0XHR2YXIgbmV3Q29udGVudCA9IHJlcXVpcmUoXCIhIS4uL25vZGVfbW9kdWxlcy9jc3MtbW9kdWxlcy10eXBlc2NyaXB0LWxvYWRlci9pbmRleC5qcyEuLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcz8/cmVmLS01LTIhLi4vbm9kZV9tb2R1bGVzL3Nhc3MtbG9hZGVyL2xpYi9sb2FkZXIuanMhLi9jb250ZW50U2NyaXB0LnNjc3NcIik7XG5cblx0XHRpZih0eXBlb2YgbmV3Q29udGVudCA9PT0gJ3N0cmluZycpIG5ld0NvbnRlbnQgPSBbW21vZHVsZS5pZCwgbmV3Q29udGVudCwgJyddXTtcblxuXHRcdHZhciBsb2NhbHMgPSAoZnVuY3Rpb24oYSwgYikge1xuXHRcdFx0dmFyIGtleSwgaWR4ID0gMDtcblxuXHRcdFx0Zm9yKGtleSBpbiBhKSB7XG5cdFx0XHRcdGlmKCFiIHx8IGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRcdGlkeCsrO1xuXHRcdFx0fVxuXG5cdFx0XHRmb3Ioa2V5IGluIGIpIGlkeC0tO1xuXG5cdFx0XHRyZXR1cm4gaWR4ID09PSAwO1xuXHRcdH0oY29udGVudC5sb2NhbHMsIG5ld0NvbnRlbnQubG9jYWxzKSk7XG5cblx0XHRpZighbG9jYWxzKSB0aHJvdyBuZXcgRXJyb3IoJ0Fib3J0aW5nIENTUyBITVIgZHVlIHRvIGNoYW5nZWQgY3NzLW1vZHVsZXMgbG9jYWxzLicpO1xuXG5cdFx0dXBkYXRlKG5ld0NvbnRlbnQpO1xuXHR9KTtcblxuXHRtb2R1bGUuaG90LmRpc3Bvc2UoZnVuY3Rpb24oKSB7IHVwZGF0ZSgpOyB9KTtcbn0iLCJpbXBvcnQgZ29CYWNrIGZyb20gXCIuL2FjdGlvbnMvYmFja1wiO1xyXG5pbXBvcnQgbGlzdCBmcm9tIFwiLi9hY3Rpb25zL2xpc3RcIjtcclxuaW1wb3J0IHNlYXJjaCBmcm9tIFwiLi9hY3Rpb25zL3NlYXJjaFwiO1xyXG5pbXBvcnQgc2VuZFRvVHJhbnNmZXJMaXN0IGZyb20gXCIuL2FjdGlvbnMvc2VuZFRvVHJhbnNmZXJMaXN0XCI7XHJcbmltcG9ydCBpbmNyZWFzZU1pbkJpZFByaWNlIGZyb20gXCIuL2FjdGlvbnMvaW5jcmVhc2VNaW5CaWRQcmljZVwiO1xyXG5pbXBvcnQgc3RvcmVJbkNsdWIgZnJvbSBcIi4vYWN0aW9ucy9zdG9yZUluQ2x1YlwiO1xyXG5pbXBvcnQgaXNVc2VyT25TZWFyY2hSZXN1bHRzUGFnZSBmcm9tIFwiLi9hY3Rpb25zL2hlbHBlcnMvaXNVc2VyT25TZWFyY2hSZXN1bHRzUGFnZVwiO1xyXG5pbXBvcnQgaW5jcmVhc2VNaW5CaW5QcmljZSBmcm9tIFwiLi9hY3Rpb25zL2luY3JlYXNlTWluQmluUHJpY2VcIjtcclxuaW1wb3J0IGluY3JlYXNlTWF4QmluUHJpY2UgZnJvbSBcIi4vYWN0aW9ucy9pbmNyZWFzZU1heEJpblByaWNlXCI7XHJcbmltcG9ydCBkZWNyZWFzZU1heEJpblByaWNlIGZyb20gXCIuL2FjdGlvbnMvZGVjcmVhc2VNYXhCaW5QcmljZVwiO1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuL2NvbnRlbnRTY3JpcHQuc2Nzc1wiO1xyXG5cclxubGV0IG9uVGltZXIgPSBudWxsO1xyXG5sZXQgb2ZmVGltZXIgPSBudWxsO1xyXG5sZXQgaXNPbiA9IGZhbHNlO1xyXG5cclxuKGZ1bmN0aW9uICgpIHtcclxuICAvLyBmaWZhIDIyIGJsb2NrICgxMC8xLzIxKVxyXG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XHJcbiAgaWYgKG5vdyA+IDE2MzMwNzE2MDA4MDkpIHtcclxuICAgIGFsZXJ0KFxyXG4gICAgICBcIlRoYW5rcyBmb3IgdXNpbmcgc2hvcnRmdXRzIGF1dG8gaW4gRklGQSAyMSEgUGxlYXNlIHZpc2l0IHRoZSBzdG9yZSB0byBwdXJjaGFzZSBhIGxpY2Vuc2UgZm9yIEZJRkEgMjIuIENoZWVycyFcIlxyXG4gICAgKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGNvbnN0IGlkID0gY2hyb21lLnJ1bnRpbWUuaWQ7XHJcbiAgaWYgKGlkICE9PSBcImxpY25jZGNnbmNqbm1rZmNibWRpa2tua2dvamloZWNiXCIpIHtcclxuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHtcclxuICAgICAgbG9nOiB0cnVlLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvLyBtZXNzYWdlIGxpc3RlbmVyIHRvIGdldCBjdXJyZW50IGNvaW4gYmFsYW5jZVxyXG4gIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigocmVxdWVzdCwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcclxuICAgIGlmIChyZXF1ZXN0LmdldEN1cnJlbnRDb2luQmFsYW5jZSkge1xyXG4gICAgICBjb25zdCBjb2luQmFsYW5jZSA9IChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxyXG4gICAgICAgIFwidmlldy1uYXZiYXItY3VycmVuY3ktY29pbnNcIlxyXG4gICAgICApWzBdIGFzIEhUTUxFbGVtZW50KS5pbm5lclRleHQ7XHJcbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWRDb2luQmFsYW5jZSA9IGNvaW5CYWxhbmNlLnJlcGxhY2UoXHJcbiAgICAgICAgL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csXHJcbiAgICAgICAgXCJcIlxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2VuZFJlc3BvbnNlKHtcclxuICAgICAgICBub3JtYWxpemVkQ29pbkJhbGFuY2U6IG5vcm1hbGl6ZWRDb2luQmFsYW5jZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGF1ZGlvID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImF1ZGlvXCIpO1xyXG4gIGF1ZGlvLmlkID0gc3R5bGVzLmF1ZGlvO1xyXG4gIGF1ZGlvLmF1dG9wbGF5ID0gZmFsc2U7XHJcbiAgYXVkaW8uc3JjID0gXCJodHRwczovL3d3dy5zb3VuZGpheS5jb20vYnV0dG9ucy9zb3VuZHMvYnV0dG9uLTEyLm1wM1wiO1xyXG4gIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5hcHBlbmRDaGlsZChhdWRpbyk7XHJcblxyXG4gIGNvbnN0IGxvb3BEb25lU291bmQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYXVkaW9cIik7XHJcbiAgbG9vcERvbmVTb3VuZC5pZCA9IHN0eWxlcy5sb29wRG9uZVNvdW5kO1xyXG4gIGxvb3BEb25lU291bmQuYXV0b3BsYXkgPSBmYWxzZTtcclxuICBsb29wRG9uZVNvdW5kLnNyYyA9IFwiaHR0cHM6Ly93d3cuc291bmRqYXkuY29tL21pc2MvYmVsbC1yaW5nLTAxLm1wM1wiO1xyXG4gIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5hcHBlbmRDaGlsZChsb29wRG9uZVNvdW5kKTtcclxuXHJcbiAgY29uc3QgY2FyZFNlZW5Tb3VuZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhdWRpb1wiKTtcclxuICBjYXJkU2VlblNvdW5kLmlkID0gc3R5bGVzLmNhcmRTZWVuU291bmQ7XHJcbiAgY2FyZFNlZW5Tb3VuZC5hdXRvcGxheSA9IGZhbHNlO1xyXG4gIGNhcmRTZWVuU291bmQuc3JjID0gXCJodHRwczovL3d3dy5zb3VuZGpheS5jb20vYnV0dG9ucy9zb3VuZHMvYnV0dG9uLTA5YS5tcDNcIjtcclxuICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYXBwZW5kQ2hpbGQoY2FyZFNlZW5Tb3VuZCk7XHJcblxyXG4gIGNvbnN0IGNhcmRQdXJjaGFzZWRTb3VuZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhdWRpb1wiKTtcclxuICBjYXJkUHVyY2hhc2VkU291bmQuaWQgPSBzdHlsZXMuY2FyZFB1cmNoYXNlZFNvdW5kO1xyXG4gIGNhcmRQdXJjaGFzZWRTb3VuZC5hdXRvcGxheSA9IGZhbHNlO1xyXG4gIGNhcmRQdXJjaGFzZWRTb3VuZC5zcmMgPVxyXG4gICAgXCJodHRwczovL3d3dy5zb3VuZGpheS5jb20vbWVjaGFuaWNhbC9zb3VuZHMvZ3VuLWd1bnNob3QtMDEubXAzXCI7XHJcbiAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFwcGVuZENoaWxkKGNhcmRQdXJjaGFzZWRTb3VuZCk7XHJcblxyXG4gIC8vIHJlc2V0cyBiYWRnZSBvbiByZWZyZXNoIChzaW5jZSBpdCdzIG9idmlvdXNseSBzdG9wcGVkKVxyXG4gIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgc3RvcEF1dG9idXllcjogdHJ1ZSB9KTtcclxuICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJzZWVuQ291bnRcIiwgXCIwXCIpO1xyXG4gIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInNlYXJjaENvdW50XCIsIFwiMFwiKTtcclxuICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJwdXJjaGFzZWRDb3VudFwiLCBcIjBcIik7XHJcblxyXG4gIGNvbnNvbGUubG9nKFwiU2V0dGluZyB1cCBldmVudCBsaXN0ZW5lci4uLlwiKTtcclxuXHJcbiAgY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChyZXF1ZXN0KSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkxpc3RlbmVyIGlzIHJlYWR5LlwiKTtcclxuXHJcbiAgICBpZiAocmVxdWVzdC5zdGFydEF1dG9idXllcikge1xyXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJzZWVuQ291bnRcIiwgXCIwXCIpO1xyXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJzZWFyY2hDb3VudFwiLCBcIjBcIik7XHJcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInB1cmNoYXNlZENvdW50XCIsIFwiMFwiKTtcclxuXHJcbiAgICAgIGNvbnNvbGUubG9nKFwiU3RhcnRpbmcgYXV0b2J1eWVyLi4uXCIpO1xyXG5cclxuICAgICAgY29uc3QgcGxheWVyTmFtZUlucHV0ID0gZG9jdW1lbnRcclxuICAgICAgICAuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInV0LXBsYXllci1zZWFyY2gtY29udHJvbFwiKVswXVxyXG4gICAgICAgIC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImlucHV0XCIpWzBdO1xyXG4gICAgICBpZiAocGxheWVyTmFtZUlucHV0ICYmIHBsYXllck5hbWVJbnB1dC52YWx1ZSA9PT0gXCJcIikge1xyXG4gICAgICAgIGNvbnN0IHJldFZhbCA9IGNvbmZpcm0oXHJcbiAgICAgICAgICBcIlBsYXllciBuYW1lIGlucHV0IGlzIGVtcHR5LiBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gc3RhcnQgdGhlIGF1dG9idXllcj9cIlxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGlmICghcmV0VmFsKSB7XHJcbiAgICAgICAgICBzdG9wQXV0b2J1eWVyKFxyXG4gICAgICAgICAgICBcIkF1dG9idXllciBkaWRuJ3QgZ2V0IHN0YXJ0ZWQuIFRoYXQgd2FzIGEgY2xvc2Ugb25lIVwiLFxyXG4gICAgICAgICAgICB0cnVlXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgbWF4QmluSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwibnVtZXJpY0lucHV0XCIpWzNdO1xyXG4gICAgICBpZiAoKG1heEJpbklucHV0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlID09PSBcIlwiKSB7XHJcbiAgICAgICAgY29uc3QgcmV0VmFsID0gY29uZmlybShcclxuICAgICAgICAgIFwiVGhlIG1heCBidXkgbm93IHByaWNlIGlzIGVtcHR5LiBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gc3RhcnQgdGhlIGF1dG9idXllcj9cIlxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGlmICghcmV0VmFsKSB7XHJcbiAgICAgICAgICBzdG9wQXV0b2J1eWVyKFxyXG4gICAgICAgICAgICBcIkF1dG9idXllciBkaWRuJ3QgZ2V0IHN0YXJ0ZWQuIFRoYXQgd2FzIGEgY2xvc2Ugb25lIVwiLFxyXG4gICAgICAgICAgICB0cnVlXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3Qge1xyXG4gICAgICAgIHJlc2V0UG9pbnQsXHJcbiAgICAgICAgYWN0aW9uLFxyXG4gICAgICAgIGl0ZXJhdGlvblRpbWUsXHJcbiAgICAgICAgaXRlcmF0aW9uVGltZU1heCxcclxuICAgICAgICBsaXN0U3RhcnRQcmljZSxcclxuICAgICAgICBsaXN0QmluUHJpY2UsXHJcbiAgICAgICAgaXNUZXN0UnVuLFxyXG4gICAgICAgIGN5Y2xlcyxcclxuICAgICAgICBvbkludGVydmFsLFxyXG4gICAgICAgIG9mZkludGVydmFsLFxyXG4gICAgICAgIG1heEJ1eU5vd1ByaWNlLFxyXG4gICAgICAgIG1pbmltdW1Db2luQmFsYW5jZSxcclxuICAgICAgfSA9IHJlcXVlc3Q7XHJcblxyXG4gICAgICAvLyBHZXQgaW5pdGlhbCBtaW4gQklOIHNldCBieSB1c2VyXHJcbiAgICAgIGNvbnN0IGluaXRpYWxNaW5CaW4gPSAoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgICAgICBcIm51bWVyaWNJbnB1dFwiXHJcbiAgICAgIClbMl0gYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XHJcbiAgICAgIGNvbnN0IGluaXRpYWxNaW5CaW5OdW1iZXIgPVxyXG4gICAgICAgIHBhcnNlSW50KGluaXRpYWxNaW5CaW4ucmVwbGFjZSgvWy4sIFxcdTAwYTBcXHUyMDJGXSovZywgXCJcIikpIHx8IDA7XHJcblxyXG4gICAgICAvLyBEZXRlcm1pbmUgcmVzZXQgcHJpY2VcclxuICAgICAgY29uc3QgbWF4UHVyY2hhc2VQcmljZSA9IGluaXRpYWxNaW5CaW5OdW1iZXIgfHwgcmVzZXRQb2ludDtcclxuICAgICAgY29uc3QgcmVzZXRQcmljZSA9IGdldE1heEJpZFByaWNlKG1heFB1cmNoYXNlUHJpY2UpO1xyXG5cclxuICAgICAgLy8gR2V0IGluaXRpYWwgbWF4IEJJTiBzZXQgYnkgdXNlclxyXG4gICAgICBjb25zdCBpbml0aWFsTWF4QmluID0gKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXHJcbiAgICAgICAgXCJudW1lcmljSW5wdXRcIlxyXG4gICAgICApWzNdIGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xyXG4gICAgICBjb25zdCBpbml0aWFsTWF4QmluTnVtYmVyID1cclxuICAgICAgICBwYXJzZUludChpbml0aWFsTWF4QmluLnJlcGxhY2UoL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csIFwiXCIpKSB8fCAwO1xyXG5cclxuICAgICAgaWYgKGluaXRpYWxNYXhCaW5OdW1iZXIgPD0gcmVzZXRQcmljZSkge1xyXG4gICAgICAgIHN0b3BBdXRvYnV5ZXIoXHJcbiAgICAgICAgICAnWW91ciBcIlJlc2V0IHByaWNlXCIgbXVzdCBiZSBsZXNzIHRoYW4gdGhlIG1heCBCSU4gcHJpY2Ugb2YgeW91ciBzbmlwaW5nIGZpbHRlci4nLFxyXG4gICAgICAgICAgdHJ1ZVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjcmVhdGVDeWNsZSh7XHJcbiAgICAgICAgY3VyckN5Y2xlOiAwLFxyXG4gICAgICAgIHRvdGFsQ3ljbGVzOiBjeWNsZXMsXHJcbiAgICAgICAgb25JbnRlcnZhbCxcclxuICAgICAgICBvZmZJbnRlcnZhbCxcclxuICAgICAgICBpc1Rlc3RSdW4sXHJcbiAgICAgICAgYWN0aW9uLFxyXG4gICAgICAgIGxpc3RTdGFydFByaWNlLFxyXG4gICAgICAgIGxpc3RCaW5QcmljZSxcclxuICAgICAgICBpdGVyYXRpb25UaW1lLFxyXG4gICAgICAgIGl0ZXJhdGlvblRpbWVNYXgsXHJcbiAgICAgICAgcmVzZXRQcmljZSxcclxuICAgICAgICB1c2VyU2V0TWluQmluOiBpbml0aWFsTWluQmluTnVtYmVyID4gMCxcclxuICAgICAgICBtYXhCdXlOb3dQcmljZSxcclxuICAgICAgICBpbml0aWFsTWF4QmluOiBpbml0aWFsTWF4QmluTnVtYmVyLFxyXG4gICAgICAgIG1pbmltdW1Db2luQmFsYW5jZTogbWluaW11bUNvaW5CYWxhbmNlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZWxzZSBpZiAocmVxdWVzdC5zdG9wQXV0b2J1eWVyRnJvbVBvcHVwKSB7XHJcbiAgICAgIHN0b3BBdXRvYnV5ZXIoXCJBdXRvYnV5ZXIgc3RvcHBlZCBiZWNhdXNlIHlvdSBzdG9wcGVkIGl0LlwiKTtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgLy8gRXZlbnQgbGlzdGVuZXIgdG8gc3RvcCBhdXRvYnV5ZXIgb24gZGVtYW5kXHJcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIChldikgPT4ge1xyXG4gICAgLy8gSWYgdXNlciBpcyB0eXBpbmcgaW4gYW4gaW5wdXQsIGlnbm9yZSBob3RrZXlzLlxyXG4gICAgaWYgKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQudGFnTmFtZS50b0xvd2VyQ2FzZSgpID09PSBcImlucHV0XCIpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChldi5rZXlDb2RlID09PSAzMiAmJiBldi5zaGlmdEtleSkge1xyXG4gICAgICBpZiAoaXNPbiB8fCBvblRpbWVyIHx8IG9mZlRpbWVyKSB7XHJcbiAgICAgICAgc3RvcEF1dG9idXllcihcIkF1dG9idXllciBzdG9wcGVkIGJlY2F1c2UgeW91IHN0b3BwZWQgaXQuXCIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFxyXG4gICAgICAgICAgW1xyXG4gICAgICAgICAgICBcInJlc2V0UG9pbnRcIixcclxuICAgICAgICAgICAgXCJkdXJhdGlvblwiLFxyXG4gICAgICAgICAgICBcImFjdGlvblwiLFxyXG4gICAgICAgICAgICBcIml0ZXJhdGlvblRpbWVcIixcclxuICAgICAgICAgICAgXCJpdGVyYXRpb25UaW1lTWF4XCIsXHJcbiAgICAgICAgICAgIFwibGlzdFN0YXJ0UHJpY2VcIixcclxuICAgICAgICAgICAgXCJsaXN0QmluUHJpY2VcIixcclxuICAgICAgICAgICAgXCJjeWNsZXNcIixcclxuICAgICAgICAgICAgXCJvbkludGVydmFsXCIsXHJcbiAgICAgICAgICAgIFwib2ZmSW50ZXJ2YWxcIixcclxuICAgICAgICAgICAgXCJtYXhCdXlOb3dQcmljZVwiLFxyXG4gICAgICAgICAgICBcIm1pbmltdW1Db2luQmFsYW5jZVwiLFxyXG4gICAgICAgICAgXSxcclxuICAgICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHtcclxuICAgICAgICAgICAgICByZXNldFBvaW50LFxyXG4gICAgICAgICAgICAgIGR1cmF0aW9uLFxyXG4gICAgICAgICAgICAgIGFjdGlvbixcclxuICAgICAgICAgICAgICBpdGVyYXRpb25UaW1lLFxyXG4gICAgICAgICAgICAgIGl0ZXJhdGlvblRpbWVNYXgsXHJcbiAgICAgICAgICAgICAgbGlzdFN0YXJ0UHJpY2UsXHJcbiAgICAgICAgICAgICAgbGlzdEJpblByaWNlLFxyXG4gICAgICAgICAgICAgIGN5Y2xlcyxcclxuICAgICAgICAgICAgICBvbkludGVydmFsLFxyXG4gICAgICAgICAgICAgIG9mZkludGVydmFsLFxyXG4gICAgICAgICAgICAgIG1heEJ1eU5vd1ByaWNlLFxyXG4gICAgICAgICAgICAgIG1pbmltdW1Db2luQmFsYW5jZSxcclxuICAgICAgICAgICAgfSA9IGRhdGE7XHJcblxyXG4gICAgICAgICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7XHJcbiAgICAgICAgICAgICAgc3RhcnRBdXRvYnV5ZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgcmVzZXRQb2ludDogcGFyc2VJbnQocmVzZXRQb2ludCksXHJcbiAgICAgICAgICAgICAgZHVyYXRpb246IGR1cmF0aW9uLFxyXG4gICAgICAgICAgICAgIGFjdGlvbjogYWN0aW9uLFxyXG4gICAgICAgICAgICAgIGl0ZXJhdGlvblRpbWU6IGl0ZXJhdGlvblRpbWUsXHJcbiAgICAgICAgICAgICAgaXRlcmF0aW9uVGltZU1heDogaXRlcmF0aW9uVGltZU1heCxcclxuICAgICAgICAgICAgICBsaXN0U3RhcnRQcmljZTogbGlzdFN0YXJ0UHJpY2UsXHJcbiAgICAgICAgICAgICAgbGlzdEJpblByaWNlOiBsaXN0QmluUHJpY2UsXHJcbiAgICAgICAgICAgICAgaXNUZXN0UnVuOiBmYWxzZSxcclxuICAgICAgICAgICAgICBjeWNsZXM6IHBhcnNlSW50KGN5Y2xlcyksXHJcbiAgICAgICAgICAgICAgb25JbnRlcnZhbDogcGFyc2VJbnQob25JbnRlcnZhbCksXHJcbiAgICAgICAgICAgICAgb2ZmSW50ZXJ2YWw6IHBhcnNlSW50KG9mZkludGVydmFsKSxcclxuICAgICAgICAgICAgICBtYXhCdXlOb3dQcmljZTogcGFyc2VJbnQobWF4QnV5Tm93UHJpY2UpLFxyXG4gICAgICAgICAgICAgIG1pbmltdW1Db2luQmFsYW5jZTogbWluaW11bUNvaW5CYWxhbmNlLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSk7XHJcbn0pKCk7XHJcblxyXG5jb25zdCBzdG9wQXV0b2J1eWVyID0gKHJlYXNvbjogc3RyaW5nLCBza2lwQ2hlY2s6IGJvb2xlYW4gPSBmYWxzZSkgPT4ge1xyXG4gIGlmIChpc09uIHx8IG9uVGltZXIgfHwgb2ZmVGltZXIgfHwgc2tpcENoZWNrKSB7XHJcbiAgICBpc09uID0gZmFsc2U7XHJcblxyXG4gICAgY2xlYXJUaW1lb3V0KG9uVGltZXIpO1xyXG4gICAgb25UaW1lciA9IG51bGw7XHJcblxyXG4gICAgY2xlYXJUaW1lb3V0KG9mZlRpbWVyKTtcclxuICAgIG9mZlRpbWVyID0gbnVsbDtcclxuXHJcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHN0b3BBdXRvYnV5ZXI6IHRydWUgfSk7XHJcblxyXG4gICAgY29uc3Qgc2VhcmNoQ291bnQgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJzZWFyY2hDb3VudFwiKTtcclxuICAgIGNvbnN0IHNlZW5Db3VudCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInNlZW5Db3VudFwiKTtcclxuICAgIGNvbnN0IHB1cmNoYXNlZENvdW50ID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwicHVyY2hhc2VkQ291bnRcIik7XHJcblxyXG4gICAgYWxlcnQoXHJcbiAgICAgIGAke3JlYXNvbn0gKCR7c2VhcmNoQ291bnR9IHNlYXJjaGVzLCAke3NlZW5Db3VudH0gY2FyZHMgc2VlbiwgJHtwdXJjaGFzZWRDb3VudH0gY2FyZHMgYm91Z2h0KWBcclxuICAgICk7XHJcbiAgfVxyXG59O1xyXG5cclxuY29uc3QgcmFuZG9taXplID0gKCk6IG51bWJlciA9PiB7XHJcbiAgY29uc3QgbWluID0gMDtcclxuICBjb25zdCBtYXggPSA1MDtcclxuXHJcbiAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIChtYXggLSBtaW4gKyAxKSArIG1pbik7XHJcbn07XHJcblxyXG5jb25zdCBnZXRNYXhCaWRQcmljZSA9IChtYXhQdXJjaGFzZVByaWNlOiBudW1iZXIpOiBudW1iZXIgPT4ge1xyXG4gIGlmIChtYXhQdXJjaGFzZVByaWNlIDw9IDEwMDApIHtcclxuICAgIHJldHVybiBtYXhQdXJjaGFzZVByaWNlIC0gNTA7XHJcbiAgfSBlbHNlIGlmIChtYXhQdXJjaGFzZVByaWNlIDw9IDEwMDAwKSB7XHJcbiAgICByZXR1cm4gbWF4UHVyY2hhc2VQcmljZSAtIDEwMDtcclxuICB9IGVsc2UgaWYgKG1heFB1cmNoYXNlUHJpY2UgPD0gMTAwMDAwKSB7XHJcbiAgICByZXR1cm4gbWF4UHVyY2hhc2VQcmljZSAtIDUwMDtcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIG1heFB1cmNoYXNlUHJpY2UgLSAxMDAwO1xyXG4gIH1cclxufTtcclxuXHJcbmNvbnN0IGNyZWF0ZUN5Y2xlID0gKHBhcmFtczoge1xyXG4gIGN1cnJDeWNsZTogbnVtYmVyO1xyXG4gIHRvdGFsQ3ljbGVzOiBudW1iZXI7XHJcbiAgb25JbnRlcnZhbDogbnVtYmVyO1xyXG4gIG9mZkludGVydmFsOiBudW1iZXI7XHJcbiAgaXNUZXN0UnVuOiBib29sZWFuO1xyXG4gIGFjdGlvbjogc3RyaW5nO1xyXG4gIGxpc3RTdGFydFByaWNlOiBzdHJpbmc7XHJcbiAgbGlzdEJpblByaWNlOiBzdHJpbmc7XHJcbiAgaXRlcmF0aW9uVGltZTogc3RyaW5nO1xyXG4gIGl0ZXJhdGlvblRpbWVNYXg6IHN0cmluZztcclxuICByZXNldFByaWNlOiBudW1iZXI7XHJcbiAgdXNlclNldE1pbkJpbjogYm9vbGVhbjtcclxuICBtYXhCdXlOb3dQcmljZTogbnVtYmVyO1xyXG4gIGluaXRpYWxNYXhCaW46IG51bWJlcjtcclxuICBtaW5pbXVtQ29pbkJhbGFuY2U6IHN0cmluZztcclxufSkgPT4ge1xyXG4gIGNvbnN0IHtcclxuICAgIGN1cnJDeWNsZSxcclxuICAgIHRvdGFsQ3ljbGVzLFxyXG4gICAgb25JbnRlcnZhbCxcclxuICAgIG9mZkludGVydmFsLFxyXG4gICAgaXNUZXN0UnVuLFxyXG4gICAgYWN0aW9uLFxyXG4gICAgbGlzdFN0YXJ0UHJpY2UsXHJcbiAgICBsaXN0QmluUHJpY2UsXHJcbiAgICBpdGVyYXRpb25UaW1lLFxyXG4gICAgaXRlcmF0aW9uVGltZU1heCxcclxuICAgIHJlc2V0UHJpY2UsXHJcbiAgICB1c2VyU2V0TWluQmluLFxyXG4gICAgbWF4QnV5Tm93UHJpY2UsXHJcbiAgICBpbml0aWFsTWF4QmluLFxyXG4gICAgbWluaW11bUNvaW5CYWxhbmNlLFxyXG4gIH0gPSBwYXJhbXM7XHJcblxyXG4gIGNvbnN0IG9uSW50ZXJ2YWxNaW51dGVzID0gb25JbnRlcnZhbCAqIDYwMDAwO1xyXG4gIGNvbnN0IG9mZkludGVydmFsTWludXRlcyA9IG9mZkludGVydmFsICogNjAwMDA7XHJcblxyXG4gIGlzT24gPSB0cnVlO1xyXG5cclxuICAvLyBzZXQgaW5pdGlhbCBjb2luIGJhbGFuY2VcclxuICBjb25zdCBjb2luQmFsYW5jZSA9IChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxyXG4gICAgXCJ2aWV3LW5hdmJhci1jdXJyZW5jeS1jb2luc1wiXHJcbiAgKVswXSBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0O1xyXG4gIGNvbnN0IG5vcm1hbGl6ZWRDb2luQmFsYW5jZSA9IGNvaW5CYWxhbmNlLnJlcGxhY2UoL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csIFwiXCIpO1xyXG4gIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInByZXZpb3VzQ29pbkJhbGFuY2VcIiwgbm9ybWFsaXplZENvaW5CYWxhbmNlKTtcclxuXHJcbiAgbW9uZXlGdW5jdGlvbihwYXJhbXMpO1xyXG5cclxuICBjb25zdCByYW5kb21Nb2RpZmllciA9IHJhbmRvbWl6ZSgpO1xyXG5cclxuICAvLyBTdGFydCBhIHRpbWVyIHRoYXQgc3RvcHMgXCJvblwiIGxvb3AgYWZ0ZXIgc3BlY2lmaWVkIHRpbWVcclxuICBvblRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICBpc09uID0gZmFsc2U7XHJcblxyXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXCJzaG91bGRQbGF5TG9vcERvbmVTb3VuZFwiLCAoZGF0YSkgPT4ge1xyXG4gICAgICBpZiAoZGF0YS5zaG91bGRQbGF5TG9vcERvbmVTb3VuZCkge1xyXG4gICAgICAgIGNvbnN0IGxvb3BEb25lU291bmQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcclxuICAgICAgICAgIHN0eWxlcy5sb29wRG9uZVNvdW5kXHJcbiAgICAgICAgKSBhcyBIVE1MQXVkaW9FbGVtZW50O1xyXG4gICAgICAgIGxvb3BEb25lU291bmQucGxheSgpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoY3VyckN5Y2xlID09PSB0b3RhbEN5Y2xlcyAtIDEpIHtcclxuICAgICAgICBzdG9wQXV0b2J1eWVyKFxyXG4gICAgICAgICAgXCJBdXRvYnV5ZXIgc3RvcHBlZCBiZWNhdXNlIGl0IGNvbXBsZXRlZCB0aGUgbnVtYmVyIG9mIHJlcXVlc3RlZCBjeWNsZXMuXCJcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9LCBvbkludGVydmFsTWludXRlcyArIHJhbmRvbU1vZGlmaWVyKTtcclxuXHJcbiAgLy8gU3RhcnQgYSB0aW1lciB0aGF0IHJlc3RhcnRzIFwib25cIiBsb29wIGFmdGVyIHNwZWNpZmljaWVkIHRpbWVcclxuICBvZmZUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJDeWNsZSA8IHRvdGFsQ3ljbGVzIC0gMSkge1xyXG4gICAgICBjcmVhdGVDeWNsZSh7XHJcbiAgICAgICAgY3VyckN5Y2xlOiBjdXJyQ3ljbGUgKyAxLFxyXG4gICAgICAgIHRvdGFsQ3ljbGVzLFxyXG4gICAgICAgIG9uSW50ZXJ2YWwsXHJcbiAgICAgICAgb2ZmSW50ZXJ2YWwsXHJcbiAgICAgICAgaXNUZXN0UnVuLFxyXG4gICAgICAgIGFjdGlvbixcclxuICAgICAgICBsaXN0U3RhcnRQcmljZSxcclxuICAgICAgICBsaXN0QmluUHJpY2UsXHJcbiAgICAgICAgaXRlcmF0aW9uVGltZSxcclxuICAgICAgICBpdGVyYXRpb25UaW1lTWF4LFxyXG4gICAgICAgIHJlc2V0UHJpY2UsXHJcbiAgICAgICAgdXNlclNldE1pbkJpbixcclxuICAgICAgICBtYXhCdXlOb3dQcmljZSxcclxuICAgICAgICBpbml0aWFsTWF4QmluLFxyXG4gICAgICAgIG1pbmltdW1Db2luQmFsYW5jZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSwgb25JbnRlcnZhbE1pbnV0ZXMgKyByYW5kb21Nb2RpZmllciArIG9mZkludGVydmFsTWludXRlcyk7XHJcbn07XHJcblxyXG5jb25zdCBtb25leUZ1bmN0aW9uID0gKHBhcmFtczoge1xyXG4gIGlzVGVzdFJ1bjogYm9vbGVhbjtcclxuICBhY3Rpb246IHN0cmluZztcclxuICBsaXN0U3RhcnRQcmljZTogc3RyaW5nO1xyXG4gIGxpc3RCaW5QcmljZTogc3RyaW5nO1xyXG4gIGl0ZXJhdGlvblRpbWU6IHN0cmluZztcclxuICBpdGVyYXRpb25UaW1lTWF4OiBzdHJpbmc7XHJcbiAgcmVzZXRQcmljZTogbnVtYmVyO1xyXG4gIHVzZXJTZXRNaW5CaW46IGJvb2xlYW47XHJcbiAgbWF4QnV5Tm93UHJpY2U6IG51bWJlcjtcclxuICBpbml0aWFsTWF4QmluOiBudW1iZXI7XHJcbiAgbWluaW11bUNvaW5CYWxhbmNlOiBzdHJpbmc7XHJcbn0pID0+IHtcclxuICBjb25zdCB7XHJcbiAgICBpc1Rlc3RSdW4sXHJcbiAgICBhY3Rpb24sXHJcbiAgICBsaXN0U3RhcnRQcmljZSxcclxuICAgIGxpc3RCaW5QcmljZSxcclxuICAgIGl0ZXJhdGlvblRpbWUsXHJcbiAgICBpdGVyYXRpb25UaW1lTWF4LFxyXG4gICAgcmVzZXRQcmljZSxcclxuICAgIHVzZXJTZXRNaW5CaW4sXHJcbiAgICBtYXhCdXlOb3dQcmljZSxcclxuICAgIGluaXRpYWxNYXhCaW4sXHJcbiAgICBtaW5pbXVtQ29pbkJhbGFuY2UsXHJcbiAgfSA9IHBhcmFtcztcclxuXHJcbiAgY29uc3QgaXRlcmF0aW9uVGltZVJlYWwgPSBnZXRJbnRlcnZhbChpdGVyYXRpb25UaW1lLCBpdGVyYXRpb25UaW1lTWF4KTtcclxuXHJcbiAgLy8gY2hlY2sgZm9yIGNhcHRjaGFcclxuICBjb25zdCBpc0FsZXJ0UHJlc2VudCA9XHJcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwidWktZGlhbG9nLXR5cGUtYWxlcnRcIikubGVuZ3RoID4gMDtcclxuICBpZiAoaXNBbGVydFByZXNlbnQpIHtcclxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFwic2hvdWxkUGxheUNhcHRjaGFTb3VuZFwiLCAoZGF0YSkgPT4ge1xyXG4gICAgICBpZiAoZGF0YS5zaG91bGRQbGF5Q2FwdGNoYVNvdW5kKSB7XHJcbiAgICAgICAgY29uc3QgYXVkaW8gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChzdHlsZXMuYXVkaW8pIGFzIEhUTUxBdWRpb0VsZW1lbnQ7XHJcbiAgICAgICAgYXVkaW8ucGxheSgpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7XHJcbiAgICAgICAgYWxlcnQ6IHRydWUsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc3RvcEF1dG9idXllcihcclxuICAgICAgICBcIkF1dG9idXllciBzdG9wcGVkIGJlY2F1c2UgaHVtYW4gdmVyaWZpY2F0aW9uIGlzIHJlcXVpcmVkIGJ5IEVBLlwiXHJcbiAgICAgICk7XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICAvLyBjaGVjayBmb3IgY29pbiBiYWxhbmNlXHJcbiAgY29uc3QgY29pbkJhbGFuY2UgPSAoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgIFwidmlldy1uYXZiYXItY3VycmVuY3ktY29pbnNcIlxyXG4gIClbMF0gYXMgSFRNTEVsZW1lbnQpLmlubmVyVGV4dDtcclxuICBjb25zdCBub3JtYWxpemVkQ29pbkJhbGFuY2UgPSBjb2luQmFsYW5jZS5yZXBsYWNlKC9bLiwgXSovZywgXCJcIik7XHJcblxyXG4gIC8vIGdldCBwcmV2aW91cyBjb2luIGJhbGFuY2UgZnJvbSBzdG9yYWdlXHJcbiAgY29uc3QgcHJldmlvdXNDb2luQmFsYW5jZSA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcclxuICAgIFwicHJldmlvdXNDb2luQmFsYW5jZVwiXHJcbiAgKTtcclxuXHJcbiAgaWYgKG5vcm1hbGl6ZWRDb2luQmFsYW5jZSA8IG1pbmltdW1Db2luQmFsYW5jZSkge1xyXG4gICAgc3RvcEF1dG9idXllcihcclxuICAgICAgXCJBdXRvYnV5ZXIgc3RvcHBlZCBiZWNhdXNlIHlvdXIgY29pbiBiYWxhbmNlIGhhcyBmYWxsZW4gYmVuZWF0aCB0aGUgbWluaW11bSBjb2luIGJhbGFuY2UgdGhyZXNob2xkIHlvdSBzZXQuXCJcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuO1xyXG4gIH0gZWxzZSBpZiAocHJldmlvdXNDb2luQmFsYW5jZSAhPT0gbm9ybWFsaXplZENvaW5CYWxhbmNlKSB7XHJcbiAgICBjb25zdCBqdXN0U2F3Q2FyZCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImp1c3RTYXdDYXJkXCIpO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogaWYgdGhlIGNhcmQgYmFsYW5jZSBpcyBkaWZmZXJlbnQgdGhhbiBiZWZvcmUgd2Ugc2VhcmNoZWQsIGFuZCB3ZSBqdXN0XHJcbiAgICAgKiBzYXcgYSBjYXJkLCB3ZSBjYW4gcmVhc29uYWJseSBhc3N1bWUgYSBjYXJkIHdhcyBwdXJjaGFzZWRcclxuICAgICAqL1xyXG4gICAgaWYgKGp1c3RTYXdDYXJkID09PSBcInRydWVcIikge1xyXG4gICAgICBjb25zdCBvbGRDb3VudCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInB1cmNoYXNlZENvdW50XCIpO1xyXG4gICAgICBjb25zdCBuZXdDb3VudCA9IG9sZENvdW50ID8gcGFyc2VJbnQob2xkQ291bnQpICsgMSA6IDE7XHJcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInB1cmNoYXNlZENvdW50XCIsIG5ld0NvdW50LnRvU3RyaW5nKCkpO1xyXG5cclxuICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoXHJcbiAgICAgICAgW1wic2hvdWxkUGxheUNhcmRQdXJjaGFzZWRTb3VuZFwiLCBcImRpc2NvcmRXZWJob29rQ2FyZFB1cmNoYXNlZFwiXSxcclxuICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgaWYgKGRhdGEuc2hvdWxkUGxheUNhcmRQdXJjaGFzZWRTb3VuZCkge1xyXG4gICAgICAgICAgICBjb25zdCBjYXJkUHVyY2hhc2VkU291bmQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcclxuICAgICAgICAgICAgICBzdHlsZXMuY2FyZFB1cmNoYXNlZFNvdW5kXHJcbiAgICAgICAgICAgICkgYXMgSFRNTEF1ZGlvRWxlbWVudDtcclxuICAgICAgICAgICAgY2FyZFB1cmNoYXNlZFNvdW5kLnBsYXkoKTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAoZGF0YS5kaXNjb3JkV2ViaG9va0NhcmRQdXJjaGFzZWQpIHtcclxuICAgICAgICAgICAgZmV0Y2hfcmV0cnkoXHJcbiAgICAgICAgICAgICAgZGF0YS5kaXNjb3JkV2ViaG9va0NhcmRQdXJjaGFzZWQsXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgY29udGVudDogYEEgY2FyZCB3YXMgKHByb2JhYmx5KSBib3VnaHRgLFxyXG4gICAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIDVcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyByZXNldHMgdGhpcyBjaGVjayBiZWZvcmUgd2Ugc2VhcmNoIGFnYWluXHJcbiAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwianVzdFNhd0NhcmRcIiwgXCJmYWxzZVwiKTtcclxuXHJcbiAgc2VhcmNoKCFpc1Rlc3RSdW4pO1xyXG5cclxuICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGlmIChhY3Rpb24gPT09IFwibGlzdFwiKSB7XHJcbiAgICAgICAgICBsaXN0KGxpc3RTdGFydFByaWNlLCBsaXN0QmluUHJpY2UpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoYWN0aW9uID09PSBcInRyYW5zZmVyXCIpIHtcclxuICAgICAgICAgIHNlbmRUb1RyYW5zZmVyTGlzdCgpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoYWN0aW9uID09PSBcImNsdWJcIikge1xyXG4gICAgICAgICAgc3RvcmVJbkNsdWIoKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gXCJub25lXCIgfHwgIWFjdGlvbikge1xyXG4gICAgICAgICAgLy8gZG8gbm90aGluZ1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGlmIChpc1VzZXJPblNlYXJjaFJlc3VsdHNQYWdlKCkpIHtcclxuICAgICAgICAgIGdvQmFjaygpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSwgMjAwKTtcclxuICAgIH0sIDMwMCk7XHJcblxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIGlmICh1c2VyU2V0TWluQmluKSB7XHJcbiAgICAgICAgY29uc3QgbWluQmlkSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxyXG4gICAgICAgICAgXCJudW1lcmljSW5wdXRcIlxyXG4gICAgICAgIClbMF0gYXMgSFRNTElucHV0RWxlbWVudDtcclxuICAgICAgICBjb25zdCBjdXJyZW50TWluQmlkID1cclxuICAgICAgICAgIHBhcnNlSW50KG1pbkJpZElucHV0LnZhbHVlLnJlcGxhY2UoL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csIFwiXCIpKSB8fCAwO1xyXG5cclxuICAgICAgICAvLyBJZiBjdXJyZW50IG1pbiBiaWQgaXMgZ3JlYXRlciB0aGFuIHJlc2V0UHJpY2UsIHJlc2V0LlxyXG4gICAgICAgIGlmIChjdXJyZW50TWluQmlkID49IHJlc2V0UHJpY2UpIHtcclxuICAgICAgICAgIG1pbkJpZElucHV0LnZhbHVlID0gXCJcIjtcclxuICAgICAgICAgIGNoYW5nZU1heEJpbihpbml0aWFsTWF4QmluLCBtYXhCdXlOb3dQcmljZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpbmNyZWFzZU1pbkJpZFByaWNlKCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc3QgbWluQmluSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFxyXG4gICAgICAgICAgXCJudW1lcmljSW5wdXRcIlxyXG4gICAgICAgIClbMl0gYXMgSFRNTElucHV0RWxlbWVudDtcclxuICAgICAgICBjb25zdCBjdXJyZW50TWluQmluID1cclxuICAgICAgICAgIHBhcnNlSW50KG1pbkJpbklucHV0LnZhbHVlLnJlcGxhY2UoL1suLCBcXHUwMGEwXFx1MjAyRl0qL2csIFwiXCIpKSB8fCAwO1xyXG5cclxuICAgICAgICAvLyBJZiBjdXJyZW50IG1pbiBCSU4gaXMgZ3JlYXRlciB0aGFuIHJlc2V0UHJpY2UsIHJlc2V0LlxyXG4gICAgICAgIGlmIChjdXJyZW50TWluQmluID49IHJlc2V0UHJpY2UpIHtcclxuICAgICAgICAgIG1pbkJpbklucHV0LnZhbHVlID0gXCJcIjtcclxuICAgICAgICAgIGNoYW5nZU1heEJpbihpbml0aWFsTWF4QmluLCBtYXhCdXlOb3dQcmljZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpbmNyZWFzZU1pbkJpblByaWNlKCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChpc09uKSB7XHJcbiAgICAgICAgbW9uZXlGdW5jdGlvbihwYXJhbXMpO1xyXG4gICAgICB9XHJcbiAgICB9LCA5MDApO1xyXG4gIH0sIGl0ZXJhdGlvblRpbWVSZWFsKTtcclxufTtcclxuXHJcbi8qKlxyXG4gKiBDaGFuZ2VzIFwibWF4IEJJTlwiIHByaWNlIGluIHNlYXJjaCBmaWx0ZXJcclxuICpcclxuICogQHBhcmFtIGluaXRpYWxNYXhCaW4gTWF4IEJJTiBzZXQgaW4gdGhlIG9yaWdpbmFsIGZpbHRlclxyXG4gKiBAcGFyYW0gbWF4QnV5Tm93UHJpY2UgVGhlIHByaWNlIHNldCBieSB0aGUgdXNlciBpbiB0aGUgcG9wLXVwXHJcbiAqL1xyXG5jb25zdCBjaGFuZ2VNYXhCaW4gPSAoaW5pdGlhbE1heEJpbjogbnVtYmVyLCBtYXhCdXlOb3dQcmljZTogbnVtYmVyKSA9PiB7XHJcbiAgaWYgKG1heEJ1eU5vd1ByaWNlIDw9IGluaXRpYWxNYXhCaW4pIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGNvbnN0IG1heEJpbklucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcclxuICAgIFwibnVtZXJpY0lucHV0XCJcclxuICApWzNdIGFzIEhUTUxJbnB1dEVsZW1lbnQ7XHJcbiAgY29uc3QgY3VycmVudE1heEJpbiA9XHJcbiAgICBwYXJzZUludChtYXhCaW5JbnB1dC52YWx1ZS5yZXBsYWNlKC9bLiwgXFx1MDBhMFxcdTIwMkZdKi9nLCBcIlwiKSkgfHwgMDtcclxuXHJcbiAgaWYgKGN1cnJlbnRNYXhCaW4gPT09IDApIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGlmIChjdXJyZW50TWF4QmluID49IG1heEJ1eU5vd1ByaWNlKSB7XHJcbiAgICBtYXhCaW5JbnB1dC52YWx1ZSA9IGluaXRpYWxNYXhCaW4udG9TdHJpbmcoKTtcclxuICAgIGluY3JlYXNlTWF4QmluUHJpY2UoKTtcclxuICAgIGRlY3JlYXNlTWF4QmluUHJpY2UoKTtcclxuICB9IGVsc2Uge1xyXG4gICAgaW5jcmVhc2VNYXhCaW5QcmljZSgpO1xyXG4gIH1cclxufTtcclxuXHJcbmZ1bmN0aW9uIGdldEludGVydmFsKGl0ZXJhdGlvblRpbWU6IHN0cmluZywgaXRlcmF0aW9uVGltZU1heDogc3RyaW5nKSB7XHJcbiAgY29uc3QgbWluID0gcGFyc2VJbnQoaXRlcmF0aW9uVGltZSk7XHJcbiAgY29uc3QgbWF4ID0gcGFyc2VJbnQoaXRlcmF0aW9uVGltZU1heCk7XHJcblxyXG4gIHJldHVybiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAobWF4IC0gbWluICsgMSkgKyBtaW4pO1xyXG59XHJcblxyXG5jb25zdCBmZXRjaF9yZXRyeSA9ICh1cmwsIG9wdGlvbnMsIG4pID0+XHJcbiAgZmV0Y2godXJsLCBvcHRpb25zKS5jYXRjaChmdW5jdGlvbiAoZXJyb3IpIHtcclxuICAgIGlmIChuID09PSAxKSB0aHJvdyBlcnJvcjtcclxuICAgIHJldHVybiBmZXRjaF9yZXRyeSh1cmwsIG9wdGlvbnMsIG4gLSAxKTtcclxuICB9KTtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==